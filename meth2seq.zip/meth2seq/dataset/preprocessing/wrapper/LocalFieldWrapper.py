from ..local.LocalTokenizer import LocalTokenizer
from ..local.LocalRefiner import LocalRefiner


class LocalFieldWrapper:

    def __init__(self):
        pass

    @staticmethod
    def tokenize(input):
        tk = LocalTokenizer()
        sp1 = tk.simple_split(input)
        sp2 = [tk.camel_split(t) for t in sp1]
        # sp3 = [tk.ninja_split(t) for t in sp2]
        return sp2

    @staticmethod
    def preprocess(input):
        return input

    @staticmethod
    def postprocess(input):
        pass