from ..local.LocalTokenizer import LocalTokenizer


class CommentFiledWrapper:

    def __init__(self):
        pass

    @staticmethod
    def tokenize(input):
        tk = LocalTokenizer()
        sp1 = tk.simple_split(input)
        # sp2 = [tk.camel_split(t) for t in sp1]
        # sp3 = [tk.ninja_split(t) for t in sp2]
        return sp1

    @staticmethod
    def preprocess(input):
        if len(input) < 10:
            return input
        else:
            return input[:10]

    @staticmethod
    def postprocess(input):
        pass