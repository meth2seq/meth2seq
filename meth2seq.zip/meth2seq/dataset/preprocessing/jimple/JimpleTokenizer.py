from ..core.tokenize import Tokenizer


class JimpleTokenizer(Tokenizer):

    def __init__(self):
        super(JimpleTokenizer, self).__init__()
        self.special_cases = [
            "stmt", "cfg", "data_flow",
            "JAssignStmt",
            "IdentityStmt", "JIdentityStmt",
            "AbstractDefinitionStmt", "JAbstractDefinitionStmt",
            "JEnterMonitorStmt",
            "JExitMonitorStmt",
            "JReturn",
            "JThrowStmt",
            "JLookupSwitchStmt",
            "JTableSwitchStmt",
            "JBreakpointStmt",
            "JGotoStmt",
            "JIfStmt",
            "JInvokeStmt",
            "JNopStmt",
            "JRetStmt",
            "JRetVoidStmt",
            "JReturnStmt"
        ]

        self.stoplist = [
            "lambda", "test", "main", "bootstrap",
            "org", "com", "spring", "java"
        ]