from ..core.refine import Refiner


class JimpleRefiner(Refiner):

    def __init__(self):
        super(JimpleRefiner, self).__init__()

    def refine(self, tokens):
        res = []
        for t in tokens:
            t = self.do_special_case(t)
            t = self.refine_letters(t)
            if not self.is_empty(t) and self.is_valid(t):
                res.append(t)
        return res

    def do_special_case(self, input):
        if input == "stmt":
            return "statement"
        elif input == "data_flow":
            return "dataflow"
        elif input == "pad":
            return "<pad>"
        else:
            return input