"""functions for preprocess after tokenize"""
import re


class Refiner:

    def __init__(self):
        self.special_tokens = ['<unk>', '<pad>', '<s>', '<eos>']
        self.special_cases = []
        self.stoplist = ["jj_3R_14", "jj_2_2", "jj_3_2", "jj_3_3", "jj_2_3", "jj_3_1", "jj_2_1"]

    def refine(self, tokens):
        res = []
        for t in tokens:
            t = self.do_special_case(t)
            t = self.refine_letters(t)
            if not self.is_empty(t) and self.is_valid(t):
                res.append(t)
        return res

    def refine_letters(self, input):
        """remove non alphabetic letters"""
        if input in self.special_tokens:
            return input
        else:
            return re.sub(r'[^a-zA-Z]', '', input)

    def do_special_case(self, input):
        return input

    def get_lower_case(self, input):
        return input.lower()

    def is_empty(self, input):
        if len(input) < 1:
            return True
        if input is None:
            return True
        if input == "":
            return True
        if not isinstance(input, str):
            return True
        return False

    def is_valid(self, input):
        if not any(c.isalpha() for c in input):
            return False
        if input[0].isdigit():
            return False
        if len(input) < 2:
            return False
        if len(set([c for c in input])) < 2:
            return False
        if input == 'iz':
            return False
        if input in self.stoplist:
            return False
        return True
