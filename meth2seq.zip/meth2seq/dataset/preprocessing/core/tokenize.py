"""functions for tokenization"""
import re
import wordninja
import spacy


class Tokenizer:

    def __init__(self):
        self.special_cases = []

        self.stoplist = []

    def simple_split(self, input):
        res = []
        tokens = input.split(',')
        for t in tokens:
            tokens2 = [x.strip() for x in t.split(':')]
            for t2 in tokens2:
                tokens3 = [x.strip() for x in t2.split(' ')]
                for t3 in tokens3:
                    res.append(t3)
        return res

    def camel_split(self, input):
        res = []
        # <init>, <clinit>
        input = input.strip('<').strip('>')
        # $
        tokens = input.split('$')
        # camel case
        for t in tokens:
            if t not in self.special_cases:
                regex = re.compile('[^a-zA-Z]')
                regex.sub('', t)
                t_u = ''
                for _s_ in t:
                    if isinstance(_s_, str):
                        t_u += _s_ if _s_.islower() else '_' + _s_.lower()  # also split ',' and ' '
                l = t_u.split('_')
                for r in l:
                    if r != '' and not r.isdigit():
                        r = re.sub(r'[^a-zA-Z]', '', r)
                        res.append(r)
            else:
                res.append(t)
        return res

    def ninja_split(self, input):
        if input not in self.special_cases:
            return wordninja.split(input)
        else:
            return [input]

    def split_twice(self, l):
        """ninjia split the second time to ensure some words are split"""
        tokens = []
        if l in self.special_cases or not self.should_ninjia(l):
            tokens.append(l)
        else:
            for t in self.ninja_split(l):
                tokens.append(t)
        return tokens

    def should_ninjia(self, l):
        if l.endswith('i') or l.endswith('j') or l.endswith('k') or l.endswith('t') or l.endswith('s'):
            return True
        if l.startswith('get') or l.startswith('set') or l.startswith('do') or l.startswith('start'):
            return True
        if len(l) > 10:
            return True
        return False

    def spacy_lemmatize(self, tokens, restrict_level=1):
        '''
        restrict_level = 0 : all lemmatize
        restrict_level = 1 : ignore NOUNs
        restrict_level = 2 : only verbs
        '''
        res = []
        from spacy.lemmatizer import Lemmatizer
        from spacy.lang.en import LEMMA_INDEX, LEMMA_EXC, LEMMA_RULES
        lemmatizer = Lemmatizer(LEMMA_INDEX, LEMMA_EXC, LEMMA_RULES)
        nlp = spacy.load("en")
        tokens = ' '.join(tokens)
        doc = nlp(tokens)
        if restrict_level == 0:
            for token in doc:
                pos = token.pos_
                r = lemmatizer(str(token), pos)
                res.append(r[0])

        if restrict_level == 1:
            for token in doc:
                pos = token.pos_
                #             print(pos)
                if pos != 'NOUN':
                    r = lemmatizer(str(token), pos)
                    res.append(r[0])
                else:
                    res.append(str(token))

        if restrict_level == 2:
            for token in doc:
                pos = token.pos_
                #             print(pos)
                if pos == 'VERB':
                    r = lemmatizer(str(token), pos)
                    res.append(r[0])
                else:
                    res.append(str(token))
        return res

    def is_valid_token(self, input):
        """filter out names that is not alphabetic"""
        if not any(c.isalpha() for c in input):
            return False
        if input[0].isdigit():
            return False
        if len(input) < 2:
            return False
        if len(set([c for c in input])) < 2:
            return False
        if input == 'iz':
            return False
        if input in self.stoplist:
            return False
        return True