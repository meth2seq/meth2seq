"""
trimming strategy:
1. get simple name
2. apply trimming strategy: with $ / without $
3. move away "__trim__"
"""


import re


def should_trim(name):
    """
    filter out certain kind of names according to experiment settings
    :param name: name to examine
    :return: bool value
    """
    # anonymous method that can't find corresponding source name (name = A$B)
    if name.find('$') != -1 and len(name.split('$')) <= 2 and not name.startswith('$'):
        return True
    # main or init method
    if name == 'main' or name == '<init>' or name == '<clinit>':
        return True
    # init method
    if name.find('<init>') != -1 or name.find('<clinit>') != -1:
        return True
    # toy method
    if name.find('example') != -1 or name.find('sample') != -1 or name.find('template') != -1:
        return True
    # names without any letters or empty name
    if not any(c.isalpha() for c in name):
        return True
    else:
        return False


class Trimming:

    def __init__(self):
        self.stoplist = ["test", "main", "<init>", "<clinit>", "bootstrap"]
        self.stoplist.extend(["jj_3R_14", "jj_2_2", "jj_3_2", "jj_3_3", "jj_2_3", "jj_3_1", "jj_2_1"])
        self.inner_stoplist = self.stoplist

    def trim(self, original_name):
        """
        trim name before tokenizing
        :param original_name: original method name
        :return: trimmed name
        """
        simplename = self.get_simple_name(original_name)
        if "$" in simplename:
            simplename = self.trim_dollar_name(simplename)
        name = self.trim_normal_name(simplename)
        if not self.is_valid(name):
            name = "__trim__"
        return name

    def get_simple_name(self, original_name):
        """
        for most cases, just move out package and class names
        when class is a inner class, we have to check if the method name is meaningful
        for example:
            in case A$B.apply(), method name apply is meaningless.
            in case A$B.getFieldType, the name getFieldType is meaningful;
            in case A.apply(java.Object), the name apply is meaningful
        :param original_name:
        :return: simple name
        """
        # get class and method name
        original_name = re.sub(r'\(.*\)', '', original_name)
        clsname = original_name.split('.')[-2]
        mdname = original_name.split('.')[-1]
        # for normal cases
        if "$" not in clsname:
            simplename = mdname
        # for inner class cases
        else:
            # not meaningful names in inner class
            if mdname in self.inner_stoplist:
                simplename = "__trim__"
            else:
                simplename = mdname
        assert simplename is not None
        return simplename

    def trim_dollar_name(self, name):
        """
        deal with a name with a $ symbol.
        for all $ cases, the only meaningful part might be is the second part of the name.
        and this part is meaningful when it contains alphabetic letters.
        for example:
            bootstrap$ and access$000 should be trimmed.
            G$instMessage should not be trimmed.
        :param name: type str, method name
        :return: trimmed name
        """
        name = name.split('$')[1]
        if Trimming.contains_letter(name):
            return name
        else:
            return "__trim__"

    @staticmethod
    def contains_letter(name):
        """
        check if a name contains any alphabetic letters
        :param name: str type, method name
        :return: bool
        """
        if not any(c.isalpha() for c in name):
            return False
        else:
            return True

    def trim_normal_name(self, name):
        """
        deal with method names without any $ symbol.
        trim out certain names according to experiment hyperparam.
        :param name: method name, type str
        :return: trimmed name
        """
        if name in self.stoplist:
            name = "__trim__"
        if "example" in name or "template" in name:
            name = "__trim__"
        if not self.contains_letter(name):
            name = "__trim__"
        return name

    def is_valid(self, input):
        if input[0].isdigit():
            return False
        input = re.sub(r'[^a-zA-Z]', '', input)
        if not any(c.isalpha() for c in input):
            return False
        if len(input) < 2:
            return False
        if len(set([c for c in input])) < 2:
            return False
        if input == 'iz':
            return False
        if input in self.stoplist:
            return False
        return True
