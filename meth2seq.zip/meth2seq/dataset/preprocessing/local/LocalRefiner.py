from ..core.refine import Refiner


class LocalRefiner(Refiner):
    
    def __init__(self):
        super(LocalRefiner, self).__init__()