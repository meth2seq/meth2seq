from ..core.tokenize import Tokenizer


class LocalTokenizer(Tokenizer):

    def __init__(self):
        super(LocalTokenizer, self).__init__()
