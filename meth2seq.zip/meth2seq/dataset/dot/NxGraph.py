import random
import networkx as nx
import matplotlib.pyplot as plt
from .SimpleJimple import SimpleJimple
from .Delimiter import Delimiter


class NxGraph:
    """
    基于networkx中graph类的wrapper class
    """
    def __init__(self, graph, info_node=None):
        """
        构造函数
        :param graph: 一个networkx graph实例
        :param info_node: dot文件中的info node
        """
        self.graph = graph
        self.info_node = self.find_info_node()
        self.walk_length_factor = None
        self.walk_times_factor = None
        self.set_random_walk_factor()

    def nodes(self):
        """return all node id of the graph"""
        return list(self.graph.nodes())

    def edges(self):
        """return all edges of a graph"""
        return list(self.graph.edges())

    def get_jimple(self, node):
        s = str(self.graph.nodes[node]['label'])
        if not s.startswith("\"label"):
            return self.graph.nodes[node]['label']
        else:
            return "goto_label"

    def get_ir(self, node):
        s = str(self.graph.nodes[node]['label'])
        # 如果不是goto语句的目的节点，以及不是位于info node之后的节点
        if not s.startswith("\"label") and int(node) < int(self.info_node):
            return self.graph.nodes[node]['ir']
        else:
            return "goto_label"

    # TODO 加入新的getter方法(ir, trans, comment)

    def get_simple_jimple(self, node):
        """
        注意，必须要relabel_attrs方法执行后方可使用该方法
        :param node:
        :return:
        """
        s = str(self.graph.nodes[node]['label'])
        if not s.startswith("\"label") and int(node) < int(self.info_node):
            return self.graph.nodes[node]['simple_jimple']
        else:
            return "goto_label"

    def get_full_method_name(self):
        res = self.graph.nodes[self.info_node]["fullMethodName"]
        return res.strip("\"")

    def get_simple_method_name(self):
        # TODO typo in simlpeMethodName
        res = self.graph.nodes[self.info_node]["simlpeMethodName"]
        return res.strip("\"")

    def get_local_names(self):
        res = self.graph.nodes[self.info_node]["local"]
        return res.strip("\"")

    def get_param_names(self):
        res = self.graph.nodes[self.info_node]["param"]
        return res.strip("\"")

    def get_comments(self):
        res = self.graph.nodes[self.info_node]["comment"]
        return res.strip("\"")

    def find_info_node(self):
        info_node = None
        for node in self.graph.nodes():
            if self.graph.nodes[node].get('comment') is not None:
                info_node = node
        assert info_node is not None
        return info_node

    def remove_info_node(self):
        self.graph.remove_node(self.info_node)
        return self.info_node

    def relabel_attrs(self):
        """
        对graph中的node和edge的属性进行relabel
        1. 对于node：增加"simple_jimple"属性
        2. 对于edge: 新增edge的label属性，由edge[color]进行判断
        :return:
        """
        g = self.graph
        for node in g.nodes():
            label = g.node[node]['label']
            namer = SimpleJimple(label)
            simple_jimple = namer.get_simple_jimple()
            g.node[node]['simple_jimple'] = simple_jimple
        for e in g.edges:
            labels = g.edges[e]
            if labels.get('color') is None:
                g.edges[e]['label'] = 'cfg'
            elif labels.get('color') == 'red':
                g.edges[e]['label'] = 'data_flow'
            elif labels.get('color') == 'blue':
                g.edges[e]['label'] = 'extra'
            elif labels.get('color') == 'green':
                g.edges[e]['label'] = 'calling'
            else:
                raise ValueError("unchecked edge color")

    def is_super_graph(self):
        if len(self.graph.nodes()) > 200:
            return True
        return False

    def get_adjacency_dict(self):
        """
        get the adjacent list of a multi-directed-graph
        note that if there are multi lines between two nodes, only one is recorded in a adj_list
        e.g. (0, 1, color='red) and (0, 1, color='blue') --> 0: 1
        TODO: will multi-lines affect random walk?
        :return: dict -> {node : its adj_list}
        """
        adj_dict = {}
        for node, neibour in self.graph.adjacency():
            adj_dict.setdefault(node, [])
            for v in neibour:
                adj_dict[node].append(v)
        return adj_dict

    def remove_self_loop(self):
        """
        remove self-loop in graph
        e.g. (1 -> 1)
        :return refined adjacent dict
        """

        removed_num = 0

        adjacent = self.get_adjacency_dict()
        for node, neibour in adjacent:
            if node in neibour:
                neibour.remove(node)
                removed_num += 1
        return adjacent

    def check_self_loop(self):
        """
        check if a graph has any self-loop
        :return: true or false
        """
        adjacent = self.get_adjacency_dict()
        for node, neibour in adjacent:
            if node in neibour:
                return True
        return False

    def has_edge(self):
        # TODO
        return None

    def degree(self):
        # TODO
        return None

    def order(self):
        # TODO
        return None

    def number_of_edges(self):
        # TODO
        return None

    def number_of_nodes(self):
        # TODO
        return None

    def out_edges(self, node):
        """return all out edges of a node"""
        return list(self.graph.out_edges(node))

    def in_edges(self, node):
        """return all out edges of a node"""
        return list(self.graph.in_edges(node))

    def out_edges_multi(self, node):
        """return all out edges in 3-tuple form"""
        out_edges_3_form = []
        out_edges = self.out_edges(node)
        for edge in out_edges:
            s = edge[0]
            t = edge[1]
            multi = self.graph[s][t]
            for i in range(len(multi)):
                label = self.graph[s][t][i]['label']
                out_edges_3_form.append((s, t, label))
        return out_edges_3_form

    def in_edges_multi(self, node):
        """return all in edges in 3-tuple form"""
        in_edges_3_form = []
        in_edges = self.in_edges(node)
        for edge in in_edges:
            s = edge[0]
            t = edge[1]
            multi = self.graph[s][t]
            for i in range(len(multi)):
                # print('i: ' + str(i))
                # print(s, t)
                label = self.graph[s][t][i]['label']
                in_edges_3_form.append((s, t, label))
        return in_edges_3_form

    def find_tail_node(self, head, edge):
        """
        given a head node and a edge, find the tail node
        :param head: head node
        :param edge: edge of 3-tuple form: (u, v, k='id')
        :return: tail node
        """
        s = edge[0]
        t = edge[1]
        return t

    def draw(self):
        plt.subplot(221)
        nx.draw(self.graph, with_labels=True, font_weight='bold')
        plt.show()

    @staticmethod
    def draw_save(graph, path):
        plt.subplot(211)
        nx.draw(graph, with_labels=True, font_weight='bold')
        # plt.show()
        plt.savefig(path)

    def random_walk_adjacent(self, path_length, alpha=0, rand=random.Random(), start=None):
        """
        returns a truncated random walk.
        :param path_length: length of a random walk
        :param alpha: probability of restart
        :param rand: random seed
        :param start: the start node of random walk
        :return: a generated random walk
        """
        if start:
            path = [start]
        else:
            # sampling nodes not edges
            path = [rand.choice(self.nodes())]

        while len(path) < path_length:
            cur = path[-1]
            cur_neibour = self.get_adjacency_dict().get(cur)
            if len(cur_neibour) > 0:
                if rand.random() > alpha:
                    path.append(rand.choice(cur_neibour))
                else:
                    path.append(path[0])
            else:
                # this is how we truncate the walk
                break
        delim = Delimiter()
        res = [self.get_jimple(node) + delim.label_level + self.get_ir(node) for node in path]
        return delim.node_level.join(res)

    def random_walk_graph(self, path_length, alpha=0, rand=random.Random(), start=None):
        """
        returns a truncated random walk that use original graph
        :param path_length: length of a random walk
        :param alpha: probability of restart
        :param rand: random seed
        :param start: the start node of random walk
        :return: a generated random walk (now use simplified jimples)
        """

        if start:
            path = [start]
        else:
            # sample a start node
            # sampling edges not nodes
            path = [rand.choice(self.nodes())]

        while len(path) < path_length:
            cur = path[-1]
            out_edges = self.out_edges_multi(cur)
            if len(out_edges) > 0:
                if rand.random() > alpha:
                    selected_edge = rand.choice(out_edges)
                    next_node = self.find_tail_node(cur, selected_edge)
                    path.append(next_node)
                else:
                    path.append(path[0])
            else:
                break
        delim = Delimiter()
        res = [self.get_jimple(node) + delim.label_level + self.get_ir(node) for node in path]
        return delim.node_level.join(res)

    def random_walk_graph_edge_sampled(self, path_length, alpha=0, rand=random.Random(), start=None):
        """
        returns a truncated random walk that use original graph, edges are sampled in walks
        :param path_length: length of a random walk
        :param alpha: probability of restart
        :param rand: random seed
        :param start: the start node of random walk
        :return: a generated random walk with edge sampled (now uising simplified Jimples)
        """
        if start:
            path = [start]
        else:
            # sample a start node
            # sampling edges not nodes
            path = [rand.choice(self.nodes())]

        edge_path = []
        while len(path) < path_length:
            cur = path[-1]
            out_edges = self.out_edges_multi(cur)
            if len(out_edges) > 0:
                if rand.random() > alpha:
                    selected_edge = rand.choice(out_edges)
                    edge_path.append(selected_edge)
                    next_node = self.find_tail_node(cur, selected_edge)
                    path.append(next_node)
                else:
                    cur2 = path[0]
                    out_edges2 = self.out_edges_multi(cur2)
                    selected_edge2 = rand.choice(out_edges2)
                    next_node = self.find_tail_node(cur2, selected_edge2)
                    edge_path.append(selected_edge2)
                    path.append(next_node)
            else:
                break
        res = []
        delim = Delimiter()
        # 如果在第一个位置没有终止
        if len(path) > 1:
            for i in range(0, len(path)-1):
                jimple = self.get_jimple(path[i])
                ir = self.get_ir(path[i])
                s = jimple + delim.label_level + ir
                res.append(s)
                e = edge_path[i][2]
                res.append("\"" + e + "\"")  # FIXME
            jimple = self.get_jimple(path[len(path)-1])
            ir = self.get_ir(path[len(path)-1])
            s= jimple + delim.label_level + ir
            res.append(s)
        # 如果在第一个位置就终止了，那么就返回第一个节点
        else:
            jimple = self.get_jimple(path[0])
            ir = self.get_ir(path[0])
            s = jimple + delim.label_level + ir
            res.append(s)
        return delim.node_level.join(res)

    def set_random_walk_factor(self, length_factor=4, time_factor=4):
        """
        指定random walk的次数和长度的计算参数
        :param length_factor:
        :param time_factor:
        :return:
        """
        self.walk_length_factor = length_factor
        self.walk_times_factor = time_factor

    def get_random_walks(self, mode):
        random_walks = []
        l = len(self.nodes())
        walk_length = int(l / self.walk_length_factor + 1)
        walk_times = self.walk_times_factor * l
        for i in range(walk_times):
            if mode == 0:
                walk = self.random_walk_adjacent(walk_length)
            elif mode == 1:
                walk = self.random_walk_graph(walk_length)
            else:
                walk = self.random_walk_graph_edge_sampled(walk_length)
            assert len(walk) > 0
            random_walks.append(walk)
        return random_walks
