import os
import traceback
from tqdm import tqdm
import itertools
from networkx.drawing.nx_pydot import read_dot
from .NxGraph import NxGraph
from .Delimiter import Delimiter


class DotFileWalker:

    def __init__(self, paths):
        """
        init function
        :param paths: input paths, list
        """
        self.paths = paths
        self.map_files = []
        self.dot_files = []
        self.dictionary = {}
        self.read_dot_files()

    def __iter__(self):
        for dot_file in self.dot_files:
            yield dot_file

    def __len__(self):
        return len(self.dot_files)

    def read_dot_files(self):
        map_files = []
        dot_files = []
        # get all dot files and map files
        for path in self.paths:
            for root, dirs, files in os.walk(path):
                for file in files:
                    if file == 'cfg_map.txt':
                        map_files.append(os.path.join(root, file))
                    if file.endswith('CFG.dot'):
                        dot_files.append(os.path.join(root, file))
        self.map_files = map_files
        self.dot_files = dot_files

    def process(self, output_path, exc_path, times=-1, mode=2):
        """
        从dot文件中读取信息，并写入文件
        :param output_path: 输出文件的路径
        :param exc_path: 异常文件的路径
        :param times: 如果为-1则执行全部dot文件；否则执行times个数的dot文件
        :param mode: 执行random walk的方式
        :return:
        """
        err_cases = []
        errcount = 0
        count = 0
        if times == -1:
            for dot in tqdm(self):
                try:
                    g = read_dot(dot)
                    nxGraph = NxGraph(g)
                    # 如果不是过大的图
                    if not nxGraph.is_super_graph():
                        # 从info node 中读取信息
                        full_name = nxGraph.get_full_method_name()
                        simple_name = nxGraph.get_simple_method_name()
                        locals = nxGraph.get_local_names()
                        params = nxGraph.get_param_names()
                        comment = nxGraph.get_comments()
                        # 去除info node并且relabel， 准备进行random walk
                        nxGraph.remove_info_node()
                        nxGraph.relabel_attrs()
                        # get random walk
                        random_walks = nxGraph.get_random_walks(mode=mode)
                        info = {"count": count, "dot": dot, "simple_name": simple_name, "comment": comment,
                                "locals": locals, "params": params, "random_walks": random_walks}
                        DotFileWalker.write(output_path, full_name, info)
                    count += 1
                except Exception:
                    count += 1
                    errcount += 1
                    err_cases.append(dot)
                    DotFileWalker.excpetion_write(traceback.format_exc(), exc_path)
                    DotFileWalker.excpetion_write(dot, exc_path)
                    DotFileWalker.excpetion_write("------------------", exc_path)
                    continue
        else:
            it = itertools.islice(self, times)
            for dot in it:
                try:
                    g = read_dot(dot)
                    nxGraph = NxGraph(g)
                    # 如果不是过大的图
                    if not nxGraph.is_super_graph():
                        # 从info node 中读取信息
                        full_name = nxGraph.get_full_method_name()
                        simple_name = nxGraph.get_simple_method_name()
                        locals = nxGraph.get_local_names()
                        params = nxGraph.get_param_names()
                        comment = nxGraph.get_comments()
                        # 去除info node并且relabel， 准备进行random walk
                        nxGraph.remove_info_node()
                        nxGraph.relabel_attrs()
                        # get random walk
                        random_walks = nxGraph.get_random_walks(mode=mode)
                        # info = (count, dot, simple_name, comment, locals, params, random_walks)
                        info = {"count": count, "dot": dot, "simple_name" :simple_name, "comment": comment,
                                "locals": locals, "params": params, "random_walks": random_walks}
                        DotFileWalker.write(output_path, full_name, info)
                    count += 1
                except Exception:
                    count += 1
                    errcount += 1
                    err_cases.append(dot)
                    DotFileWalker.excpetion_write(traceback.format_exc(), exc_path)
                    DotFileWalker.excpetion_write(dot, exc_path)
                    DotFileWalker.excpetion_write("------------------", exc_path)
                    continue
        return count, errcount

    @staticmethod
    def write(output_path, fullname, info):
        assert fullname is not None and len(fullname) > 0
        delim = Delimiter()
        with open(output_path + "/random_walks.txt", "a") as f:
            random_walks = info["random_walks"]
            random_walks_str = delim.walk_level.join(random_walks)
            random_walks_str = random_walks_str.replace("\n", "")
            random_walks_str = random_walks_str.replace("\r", "")
            f.write(fullname + delim.full_name_level + random_walks_str)
            f.write("\n")
        with open(output_path + "/local_names.txt", "a") as f:
            locals = info["locals"]
            random_walks = info["random_walks"]
            random_walks_str = delim.walk_level.join(random_walks)
            random_walks_str = random_walks_str.replace("\n", "")
            random_walks_str = random_walks_str.replace("\r", "")
            f.write(locals + delim.full_name_level + random_walks_str)
            f.write("\n")
        with open(output_path + "/param_names.txt", "a") as f:
            params = info["params"]
            random_walks = info["random_walks"]
            random_walks_str = delim.walk_level.join(random_walks)
            random_walks_str = random_walks_str.replace("\n", "")
            random_walks_str = random_walks_str.replace("\r", "")
            f.write(params + delim.full_name_level + random_walks_str)
            f.write("\n")
        with open(output_path + "/comment.txt", "a") as f:
            commment = info["comment"]
            random_walks = info["random_walks"]
            random_walks_str = delim.walk_level.join(random_walks)
            random_walks_str = random_walks_str.replace("\n", "")
            random_walks_str = random_walks_str.replace("\r", "")
            f.write(commment + delim.full_name_level + random_walks_str)
            f.write("\n")

    @staticmethod
    def clean_file_content(output_path):
        # open(output_path + "/id.txt", "w").close()
        # open(output_path + "/dot_path.txt", "w").close()
        # open(output_path + "/simple_name.txt", "w").close()
        open(output_path + "/random_walks.txt", "w").close()
        open(output_path + "/local_names.txt", "w").close()
        open(output_path + "/param_names.txt", "w").close()
        open(output_path + "/comment.txt", "w").close()

    @staticmethod
    def excpetion_write(exc, path):
        with open(path, "a") as f:
            f.write(exc)
            f.write("\n")