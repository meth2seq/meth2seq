from dataset.dot.DotFileWalker import DotFileWalker
from dataset.dot.NxGraph import NxGraph
from dataset.dot.SimpleJimple import SimpleJimple


path1 = "/home/qwe/disk1/zfy_lab/data/projects/dots"
output_path = "/home/qwe/disk1/zfy_lab/data/raw_samples/tmp"
exc_path = output_path + "/exceptions.txt"
paths = [path1]

# total dot file number:  188803
walker = DotFileWalker(paths)
print(walker.paths)
walker.read_dot_files()
print("total dot file number: ", len(walker.dot_files))
DotFileWalker.clean_file_content(output_path)
count, errcount= walker.process(output_path, exc_path)
print(count, errcount)