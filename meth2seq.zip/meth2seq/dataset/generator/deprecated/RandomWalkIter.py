import pandas as pd
from tqdm import tqdm
import itertools
import re
from dataset.preprocessing.core.cleansing import Trimming


class RandomWalkIter:
    def __init__(self, path):
        self.path = path

    def __iter__(self):
        with open(self.path, 'r') as f:
            for i, line in enumerate(f):
                if len(line) > 1:
                    name = line.split(':::')[0]
                    walks = line.split(':::')[1].split('$$$')[:-1]  # a$$$b$$$
                    yield name, walks

    def __len__(self):
        # option 1
        # return sum(1 for i in open(self.path, 'rb'))
        with open(self.path, 'r') as f:
            return sum(bl.count("\n") for bl in RandomWalkIter.blocks(f))

    def write_to_csv(self, out_path, max_walk_times=48, pad="<pad>"):
        it = RandomWalkIter(self.path)
        dic = {}
        dic.setdefault("method_name", [])
        for i in range(max_walk_times):
            dic.setdefault("walk_" + str(i), [])
        for t in tqdm(it, total=len(it)):
            name = t[0]
            walks = t[1]
            trim = Trimming()
            simplename = trim.trim(name)
            if simplename != "__trim__":
                dic['method_name'].append(simplename)
                times = len(walks) if len(walks) < max_walk_times else max_walk_times
                for i in range(max_walk_times):
                    if i in range(times):
                        dic['walk_' + str(i)].append(walks[i])
                    else:
                        dic['walk_' + str(i)].append(pad)
        df = pd.DataFrame(dic)
        df.to_csv(out_path)
        return df

    def write_toy_csv(self, out_path, max_walk_times=48, times=4, pad="<pad>"):
        it = RandomWalkIter(self.path)
        sit = itertools.islice(it, times)
        dic = {}
        dic.setdefault("method_name", [])
        for i in range(max_walk_times):
            dic.setdefault("walk_" + str(i), [])

        for t in sit:
            name = t[0]
            walks = t[1]
            trim = Trimming()
            simplename = trim.trim(name)
            if simplename != "__trim__":
                dic['method_name'].append(simplename)
                times = len(walks) if len(walks) < max_walk_times else max_walk_times
                for i in range(max_walk_times):
                    if i in range(times):
                        dic['walk_' + str(i)].append(walks[i])
                    else:
                        dic['walk_' + str(i)].append(pad)
        df = pd.DataFrame(dic)
        df.to_csv(out_path)
        return df, dic

    def write_to_csv(self, train_path, val_path, test_path, max_walk_times=48, pad="<pad>"):
        it = RandomWalkIter(self.path)
        train_dic = {}
        train_dic.setdefault("method_name", [])
        for i in range(max_walk_times):
            train_dic.setdefault("walk_" + str(i), [])

        val_dic = {}
        val_dic.setdefault("method_name", [])
        for i in range(max_walk_times):
            val_dic.setdefault("walk_" + str(i), [])

        test_dic = {}
        test_dic.setdefault("method_name", [])
        for i in range(max_walk_times):
            test_dic.setdefault("walk_" + str(i), [])

        trim = Trimming()
        total = len(it)
        count = 0
        train_num, val_num, test_num = RandomWalkIter.compute_split_ratio(total)
        for t in tqdm(it, total=total):
            if count < train_num:
                name = t[0]
                walks = t[1]
                simplename = trim.trim(name)
                if simplename != "__trim__":
                    train_dic['method_name'].append(simplename)
                    times = len(walks) if len(walks) < max_walk_times else max_walk_times
                    for i in range(max_walk_times):
                        if i in range(times):
                            train_dic['walk_' + str(i)].append(walks[i])
                        else:
                            train_dic['walk_' + str(i)].append(pad)
                count += 1
            elif train_num <= count < train_num + val_num:
                name = t[0]
                walks = t[1]
                simplename = trim.trim(name)
                if simplename != "__trim__":
                    val_dic['method_name'].append(simplename)
                    times = len(walks) if len(walks) < max_walk_times else max_walk_times
                    for i in range(max_walk_times):
                        if i in range(times):
                            val_dic['walk_' + str(i)].append(walks[i])
                        else:
                            val_dic['walk_' + str(i)].append(pad)
                count += 1
            else:
                name = t[0]
                walks = t[1]
                simplename = trim.trim(name)
                if simplename != "__trim__":
                    test_dic['method_name'].append(simplename)
                    times = len(walks) if len(walks) < max_walk_times else max_walk_times
                    for i in range(max_walk_times):
                        if i in range(times):
                            test_dic['walk_' + str(i)].append(walks[i])
                        else:
                            test_dic['walk_' + str(i)].append(pad)
                count += 1
        df1 = pd.DataFrame(train_dic)
        df2 = pd.DataFrame(val_dic)
        df3 = pd.DataFrame(test_dic)
        print(len(df1), len(df2), len(df3)) # 259997 37142 74286
        df1.to_csv(train_path)
        df2.to_csv(val_path)
        df3.to_csv(test_path)

    def write_to_csv_no_trim(self, train_path, val_path, test_path, max_walk_times=48, pad="<pad>"):
        it = RandomWalkIter(self.path)
        train_dic = {}
        train_dic.setdefault("method_name", [])
        for i in range(max_walk_times):
            train_dic.setdefault("walk_" + str(i), [])

        val_dic = {}
        val_dic.setdefault("method_name", [])
        for i in range(max_walk_times):
            val_dic.setdefault("walk_" + str(i), [])

        test_dic = {}
        test_dic.setdefault("method_name", [])
        for i in range(max_walk_times):
            test_dic.setdefault("walk_" + str(i), [])

        total = len(it)
        count = 0
        train_num, val_num, test_num = RandomWalkIter.compute_split_ratio(total)
        for t in tqdm(it, total=total):
            if count < train_num:
                name = t[0]
                walks = t[1]
                simplename = self.get_simple_name(name)
                train_dic['method_name'].append(simplename)
                times = len(walks) if len(walks) < max_walk_times else max_walk_times
                for i in range(max_walk_times):
                    if i in range(times):
                        train_dic['walk_' + str(i)].append(walks[i])
                    else:
                        train_dic['walk_' + str(i)].append(pad)
                count += 1
            elif train_num <= count < train_num + val_num:
                name = t[0]
                walks = t[1]
                simplename = self.get_simple_name(name)
                val_dic['method_name'].append(simplename)
                times = len(walks) if len(walks) < max_walk_times else max_walk_times
                for i in range(max_walk_times):
                    if i in range(times):
                        val_dic['walk_' + str(i)].append(walks[i])
                    else:
                        val_dic['walk_' + str(i)].append(pad)
                count += 1
            else:
                name = t[0]
                walks = t[1]
                simplename = self.get_simple_name(name)
                test_dic['method_name'].append(simplename)
                times = len(walks) if len(walks) < max_walk_times else max_walk_times
                for i in range(max_walk_times):
                    if i in range(times):
                        test_dic['walk_' + str(i)].append(walks[i])
                    else:
                        test_dic['walk_' + str(i)].append(pad)
                count += 1
        df1 = pd.DataFrame(train_dic)
        df2 = pd.DataFrame(val_dic)
        df3 = pd.DataFrame(test_dic)
        print(len(df1), len(df2), len(df3)) # 259997 37142 74286
        df1.to_csv(train_path)
        df2.to_csv(val_path)
        df3.to_csv(test_path)


    def compute_max_walk_time(self):
        it = RandomWalkIter(self.path)
        max = 0
        for t in it:
            l = len(t[1])
            print(l)
            if l > max:
                max = l
        return max

    def walk_time_stats(self):
        pass

    def walk_length_stats(self):
        pass

    @staticmethod
    def blocks(files, size=65536):
        while True:
            b = files.read(size)
            if not b: break
            yield b

    @staticmethod
    def compute_split_ratio(total):
        a = int(total * 0.7)
        b = int(total * 0.1)
        c = total - a - b
        return a, b, c

    @staticmethod
    def get_simple_name(fullname):
        s = re.sub(r'\(.*\)', '', fullname)
        simple = s.split('.')[-1]
        return simple
