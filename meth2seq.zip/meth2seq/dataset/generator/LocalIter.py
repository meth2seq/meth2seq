from dataset.generator.RandomWalkBasicIter import RandomWalkBasicIter
from dataset.dot.Delimiter import Delimiter
import random
import csv
import itertools
from tqdm import tqdm


class LocalIter(RandomWalkBasicIter):

    def __iter__(self):
        delim = Delimiter()
        with open(self.in_path + "local_names.txt", 'r') as f:
            lines = f.readlines()
            random.shuffle(lines)
            for line in lines:
                if len(line) > 1:
                    # print(line)
                    target = line.split(delim.full_name_level)[0]
                    walks = line.split(delim.full_name_level)[1].split(delim.walk_level)
                    if target != "NONE":
                        yield target, walks

    def __len__(self):
        # option 1
        # return sum(1 for i in open(self.path, 'rb'))
        with open(self.in_path + "random_walks.txt", 'r') as f:
            return sum(bl.count("\n") for bl in RandomWalkBasicIter.blocks(f))

    def dict_to_csv_toy(self, times, trim=False):
        fieldnames = self.get_field_names()
        with open(self.out_path + "toy.csv", "w") as csv_file:
            writer = csv.DictWriter(csv_file, fieldnames=fieldnames)
            writer.writeheader()
            # 开始遍历
            it = itertools.islice(self, times)
            for t in it:
                name = t[0]
                walks = t[1]
                simplename = LocalIter.get_simple_name(name)
                row = self.get_row(simplename, walks, None)
                writer.writerow(row)

    def dict_to_csv_total(self, trim=False):
        fieldnames = self.get_field_names()
        with open(self.out_path + "total.csv", "w") as csv_file:
            writer = csv.DictWriter(csv_file, fieldnames=fieldnames)
            writer.writeheader()
            # 开始遍历
            for t in tqdm(self):
                name = t[0]
                walks = t[1]
                simplename = LocalIter.get_simple_name(name)
                row = self.get_row(simplename, walks, None)
                writer.writerow(row)

    def dict_to_csv_split(self, trim=False):
        fieldnames = self.get_field_names()
        total = len(self)
        train_num, val_num, test_num = LocalIter.compute_split_ratio(total)
        with open(self.out_path + "train.csv", "w") as csv1:
            with open(self.out_path + "val.csv", "w") as csv2:
                with open(self.out_path + "test.csv", "w") as csv3:
                    writer1 = csv.DictWriter(csv1, fieldnames=fieldnames)
                    writer2 = csv.DictWriter(csv2, fieldnames=fieldnames)
                    writer3 = csv.DictWriter(csv3, fieldnames=fieldnames)
                    writer1.writeheader()
                    writer2.writeheader()
                    writer3.writeheader()
                    count = 0
                    for t in tqdm(self, total=total):
                        if count < train_num:
                            name = t[0]
                            walks = t[1]
                            simplename = LocalIter.get_simple_name(name)
                            row = self.get_row(simplename, walks, None)
                            writer1.writerow(row)
                        elif train_num <= count < train_num + val_num:
                            name = t[0]
                            walks = t[1]
                            simplename = LocalIter.get_simple_name(name)
                            row = self.get_row(simplename, walks, None)
                            writer2.writerow(row)
                        else:
                            name = t[0]
                            walks = t[1]
                            simplename = LocalIter.get_simple_name(name)
                            row = self.get_row(simplename, walks, None)
                            writer3.writerow(row)
                        count += 1

    def get_field_names(self):
        res = list()
        res.append("local_name");
        for i in range(self.max_walk_times):
            res.append("jimple_" + str(i))
            res.append("ir_" + str(i))
            res.append("trans_" + str(i))
        res.append("comment")
        return res

    def get_row(self, simple_name, walks, comment):
        delim = Delimiter()
        row = dict()
        row["local_name"] = simple_name
        times = len(walks) if len(walks) < self.max_walk_times else self.max_walk_times
        for i in range(self.max_walk_times):
            if i in range(times):
                assert len(walks[i]) > 0
                walk_list = walks[i].split(delim.node_level)
                jimple_list = [LocalIter.get_node_attr(t, "jimple") for t in walk_list]
                jimple_str = ":: ".join(jimple_list).strip("\"")
                ir_list = [LocalIter.get_node_attr(t, "ir") for t in walk_list]
                ir_str = ":: ".join(ir_list).strip("\"")
                trans_list = [LocalIter.get_node_attr(t, "trans") for t in walk_list]
                trans_str = ":: ".join(trans_list).strip("\"")
                row["jimple_"+str(i)] = jimple_str.replace("\n", "")
                row["ir_" + str(i)] = ir_str.replace("\n", "")
                row["trans_" + str(i)] = trans_str.replace("\n", "")
            else:
                row["jimple_" + str(i)] = self.pad
                row["ir_" + str(i)] = self.pad
                row["trans_" + str(i)] = self.pad
        row["comment"] = self.pad
        return row

    @staticmethod
    def label_clean(input):
        return input.strip("\"")
        # return re.sub(r'[^a-zA-Z\s]', ' ', input)
        # return re.sub(r'[\[\]\"\'\\]', "", input)

    @staticmethod
    def get_simple_name(fullname):
        res = []
        locals_with_type = [t for t in fullname.split(", ") if t != '']
        variables = [t.split(":::")[1] for t in locals_with_type]
        types = [t.split(":::")[0] for t in locals_with_type]
        for var in variables:
            if var.find("stack") == -1:
                res.append(var)
        return ", ".join(res)
