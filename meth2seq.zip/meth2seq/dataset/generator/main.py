from dataset.generator.NamingIter import NamingIter
import csv
import itertools
from dataset.dot.Delimiter import Delimiter
from dataset.generator.LocalIter import LocalIter
from dataset.generator.CommentIter import CommentIter


"""run"""
# in_path = "/home/qwe/disk1/data_SoC/files_IR/"
# output = "/home/qwe/disk1/data_SoC/files_IR/"
# it = IRIter(in_path, output)
# # 187933
# it.process(split=True)

"""test"""
in_path = "/home/qwe/disk1/zfy_lab/data/raw_samples/tmp/"
output = "/home/qwe/disk1/zfy_lab/data/raw_samples/tmp/"
it = CommentIter(in_path, output)
it.process(times=10, split=False)