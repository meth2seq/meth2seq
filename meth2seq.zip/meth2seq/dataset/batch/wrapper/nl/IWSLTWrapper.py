from dataset.batch.mask.Mask import Mask
from dataset.batch.wrapper.randomwalk.BasicWrapper import BasicWrapper


class IWSLTWrapper(BasicWrapper):
    def __init__(self, dl, x_var, y_var, padding_idx):
        """
        in the IWSLT dataset x and y only have one field.
        :param dl:
        :param x_var: "src"
        :param y_var: "trg"
        """
        self.dl = dl
        self.x_var = x_var
        self.y_var = y_var
        self.padding_idx = padding_idx

    def __iter__(self):
        for batch in self.dl:
            x = getattr(batch, self.x_var).transpose(0,1)  # [length, batch_size]
            y = getattr(batch, self.y_var).transpose(0,1)  # [length]
            # print(x.shape, y.shape)

            # if self.y_vars is None:  # we will concatenate y into a single tensor
            #     y = torch.cat([getattr(batch, feat).unsqueeze(1) for feat in self.y_vars], dim=1).float()
            # else:
            #     y = torch.zeros((1))

            yield Mask(x, y, self.padding_idx)

    def __len__(self):
        return len(self.dl)