import torch
from dataset.batch.mask.Mask import Mask
from op.tensor.TensorOp import TensorOp
from dataset.batch.mask.RandomWalkMask import RandomWalkMask
from .BasicWrapper import BasicWrapper
from op.torchtext.FieldUtils import TorchTextField


class MultiContextWrapper(BasicWrapper):

    def __init__(self, iter, y_fields, padding_idx, walk_times=48, walk_length=11,
                 device=torch.device("cuda:0")):
        super().__init__(iter, y_fields, padding_idx, walk_times, walk_length, device)
        self.x_fields = TorchTextField.get_all_walk_fields(walk_times)