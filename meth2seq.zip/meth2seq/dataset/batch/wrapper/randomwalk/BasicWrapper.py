"""
batch wrapper provides a more convenient way to iterate over a torchtext.data.Batch object.
"""
import torch
from op.tensor.TensorOp import TensorOp
from dataset.batch.mask.RandomWalkMask import RandomWalkMask


class BasicWrapper:

    def __init__(self, iter, y_fields, padding_idx, walk_times=48, walk_length=11, device=torch.device("cuda:0")):
        """
        init method
        :param iterator: any object that extends the torchtext.data.Iterator
        :param x_fields:
        :param y_fileds:
        """
        self.dl = iter
        self.x_fields = None
        self.y_fields = y_fields
        self.padding_idx = padding_idx
        self.walk_length = walk_length
        self.device = device

    def __iter__(self):
        """
        一共有三种不同来源的contexts， 分别是jimple，IR(trans)，和comment
        这里采用最简单的方法，直接将不同来源的contexts线性连接
        """
        for batch in self.dl:
            walks = []
            assert len(self.x_fields) == 144
            for x_fields in self.x_fields:
                walk = getattr(batch, x_fields)
                if walk.shape[0] < self.walk_length:
                    padwalk = TensorOp.tpad(walk, dim=0, n=abs(self.walk_length - walk.shape[0]),
                                            fillvalue=self.padding_idx)
                else:
                    padwalk = torch.index_select(walk, 0,
                                                 torch.tensor([i for i in range(self.walk_length)]).to(self.device))
                padwalk = padwalk.unsqueeze(1)
                walks.append(padwalk)
            x = torch.cat([t for t in walks], dim=1)
            x = x.transpose(0, -1)

            y = getattr(batch, self.y_fields)
            y = y.transpose(0, -1)

            yield RandomWalkMask(x, y, pad=1)

    def __len__(self):
        """
        return the length of the iterator
        :return:
        """
        return len(self.dl)
