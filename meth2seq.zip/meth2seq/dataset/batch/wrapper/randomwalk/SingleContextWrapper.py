import torch
import sys
sys.path.insert(0, "/tmp/pycharm_project_521/")
from dataset.batch.mask.Mask import Mask
from op.tensor.TensorOp import TensorOp
from dataset.batch.mask.RandomWalkMask import RandomWalkMask
from .BasicWrapper import BasicWrapper


class SingleContextWrapper(BasicWrapper):

    def __init__(self, iter, y_fields, padding_idx, walk_times=48,walk_length=11, device=torch.device("cuda:0")):
        super().__init__(iter, y_fields, padding_idx, walk_times, walk_length, device)
        x_fields = []
        for i in range(walk_times):
            x_fields.append("walk_" + str(i))
        self.x_fields = x_fields
