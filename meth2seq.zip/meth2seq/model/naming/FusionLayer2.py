import torch
import torch.nn as nn
import torch.nn.functional as F


class FusionLayer2(nn.Module):
    """"use FFN to fusion contexts"""
    def __init__(self, d_in, d_ff, d_out, dropout=0.1):
        super(FusionLayer2, self).__init__()
        self.w_1 = nn.Linear(d_in, d_ff)
        self.w_2 = nn.Linear(d_ff, d_out)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x):
        x = x.reshape(x.size(0), x.size(1), -1)  # which makes d_in = 11 * 256 = 2816
        return self.w_2(self.dropout(F.relu(self.w_1(x))))
