### data
- random shuffle
- add min count : 8
- no trim

### model
- initial

### training 
- learning rate : 0.0001

### evaluating
- set max prediction length : 5

```angular2
{'accuracy': 0.30420353982300885, 'precision': 0.581112378056575, 'recall': 0.550691508047928, 'f1': 0.5570147636783773}

```

```angular2
{'accuracy': 0.3272262168141593, 'precision': 0.6001025520385335, 'recall': 0.5348117272964787, 'f1': 0.5551293103399074}

```