from dataset.preprocessing.wrapper.JimpleFieldWrapper import JimpleFieldWrapper
from dataset.preprocessing.wrapper.MethodNameFieldWrapper import MethodNameFieldWrapper
import torch
from torchtext.data import Field
from torchtext.data import TabularDataset
from torchtext.data import BucketIterator
from dataset.batch.wrapper.randomwalk.SingleContextWrapper import SingleContextWrapper
from training.loss.wrapper.KLDivLossWithLabelSmoothing import KLDivLossWithLabelSmoothing
from training.loss.compute.SimpleLossCompute import SimpleLossCompute
from training.opt.OptimWrapper import OptimWrapper
from model.naming.Model import Model
from time import time

# preliminary
DATA_PATH = "/home/qwe/disk1/data_SoC/files/ptdata/"
MAX_WALK_TIMES = 48
EPOCHS = 10
SAVE_PATH = "/home/qwe/zfy_lab/fytorch/output/trained/ck_build_train/"
BATCH_SIZE = 64


# device
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
print("current device is :", device)

start = time()
JIMPLE = Field(tokenize=JimpleFieldWrapper.tokenize, preprocessing=JimpleFieldWrapper.preprocess,
               init_token="<s>", eos_token="<eos>")
NAME = Field(tokenize=MethodNameFieldWrapper.tokenize, preprocessing=MethodNameFieldWrapper.preprocess,
             init_token="<s>", eos_token="<eos>")

fields = []
fields.append(("id", None))
fields.append(("method_name", NAME))
for i in range(MAX_WALK_TIMES):
    name = "walk_" + str(i)
    fields.append((name, JIMPLE))

# build dataset
train, val, test = TabularDataset.splits(
    path=DATA_PATH, train="train.csv", validation="val.csv", test="test.csv", format="csv",
    skip_header=True, fields=fields
)


# build vocab
JIMPLE.build_vocab(train, val, test)
NAME.build_vocab(train, val, test)


# create iterator
def sort_key(x):
    total_length = 0
    name = getattr(x, "method_name")  # this happens when preprocessing is done, so type is list
    total_length += len(name)
    return total_length


train_iter, val_iter, test_iter = BucketIterator.splits(
    datasets=(train, val, test),
    batch_sizes=(BATCH_SIZE, BATCH_SIZE, BATCH_SIZE),
    sort_key=sort_key,
    sort_within_batch=False,
    device=device,
    repeat=False
)

# wrap the iterator
train_wrapper = SingleContextWrapper(train_iter, "method_name", padding_idx=NAME.vocab.stoi["<pad>"], walk_times=MAX_WALK_TIMES)
val_wrapper = SingleContextWrapper(val_iter, "method_name", padding_idx=NAME.vocab.stoi["<pad>"], walk_times=MAX_WALK_TIMES)
test_wrapper = SingleContextWrapper(test_iter, "method_name", padding_idx=NAME.vocab.stoi["<pad>"], walk_times=MAX_WALK_TIMES)


"""model"""
model = Model.make_model(len(JIMPLE.vocab), len(NAME.vocab), N=6)
model.cuda()
criterion = KLDivLossWithLabelSmoothing(len(NAME.vocab), padding_idx=0, smoothing=0.1)
criterion.cuda()
opt = OptimWrapper.get_std_opt(model)
train_loss_compute = SimpleLossCompute(model.generator, criterion, opt)
val_loss_compute = SimpleLossCompute(model.generator, criterion, None)

"""eval"""
checkpoint = torch.load(SAVE_PATH)
model.load_state_dict(checkpoint["state_dict"])
train_loss_compute.opt.optimizer.load_state_dict(checkpoint["optim_dict"])
model.eval()

from evaluating.run.evaluate import eval3
result = eval3(model, val_wrapper, NAME.vocab.stoi["<s>"], NAME.vocab.stoi["<eos>"], NAME.vocab.stoi["<pad>"], NAME.vocab.stoi["<unk>"])
print(result)