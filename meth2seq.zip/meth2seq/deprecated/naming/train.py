from torchtext.data import Field
from torchtext.data import TabularDataset
from torchtext.data import BucketIterator
from dataset.preprocessing.jimple.JimpleFieldWrapper import JimpleFieldWrapper
from dataset.preprocessing.method_name.NameFieldWrapper import NameFieldWrapper
from dataset.batch.wrapper.randomwalk.SingleContextWrapper import SingleContextWrapper
from training.loss.wrapper.KLDivLossWithLabelSmoothing import KLDivLossWithLabelSmoothing
from training.loss.compute.SimpleLossCompute import SimpleLossCompute
from training.opt.OptimWrapper import OptimWrapper
from model.naming.Model import Model
from training.run.RunEpoch import RunEpoch
from evaluating.run.evaluate import evaluate
from op.model.utils import *


# preliminary
DATA_PATH = "/home/qwe/disk1/data_SoC/files/"
MAX_WALK_TIMES = 50
EPOCHS = 10
SAVE_PATH = "/home/qwe/zfy_lab/fytorch/trained/"
BATCH_SIZE = 64
MODEL_DIR = "/home/qwe/zfy_lab/fytorch/out/"


# device
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
print("current device is :", device)

# define field
JIMPLE = Field(tokenize=JimpleFieldWrapper.tokenize, preprocessing=JimpleFieldWrapper.preprocess,
               init_token="<s>", eos_token="<eos>")
NAME = Field(tokenize=NameFieldWrapper.tokenize, preprocessing=NameFieldWrapper.preprocess,
             init_token="<s>", eos_token="<eos>")

fields = []
fields.append(("id", None))
fields.append(("method_name", NAME))
for i in range(MAX_WALK_TIMES):
    name = "walk_" + str(i)
    fields.append((name, JIMPLE))

# build dataset
train, val, test = TabularDataset.splits(
    path=DATA_PATH, train="train.csv", validation="val.csv", test="test.csv", format="csv",
    skip_header=True, fields=fields
)

# build vocab
JIMPLE.build_vocab(train, val, test)
NAME.build_vocab(train, val, test)


# create iterator
def sort_key(x):
    total_length = 0
    name = getattr(x, "method_name")  # this happens when preprocessing is done, so type is list
    total_length += len(name)
    # for i in range(MAX_WALK_TIMES):
    #     walk = getattr(x, "walk_" + str(i))
    #     total_length += len(walk)  # walk is also list of tokens now
    return total_length


train_iter, val_iter = BucketIterator.splits(
    datasets=(train, val),
    batch_sizes=(BATCH_SIZE, BATCH_SIZE),
    device=device,
    sort_key=sort_key,
    sort_within_batch=False,
    repeat=False
)

test_iter = BucketIterator(
    dataset=test,
    batch_size=BATCH_SIZE,
    device=device,
    sort=False,
    sort_within_batch=False,
    repeat=False
)

# wrap the iterator
train_wrapper = SingleContextWrapper(train_iter, "method_name", padding_idx=1, walk_times=MAX_WALK_TIMES)
val_wrapper = SingleContextWrapper(val_iter, "method_name", padding_idx=1, walk_times=MAX_WALK_TIMES)
test_wrapper = SingleContextWrapper(test_iter, "method_name", padding_idx=1, walk_times=MAX_WALK_TIMES)


"""model"""
model = Model.make_model(len(JIMPLE.vocab), len(NAME.vocab), N=6)
model.cuda()
criterion = KLDivLossWithLabelSmoothing(len(NAME.vocab), padding_idx=0, smoothing=0.1)
criterion.cuda()
opt = OptimWrapper.get_std_opt(model)
train_loss_compute = SimpleLossCompute(model.generator, criterion, opt)
val_loss_compute = SimpleLossCompute(model.generator, criterion, None)

"""train"""
best_val_acc = 0.0

for epoch in range(EPOCHS):
    # Run one epoch
    logging.info("Epoch {}/{}".format(epoch + 1, EPOCHS))

    RunEpoch.train(model, train_loss_compute, train_wrapper,
          metrics)

    # Evaluate for one epoch on validation set
    val_metrics = evaluate(
        model, val_loss_compute, val_wrapper, metrics)

    val_acc = val_metrics['f1']
    is_best = val_acc >= best_val_acc

    # Save weights
    save_checkpoint({'epoch': epoch + 1,
                       'state_dict': model.state_dict(),
                       'optim_dict': train_loss_compute.opt.state_dict()},
                      is_best=is_best,
                      checkpoint=MODEL_DIR)

    # If best_eval, best_save_path
    if is_best:
        logging.info("- Found new best accuracy")
        best_val_acc = val_acc

        # Save best val metrics in a json file in the model directory
        best_json_path = os.path.join(
            MODEL_DIR, "metrics_val_best_weights.json")
        save_dict_to_json(val_metrics, best_json_path)

    # Save latest val metrics in a json file in the model directory
    last_json_path = os.path.join(
        MODEL_DIR, "metrics_val_last_weights.json")
    save_dict_to_json(val_metrics, last_json_path)


