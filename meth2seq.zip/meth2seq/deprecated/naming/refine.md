### TODO
- add min count   (✔️)
- random shuffle (✔️)
- best accuracy (✔️)
- set max prediction length (✔️)
- beam search (✔️)
- padding_idx in loss compute
- no trim


### data
- random shuffle
- add min count
- no trim

### model (可重复)


### training （可重复）
- best accuracy
- padding_idx in loss compute
- learning rate

### evaluating （可重复）
- set max prediction length 
- beam search