import re


class Jimple:

    def __init__(self, jimple):
        self.info = 'jimple to natural language'
        self.jimple = jimple


    def get_simple_jimple(self):
        jimple = self.jimple
        if jimple.find('JAssignStmt') != -1:
            simple = self.solve_assign()
        elif jimple.find('IdentityStmt') != -1:
            simple = self.solve_idntity()
        elif jimple.find('AbstractDefinitionStmt') != -1:
            simple = self.solve_abstract_def()
        elif jimple.find('JEnterMonitorStmt') != -1:
            simple = self.solve_enter_monitor()
        elif jimple.find('JExitMonitorStmt') != -1:
            simple = self.solve_exit_monitor()
        elif jimple.find('JReturn') != -1:
            simple = self.solve_return()
        elif jimple.find('JThrowStmt') != -1:
            simple = self.solve_throw()
        elif jimple.find('JLookupSwitchStmt') != -1:
            simple = self.solve_lookup_switch()
        elif jimple.find('JTableSwitchStmt') != -1:
            simple = self.solve_table_switch()
        elif jimple.find('JBreakpointStmt') != -1:
            simple = self.solve_break()
        elif jimple.find('JGotoStmt') != -1:
            simple = self.solve_goto()
        elif jimple.find('JIfStmt') != -1:
            simple = self.solve_if()
        elif jimple.find('JInvokeStmt') != -1:
            simple = self.solve_invoke()
        elif jimple.find('JNopStmt') != -1:
            simple = self.solve_nop()
        elif jimple.find('JRetStmt') != -1:
            simple = self.solve_ret()
        elif jimple.find('JRetVoidStmt') != -1:
            simple = self.solve_ret_void()
        elif jimple.find('PlaceholderStmt') != -1:
            simple = self.solve_placeholder()
        elif jimple.find('AbstractStmt') != -1:
            simple = self.solve_abstract()
        else:
            simple = self.solve_exception()
        return simple

    def solve_assign(self):
        simple = None
        if self.jimple.find('JAssignStmt') != -1 and self.jimple.find('interfaceinvoke') != -1:
            simple = solve_assign_interfaceinvoke(self.jimple)
        elif self.jimple.find('JAssignStmt') != -1 and self.jimple.find('staticinvoke') != -1:
            simple = solve_assign_static_invoke(self.jimple)
        elif self.jimple.find('JAssignStmt') != -1 and self.jimple.find('virtualinvoke') != -1:
            simple = solve_virtual_invoke(self.jimple)
        elif self.jimple.find('JAssignStmt') != -1 and self.jimple.find('specialinvoke') != -1:
            simple = solve_assign_special_invoke(self.jimple)
        elif self.jimple.find('JAssignStmt') != -1 and self.jimple.find('dynamicinvoke') != -1:
            simple = solve_assign_dynamic_invoke(self.jimple)
        elif self.jimple.find('JAssignStmt') != -1 and \
            self.jimple.find('dynamicinvoke') == -1 and self.jimple.find('specialinvoke') == -1 \
            and self.jimple.find('virtualinvoke') == -1 and self.jimple.find('staticinvoke') == -1 and self.jimple.find('interfaceinvoke') == -1:
                simple = solve_assign_others(self.jimple)
        else:
            print('exception in assign')

        assert simple is not None
        return simple

    def solve_invoke(self):
        simple = None
        if self.jimple.find('JInvokeStmt_interfaceinvoke') != -1:
            simple = solve_interface_invoke(self.jimple)
        elif self.jimple.find('JInvokeStmt_staticinvoke') != -1:
            simple = solve_static_invoke(self.jimple)
        elif self.jimple.find('JInvokeStmt_virtualinvoke') != -1:
            simple = solve_virtual_invoke(self.jimple)
        elif self.jimple.find('JInvokeStmt_dynamicinvoke') != -1:
            simple = solve_dynamic_invoke(self.jimple)
        elif self.jimple.find('JInvokeStmt_specialinvoke') != -1:
            simple = solve_special_invoke(self.jimple)
        else:
            simple = 'exception in invoke'
        assert simple is not None
        return simple

    def solve_idntity(self):
        simple = None
        simple = solve_identities(self.jimple)
        assert simple is not None
        return simple

    def solve_abstract_def(self):
        return 'AbstractDefinitionStmt'

    def solve_enter_monitor(self):
        return 'JEnterMonitorStmt'

    def solve_exit_monitor(self):
        return 'JExitMonitorStmt'

    def solve_return(self):
        simple = None
        simple = solve_returns(self.jimple)
        assert simple is not None
        return simple

    def solve_throw(self):
        simple = None
        simple = solve_throws(self.jimple)
        assert simple is not None
        return simple

    def solve_lookup_switch(self):
        return 'JLookupSwitchStmt'

    def solve_table_switch(self):
        return 'JTableSwitchStmt'

    def solve_break(self):
        return 'JBreakpointStmt'

    def solve_goto(self):
        simple = None
        simple = solve_gotos(self.jimple)
        assert simple is not None
        return simple

    def solve_if(self):
        simple = None
        simple = solve_ifs(self.jimple)
        assert simple is not None
        return simple

    def solve_nop(self):
        return 'JNopStmt'

    def solve_ret(self):
        return 'JRetStmt'

    def solve_ret_void(self):
        return 'JRetVoidStmt'

    def solve_placeholder(self):
        return 'PlaceholderStmt'

    def solve_abstract(self):
        return 'AbstractStmt'

    def solve_exception(self):
        if len(self.jimple.split('.')) > 1:
            return '3rd'
        else:
            return self.jimple


def solve_interface_invoke(input):
    """
    example:
    "JInvokeStmt_interfaceinvoke $r3.<org.apache.ibatis.session.SqlSession: void select(java.lang.String,org.apache.ibatis.session.ResultHandler)>(r1, r2)"
    """
    pattern = re.compile(r'(.*)\s(.*)\.<(.*):\s(.*)\s(.*)\((.*)\)>\((.*)\)')
    # pattern = re.compile(r'(.*)_(.*)\s(.*)\.<(.*):\s(.*)\s(.*)\((.*)')
    res = re.search(pattern, input)
    assert res != None
    jtype = res.group(1)
    basic_type = jtype.split('_')[0]
    special_type = jtype.split('_')[1]
    caller = res.group(2)
    belong = res.group(3)
    ret_type = res.group(4)
    md_name = res.group(5)
    param_types = res.group(6).split(',')
    param_feeds= res.group(7)
    simple = basic_type + ': ' + ret_type + ' ' + md_name + '('
    for i in range(len(param_types) - 1):
        simple += param_types[i] + ' '
    i = len(param_types) - 1
    simple += param_types[i] + ')'
    return simple

def solve_static_invoke(input):
    """
    example
    "JInvokeStmt_staticinvoke <org.junit.jupiter.api.Assertions: java.lang.Object fail()>()"
    """
    pattern = re.compile(r'(.*)\s<(.*):\s(.*)\s(.*)\((.*)\)>\((.*)\)')
    res = re.search(pattern, input)
    assert res != None
    jtype = res.group(1)
    basic_type = jtype.split('_')[0]
    special_type = jtype.split('_')[1]
    belong = res.group(2)
    ret_type = res.group(3)
    md_name = res.group(4)
    param_types = res.group(5).split(',')
    param_feeds = res.group(6)
    simple = basic_type + ': ' + ret_type + ' ' + md_name + '('
    for i in range(len(param_types) - 1):
        simple += param_types[i] + ' '
    i = len(param_types) - 1
    simple += param_types[i] + ')'
    return simple

def solve_virtual_invoke(input):
    """
        example:
        "JInvokeStmt_virtualinvoke r1.<org.springframework.context.support.GenericApplicationContext: void registerBeanDefinition(java.lang.String,org.springframework.beans.factory.config.BeanDefinition)>(\"sqlSessionTemplate\", $r4)"
        """
    pattern = re.compile(r'(.*)\s(.*)\.<(.*):\s(.*)\s(.*)\((.*)\)>\((.*)\)')
    # pattern = re.compile(r'(.*)_(.*)\s(.*)\.<(.*):\s(.*)\s(.*)\((.*)')
    res = re.search(pattern, input)
    assert res != None
    jtype = res.group(1)
    basic_type = jtype.split('_')[0]
    special_type = jtype.split('_')[1]
    caller = res.group(2)
    belong = res.group(3)
    ret_type = res.group(4)
    md_name = res.group(5)
    param_types = res.group(6).split(',')
    param_feeds = res.group(7)
    simple = basic_type + ': ' + ret_type + ' ' + md_name + '('
    for i in range(len(param_types) - 1):
        simple += param_types[i] + ' '
    i = len(param_types) - 1
    simple += param_types[i] + ')'
    return simple

def solve_dynamic_invoke(input):
    """
    seems dynamic invoke dont exist without an assignment
    """
    return 'JInvokeStmt_dynamicinvoke'


def solve_special_invoke(input):
    """
    example:
    "JInvokeStmt_specialinvoke $r3.<org.mybatis.spring.mapper.MapperFactoryBean: void <init>()>()"
    """
    pattern = re.compile(r'(.*)\s(.*)\.<(.*):\s(.*)\s(.*)\((.*)\)>\((.*)\)')
    # pattern = re.compile(r'(.*)_(.*)\s(.*)\.<(.*):\s(.*)\s(.*)\((.*)')
    res = re.search(pattern, input)
    assert res != None
    jtype = res.group(1)
    basic_type = jtype.split('_')[0]
    special_type = jtype.split('_')[1]
    caller = res.group(2)
    belong = res.group(3)
    ret_type = res.group(4)
    md_name = res.group(5)
    param_types = res.group(6).split(',')
    param_feeds = res.group(7)
    simple = basic_type + ': ' + ret_type + ' ' + md_name + '('
    for i in range(len(param_types) - 1):
        simple += param_types[i] + ' '
    i = len(param_types) - 1
    simple += param_types[i] + ')'
    return simple

def solve_assign_interfaceinvoke(input):
    """
    example:
    "JAssignStmt_$r3 = interfaceinvoke $r2.<org.apache.ibatis.session.SqlSession: java.lang.Object selectOne(java.lang.String,java.lang.Object)>(\"org.mybatis.spring.sample.mapper.UserMapper.getUser\", r1)"
    :return:
    """
    pattern = re.compile(r'(.*)_(.*)\s=\s(.*)\s(.*)\.<(.*):\s(.*)\s(.*)\((.*)\)>\((.*)\)')
    res = re.search(pattern,input)
    assert res != None
    basic_type = res.group(1)
    assign_target = res.group(2)
    special_type = res.group(3)
    caller = res.group(4)
    belong = res.group(5)
    ret_type = res.group(6)
    md_name = res.group(7)
    param_types = res.group(8).split(',')
    param_feeds = res.group(9)
    simple = basic_type + ': ' + ret_type + ' ' + md_name + '('
    for i in range(len(param_types) - 1):
        simple += param_types[i] + ' '
    i = len(param_types) - 1
    simple += param_types[i] + ')'
    return simple

def solve_assign_static_invoke(input):
    """
    "JAssignStmt_$r6 = staticinvoke <org.mybatis.spring.sample.config.SampleJobConfig: org.springframework.core.convert.converter.Converter createItemToParameterMapConverter(java.lang.String,java.time.LocalDateTime)>(\"batch_java_config_user\", $r5)"
    """
    pattern = re.compile(r'(.*)_(.*)\s=\s(.*)\s<(.*):\s(.*)\s(.*)\((.*)\)>\((.*)\)')
    res = re.search(pattern, input)
    assert res != None
    basic_type = res.group(1)
    assign_target = res.group(2)
    special_type = res.group(3)
    caller = ''
    belong = res.group(4)
    ret_type = res.group(5)
    md_name = res.group(6)
    param_types = res.group(7).split(',')
    param_feeds = res.group(8)
    simple = basic_type + ': ' + ret_type + ' ' + md_name + '('
    for i in range(len(param_types) - 1):
        simple += param_types[i] + ' '
    i = len(param_types) - 1
    simple += param_types[i] + ')'
    return simple

def solve_assign_virtual_invoke(input):
    pattern = re.compile(r'(.*)_(.*)\s=\s(.*)\s(.*)\.<(.*):\s(.*)\s(.*)\((.*)\)>\((.*)\)')
    res = re.search(pattern, input)
    assert res != None
    basic_type = res.group(1)
    assign_target = res.group(2)
    special_type = res.group(3)
    caller = res.group(4)
    belong = res.group(5)
    ret_type = res.group(6)
    md_name = res.group(7)
    param_types = res.group(8).split(',')
    param_feeds = res.group(9)
    simple = basic_type + ': ' + ret_type + ' ' + md_name + '('
    for i in range(len(param_types) - 1):
        simple += param_types[i] + ' '
    i = len(param_types) - 1
    simple += param_types[i] + ')'
    return simple

def solve_assign_special_invoke(input):
    pattern = re.compile(r'(.*)_(.*)\s=\s(.*)\s(.*)\.<(.*):\s(.*)\s(.*)\((.*)\)>\((.*)\)')
    res = re.search(pattern, input)
    assert res != None
    basic_type = res.group(1)
    assign_target = res.group(2)
    special_type = res.group(3)
    caller = res.group(4)
    belong = res.group(5)
    ret_type = res.group(6)
    md_name = res.group(7)
    param_types = res.group(8).split(',')
    param_feeds = res.group(9)
    simple = basic_type + ': ' + ret_type + ' ' + md_name + '('
    for i in range(len(param_types) - 1):
        simple += param_types[i] + ' '
    i = len(param_types) - 1
    simple += param_types[i] + ')'
    return simple

def solve_assign_dynamic_invoke(input):
    pattern = re.compile(r'(.*)_(.*)\s=\s(.*)\"\s<(.*),\shandle:\s<(.*):\s(.*)\s(.*)\((.*)\)>,\s(.*)\((.*)\)(.*)\)')
    res = re.search(pattern, input)
    assert res != None
    basic_type = res.group(1)
    assign_target = res.group(2)
    special = res.group(3)
    caller = ''
    special1 = special.split(' ')[0]
    special2 = special.split(' ')[1].replace('\"', '').replace('\\', '')
    lambda_stuff = res.group(4)
    belong = res.group(5)
    ret_type = res.group(6)
    md_name = res.group(7)
    param_types = res.group(8).split(',')
    simple = basic_type + ': ' + ret_type + ' ' + md_name + '('
    for i in range(len(param_types) - 1):
        simple += param_types[i] + ' '
    i = len(param_types) - 1
    simple += param_types[i] + ')'
    return simple

def solve_assign_others(input):
    left = input.split(' = ')[0]
    right = str(input.split(' = ')[1]).replace('\n', '')
    basic_type = left.split('_')[0]
    target = left.split('_')[1]
    target_ = re.match(r'(.*)\.<(.*):\s(.*)\s(.*)>', target)
    simple = None


    if re.match(r'(.*)\.<(.*):\s(.*)\s([^\(\)]*)>', right) != None:
        simple = 'object assign'


    elif re.match(r'\$*r[0-9]*', right) != None and len(right.split()) == 1:
        # variable assign
        simple = 'variable assign'

    elif re.match(r'(.*)\s([\+\-\*\/])\s(.*)', right) != None:
        # var op assign
        simple = 'variable operation assign'

    elif re.match(r'new\s(.*)', right) != None:
        # new obj assign
        simple = 'new obj assign'

    elif re.match(r'newarray\s\((.*)\)\[(.*)\]', right) != None:
        # new array assign
        simple = 'new array assign'
    elif re.match(r'(.*)\sinstanceof\s(.*)', right) != None:
        # instanceof assign
        simple = 'instanceof assign'
    elif re.match(r'\"(.*)\"', right) != None and re.match(r'\"([0-9]+)\"', right) == None:
        # string value assign
        simple = 'string value assign'
    elif re.match(r'\((.*)\)\s\$*r[0-9]+', right) != None:
        # type cast assign
        simple = 'type cast assign'
    elif re.match(r'lengthof\s(.*)', right) != None or re.match(r'\"*([0-9]+)\"*', right) != None:
        # num value assign
        simple = 'num value assign'
    else:
        simple = 'other assign'
    assert simple != None
    return simple

def solve_identities(input):
    simple = 'JIdentityStmt'
    return simple

def solve_returns(input):
    if input.find('JReturnVoidStmt') != -1:
        simple = 'JReturnVoidStmt'
    else:
        simple = 'JReturnStmt'
    return simple

def solve_throws(input):
    simple = 'JThrowStmt'
    return simple

def solve_gotos(input):
    return 'JGotoStmt'

def solve_ifs(input):
    return 'JIfStmt'






