from deprecated.dataset import DotFileWalker
import sys
sys.path.append("/Users/zfy/fytorch/dataset/deprecated")


path1 = "/home/qwe/disk1/dots/projects1"
path2 = "/home/qwe/disk1/dots/projects2"
path3 = "/home/qwe/disk1/dots/projects3"
test_path = "/home/qwe/disk1/dots/projects1/spring-cloud"
exc_path = "/home/qwe/disk1/dots/" + "exceptions.txt"
output_path = "/home/qwe/disk1/data_SoC/files_IR"

walker = DotFileWalker(test_path)
print("total deprecated file number: ", len(walker.dot_files))
walker.get_node_info(exc_path)
walker.output_to_file(output_path)