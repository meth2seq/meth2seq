from .graph import Graph

class RandomWalk:

    def __init__(self):
        pass

    @staticmethod
    def generate_random_walk(g, walk_mode=0):
        """

        :param g: networkx graph
        :param walk_mode: 0: find by adjacent / 1: find along the edge / 2: find along edge & with edge
        :return:
        """
        random_walks = []
        graph = Graph(g)
        l = len(graph.nodes())
        walk_length = int(l / 2 + 1)
        walk_times = 8 * l
        walk = None
        for i in range(walk_times):
            if walk_mode == 0:
                walk = graph.random_walk_adjacent(walk_length, simple_jimple=True)
            elif walk_mode == 1:
                walk = graph.random_walk_graph(walk_length, simple_jimple=True)
            else:
                walk = graph.random_walk_graph_edge_sampled(walk_length, simple_jimple=True)
            random_walks.append(walk)
        return random_walks