import torch
from time import time
from argparse import ArgumentParser
from dataset.preprocessing.wrapper.JimpleFieldWrapper import JimpleFieldWrapper
from dataset.preprocessing.wrapper.MethodNameFieldWrapper import MethodNameFieldWrapper
from torchtext.data import Field
from torchtext.data import TabularDataset
from deprecated.hyperparam.HyperParam import HyperParam
from op.io.io import save_dataset
from dataset.dot.DotFileWalker import DotFileWalker
from dataset.generator.NamingIter import NamingIter


if __name__ == "__main__":
    parser = ArgumentParser()
    # path params
    parser.add_argument("-i", "--input", dest="input_path")
    parser.add_argument("-s", "--sample", dest="sample_path")
    parser.add_argument("-c", "--csv", dest="csv_path")
    parser.add_argument("-o", "--output", dest="output_path")

    parser.add_argument("-wt", "--walk-times", dest="max_walk_times")

    args = parser.parse_args()

    # parse dot files
    walker = DotFileWalker(args.input_path)
    walker.read_dot_files()
    print("total dot file number: ", len(walker.dot_files))
    DotFileWalker.clean_file_content(args.sample_path)
    count, errcount= walker.process(args.sample_path, args.sample_path)
    print(count, errcount)

    # generate learning sequences
    it = NamingIter(args.csv_path, args.csv_path)
    it.process(split=True)

    # preprocess(tokenize & clean)
    SRC = Field(tokenize=JimpleFieldWrapper.tokenize, preprocessing=JimpleFieldWrapper.preprocess,
                   init_token="<s>", eos_token="<eos>")
    NAME = Field(tokenize=MethodNameFieldWrapper.tokenize, preprocessing=MethodNameFieldWrapper.preprocess,
                 init_token="<s>", eos_token="<eos>")

    fields = list()
    fields.append(("method_name", NAME))
    for i in range(args.max_walk_times):
        fields.append(("jimple_"+str(i), SRC))
        fields.append(("ir_"+str(i), SRC))
        fields.append(("trans_"+str(i), SRC))
    fields.append("comment", SRC)

    # build dataset
    train, val, test = TabularDataset.splits(
        path=args.csv_path, train="train.csv", validation="val.csv", test="test.csv", format="csv",
        skip_header=True, fields=fields
    )

    # build vocab
    SRC.build_vocab(train, val, test)
    NAME.build_vocab(train, val, test)

    # save dataset
    save_dataset(train, args.output_path + "train.csv")
    save_dataset(val, args.output_path + "val.csv")
    save_dataset(test, args.output_path + "test.csv")

    # save vocab
    vocab = {
        "src": SRC.vocab,
        "name": NAME.vocab
    }

    torch.save(vocab, args.output_path + "vocab.pt")
