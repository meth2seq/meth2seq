import os
import torch
from torchtext.data import Field
from torchtext.data import TabularDataset
from torchtext.data import BucketIterator
from dataset.batch.wrapper.randomwalk.MultiContextWrapper import MultiContextWrapper
from model.naming.Model import Model
from training.loss.wrapper.KLDivLossWithLabelSmoothing import KLDivLossWithLabelSmoothing
from training.opt.OptimWrapper import OptimWrapper
from training.loss.compute.SimpleLossCompute import SimpleLossCompute
from training.run.RunEpoch import RunEpoch
from evaluating.run.evaluate import Eval
from op.model.utils import save_checkpoint, save_dict_to_json, metrics_dict_msg, save_value_to_json


class Model:

    def __init__(self, args):
        # goal
        self.goal = args.goal

        # path related params
        self.data_path = args.data_path
        self.model_save_path = args.model_save_path
        self.load_path = args.load_path

        # training params
        self.num_epoch = args.num_epoch
        self.save_every_epoch = args.save_every_epoch
        self.batch_size = args.batch_size
        self.test_batch_size = args.test_batch_size
        self.patience = args.patience
        self.max_walk_times = args.max_walk_times
        self.max_walk_length = args.max_walk_length
        self.device = args.device

    def train(self):
        tokenize = lambda x: x.split(',')
        SRC = Field(tokenize=tokenize, init_token="<s>", eos_token="<eos>")
        NAME = Field(tokenize=tokenize, init_token="<s>", eos_token="<eos>")

        fields = list()
        fields.append(("id", None))
        fields.append(("method_name", NAME))
        for i in range(self.max_walk_times):
            fields.append(("jimple_" + str(i), SRC))
            fields.append(("ir_" + str(i), SRC))
            fields.append(("trans_" + str(i), SRC))
        fields.append("comment", SRC)

        # load dataset
        train, val, test = TabularDataset.splits(
            path=self.data_path, train="train.csv", validation="val.csv", test="test.csv", format="csv",
            skip_header=True, fields=fields
        )

        # load vocab
        ck = torch.load(self.load_path + "vocab.pt")
        vocab_src = ck["src"]
        vocab_name = ck["name"]
        SRC.vocab = vocab_src
        NAME.vocab = vocab_name

        # create iterator
        def sort_key(x):
            total_length = 0
            name = getattr(x, "method_name")  # this happens when preprocessing is done, so type is list
            total_length += len(name)
            return total_length

        train_iter, val_iter, test_iter = BucketIterator.splits(
            datasets=(train, val, test),
            batch_sizes=(self.batch_size, self.batch_size, self.test_batch_size),
            sort_key=sort_key,
            sort_within_batch=False,
            device=self.device,
            repeat=False
        )

        # wrap the iterator
        train_wrapper = MultiContextWrapper(train_iter, "method_name", padding_idx=NAME.vocab.stoi["<pad>"],
                                            walk_times=self.max_walk_times)
        val_wrapper = MultiContextWrapper(val_iter, "method_name", padding_idx=NAME.vocab.stoi["<pad>"],
                                          walk_times=self.max_walk_times)
        test_wrapper = MultiContextWrapper(test_iter, "method_name", padding_idx=NAME.vocab.stoi["<pad>"],
                                           walk_times=self.max_walk_times)

        """model"""
        model = Model.make_model(len(SRC.vocab), len(NAME.vocab), N=6)
        model.cuda()
        criterion = KLDivLossWithLabelSmoothing(len(NAME.vocab), padding_idx=0, smoothing=0.1)
        criterion.cuda()
        opt = OptimWrapper.get_std_opt(model)
        train_loss_compute = SimpleLossCompute(model.generator, criterion, opt)
        val_loss_compute = SimpleLossCompute(model.generator, criterion, None)

        """train"""
        best_f1 = 0.0
        no_new_best_count = 0
        for epoch in range(self.num_epoch):
            print("EPOCH: " + str(epoch))
            model.train()
            loss = RunEpoch.run_epoch(train_wrapper, model, train_loss_compute)
            print("loss: %f" % loss)
            model.eval()
            val_eval = Eval(model, val_wrapper, NAME.vocab.stoi["<s>"],
                                NAME.vocab.stoi["<eos>"], NAME.vocab.stoi["<pad>"], NAME.vocab.stoi["<unk>"])
            val_metrics = val_eval.process()
            test_eval = Eval(model, test_wrapper, NAME.vocab.stoi["<s>"],
                                NAME.vocab.stoi["<eos>"], NAME.vocab.stoi["<pad>"], NAME.vocab.stoi["<unk>"])
            test_metrics = test_eval.process()
            print("val metric: " + metrics_dict_msg(val_metrics))
            print("test metric: " + metrics_dict_msg(test_metrics))
            val_f1 = val_metrics["f1"]

            is_best = val_f1 > best_f1
            checkpoint = {
                epoch: epoch,
                "state_dict": model.state_dict(),
                "optim_dict": train_loss_compute.opt.optimizer.state_dict()
            }
            save_checkpoint(checkpoint, is_best, self.model_save_path)

            if is_best:
                "find new best f1"
                best_f1 = val_f1

                best_json_path = os.path.join(
                    self.model_save_path, "metrics_val_best_weights.json")

                save_dict_to_json(val_metrics, best_json_path)
            else:
                no_new_best_count += 1

            if no_new_best_count > self.patience:
                print("5 epochs without new best, end training")
                break

    def evaluate(self):
        tokenize = lambda x: x.split(',')
        SRC = Field(tokenize=tokenize, init_token="<s>", eos_token="<eos>")
        NAME = Field(tokenize=tokenize, init_token="<s>", eos_token="<eos>")

        fields = list()
        fields.append(("id", None))
        fields.append(("method_name", NAME))
        for i in range(self.max_walk_times):
            name = "walk_" + str(i)
            fields.append((name, SRC))
        fields.append("comment", SRC)

        # load dataset
        train, val, test = TabularDataset.splits(
            path=self.data_path, train="train.csv", validation="val.csv", test="test.csv", format="csv",
            skip_header=True, fields=fields
        )

        # load vocab
        ck = torch.load(self.data_path + "vocab.pt")
        vocab_src = ck["src"]
        vocab_name = ck["name"]
        SRC.vocab = vocab_src
        NAME.vocab = vocab_name

        # create iterator
        def sort_key(x):
            total_length = 0
            name = getattr(x, "method_name")  # this happens when preprocessing is done, so type is list
            total_length += len(name)
            return total_length

        train_iter, val_iter, test_iter = BucketIterator.splits(
            datasets=(train, val, test),
            batch_sizes=(self.batch_size, self.batch_size, self.test_batch_size),
            sort_key=sort_key,
            sort_within_batch=False,
            device=self.device,
            repeat=False
        )

        # wrap the iterator
        train_wrapper = MultiContextWrapper(train_iter, "method_name", padding_idx=NAME.vocab.stoi["<pad>"],
                                                 walk_times=self.max_walk_times)
        val_wrapper = MultiContextWrapper(val_iter, "method_name", padding_idx=NAME.vocab.stoi["<pad>"],
                                               walk_times=self.max_walk_times)
        test_wrapper = MultiContextWrapper(test_iter, "method_name", padding_idx=NAME.vocab.stoi["<pad>"],
                                                walk_times=self.max_walk_times)

        """model"""
        model = Model.make_model(len(SRC.vocab), len(NAME.vocab), N=6)
        model.cuda()
        criterion = KLDivLossWithLabelSmoothing(len(NAME.vocab), padding_idx=NAME.vocab.stoi["<pad>"], smoothing=0.1)
        criterion.cuda()
        opt = OptimWrapper.get_std_opt(model)
        train_loss_compute = SimpleLossCompute(model.generator, criterion, opt)
        val_loss_compute = SimpleLossCompute(model.generator, criterion, None)

        """eval"""
        checkpoint = torch.load(self.load_path + "best.pth.tar")
        model.load_state_dict(checkpoint["state_dict"])
        train_loss_compute.opt.optimizer.load_state_dict(checkpoint["optim_dict"])
        model.eval()

        test_eval = Eval(model, test_wrapper, NAME.vocab.stoi["<s>"], NAME.vocab.stoi["<eos>"], NAME.vocab.stoi["<pad>"],
                        NAME.vocab.stoi["<unk>"])
        metrics = test_eval.process()
        print(metrics)