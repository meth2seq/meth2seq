DATASET_NAME=my_dataset
INPUT=${DATASET_NAME}.dot_files
SAMPLE_PATH={$DATASET_NAME}.samples
CSV_PATH=${DATASET_NAME}.csvs
OUTPUT_PATH=${DATASET_NAME}.output
MAX_WALK_TIMES=48

mkdir -p data
mkdir -p data/${DATASET_NAME}

echo "start preprocessing"
python preprocess.py --input INPUT --sample SAMPLE_PATH --csv CSV_PATH --output OUTPUT_PATH --walk-times MAX_WALK_TIMES
echo "preprocess finished"