import torch
from argparse import ArgumentParser
from .Model import Model


if __name__ == "__main__" :
    parser = ArgumentParser()
    # set goal
    parser.add_argument("-g", "--goal", help="set process goal", default="train")

    # path related params
    parser.add_argument("-d", "--data", dest="data_path", help="path to input data")
    parser.add_argument("-s", "--save", dest="save_path", help="model save path")
    # parser.add_argument("-l", "--load", dest="load_path", help="data load path")

    # training params
    parser.add_argument("-ep", "--epoch", dest="epoch_num",default=40)
    parser.add_argument("-se", "--save-every-epoch", dest="save_interval", default=1)
    parser.add_argument("-b", "--batch", dest="batch_size", default=64)
    parser.add_argument("-tb", "--test-batch", dest="test_batch_size",default=64)
    parser.add_argument("-p", "--patience", default=10)
    parser.add_argument("-wt", "--walk-times", dest="max_walk_times", default=48)
    parser.add_argument("-wl", "--walk-length", dest="max_walk_length", default=11)
    parser.add_argument("-dev", "--device", default=torch.device("cuda:0" if torch.cuda.is_available() else "cpu"))

    args = parser.parse_args()
    model = Model(args)


    if model.goal is "train":
        model.train()

    if model.goal is "evaluate":
        model.evaluate()