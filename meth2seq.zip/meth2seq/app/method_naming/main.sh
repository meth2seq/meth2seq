DATASET_NAME=my_dataset
DATA_PATH=data/${DATASET_NAME}/output
SAVE_MODEL_PATH=data/$DATASET_NAME/model

echo "start running"
python main.py --data DATA_PATH --save SAVE_MODEL_PATH
echo "running finished"