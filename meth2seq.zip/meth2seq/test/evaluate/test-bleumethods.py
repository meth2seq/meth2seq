from evaluating.metrics.Bleu import Bleu


hyp1 = ['It', 'is', 'a', 'guide', 'to', 'action', 'which',
        'ensures', 'that', 'the', 'military', 'always',
        'obeys', 'the', 'commands', 'of', 'the', 'party']
hyp1_str = " ".join(hyp1)
ref1a = ['It', 'is', 'a', 'guide', 'to', 'action', 'that',
         'ensures', 'that', 'the', 'military', 'will', 'forever',
         'heed', 'Party', 'commands']
ref1a_str = " ".join(ref1a)
ref1b = ['It', 'is', 'the', 'guiding', 'principle', 'which',
         'guarantees', 'the', 'military', 'forces', 'always',
         'being', 'under', 'the', 'command', 'of', 'the', 'Party']
ref1b_str = " ".join(ref1b)
ref1c = ['It', 'is', 'the', 'practical', 'guide', 'for', 'the',
         'army', 'always', 'to', 'heed', 'the', 'directions',
         'of', 'the', 'party']
ref1c_str = " ".join(ref1c)
hyp2 = ['he', 'read', 'the', 'book', 'because', 'he', 'was',
        'interested', 'in', 'world', 'history']
hyp2_str = " ".join(hyp2)
ref2a = ['he', 'was', 'interested', 'in', 'world', 'history',
         'because', 'he', 'read', 'the', 'book']
ref2a_str = " ".join(ref2a)
assert type(ref1a_str) is str
assert type(ref2a_str) is str
assert type(ref1b_str) is str
assert type(ref1c_str) is str
assert type(hyp1_str) is str
assert type(hyp2_str) is str

list_of_refs1 = [[ref1a, ref1b, ref1c], [ref2a]]
preds = [hyp1, hyp2]
print(Bleu.nltk_corpus_bleu(list_of_refs1, preds))

list_of_refs2 =[[ref1a_str, ref2a_str],
                [ref1b_str, ref2a_str],
                [ref1c_str, ref2a_str]]
preds2 = [hyp1_str, hyp2_str]
# print(preds2)
# print(list_of_refs2)
print(Bleu.sacre_corpus_bleu(list_of_refs2, preds2))