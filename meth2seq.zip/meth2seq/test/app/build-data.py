import torch
from time import time
from dataset.preprocessing.wrapper.JimpleFieldWrapper import JimpleFieldWrapper
from dataset.preprocessing.wrapper.CommentFieldWrapper import CommentFiledWrapper
from torchtext.data import Field
from torchtext.data import TabularDataset
from deprecated.hyperparam.HyperParam import HyperParam
from op.io.io import save_dataset3

start = time()

# preliminary
BASE = "/home/qwe/disk1/zfy_lab/data/raw_samples/tmp/"
param = HyperParam(BASE)
MAX_WALK_TIMES = param.MAX_WALK_TIMES
device = param.device
DATA_PATH1 = param.DATA_PATH1
DATA_PATH2 = param.DATA_PATH2
MODEL_PATH = param.MODEL_PATH

print("read csv file from: %s" % DATA_PATH1)
print("generate csv_ file and vocab file to: %s" % DATA_PATH2)
print("current model saving path: %s" % MODEL_PATH)
print("current device is :", device)

SRC = Field(tokenize=JimpleFieldWrapper.tokenize, preprocessing=JimpleFieldWrapper.preprocess,
               init_token="<s>", eos_token="<eos>")
NAME = Field(tokenize=CommentFiledWrapper.tokenize, preprocessing=CommentFiledWrapper.preprocess,
             init_token="<s>", eos_token="<eos>")

fields = list()
fields.append(("comment", NAME))
for i in range(MAX_WALK_TIMES):
    fields.append(("jimple_"+str(i), SRC))
    fields.append(("ir_"+str(i), SRC))
    fields.append(("trans_"+str(i), SRC))

# build dataset
train, val, test = TabularDataset.splits(
    path=DATA_PATH1, train="train.csv", validation="val.csv", test="test.csv", format="csv",
    skip_header=True, fields=fields
)

# for i in range(len(train)):
#     example = train[i]
#     comment = getattr(example, "comment")
#     print(comment)

# build vocab
SRC.build_vocab(train, val, test)
NAME.build_vocab(train, val, test)

# save dataset
save_dataset3(train, DATA_PATH2 + "train1_.csv")
save_dataset3(val, DATA_PATH2 + "val1_.csv")
save_dataset3(test, DATA_PATH2 + "test1_.csv")

# save vocab
vocab = {
    "src": SRC.vocab,
    "name": NAME.vocab
}

torch.save(vocab, DATA_PATH2 + "vocab1.pt")
print("build data time: %f" % (time() - start))
