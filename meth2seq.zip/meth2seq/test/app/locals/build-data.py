import torch
from time import time
from dataset.preprocessing.wrapper.JimpleFieldWrapper import JimpleFieldWrapper
from dataset.preprocessing.wrapper.LocalFieldWrapper import LocalFieldWrapper
from torchtext.data import Field
from torchtext.data import TabularDataset
from op.io.io import save_dataset2
from deprecated.hyperparam.HyperParam import HyperParam

start = time()

# preliminary
INPUT_BASE = "/home/qwe/disk1/data_SoC/files_IR/local_name/"
OUTPUT_BASE = "/home/qwe/disk1/zfy_lab/fytorch_data/local_name/"
param = HyperParam(INPUT_BASE, OUTPUT_BASE)
MAX_WALK_TIMES = param.MAX_WALK_TIMES
device = param.device
SAVE_DATA_PATH = param.get_save_params_single_fields()[0]
SAVE_MODEL_PATH = param.get_save_params_single_fields()[1]
INPUT_BASE = param.INPUT_BASE

print("current data saving path: %s" % SAVE_DATA_PATH)
print("current model saving path: %s" % SAVE_MODEL_PATH)
print("current device is :", device)

SRC = Field(tokenize=JimpleFieldWrapper.tokenize, preprocessing=JimpleFieldWrapper.preprocess,
               init_token="<s>", eos_token="<eos>")
NAME = Field(tokenize=LocalFieldWrapper.tokenize, preprocessing=LocalFieldWrapper.preprocess,
             init_token="<s>", eos_token="<eos>")

fields = list()
fields.append(("local_name", NAME))
for i in range(MAX_WALK_TIMES):
    fields.append(("jimple_"+str(i), SRC))
    fields.append(("ir_"+str(i), SRC))
    fields.append(("trans_"+str(i), SRC))
fields.append(("comment", SRC))

# build dataset
train, val, test = TabularDataset.splits(
    path=INPUT_BASE, train="train.csv", validation="val.csv", test="test.csv", format="csv",
    skip_header=True, fields=fields
)

# build vocab
SRC.build_vocab(train, val, test)
NAME.build_vocab(train, val, test)

# save dataset
save_dataset2(train, SAVE_DATA_PATH + "train_.csv")
save_dataset2(val, SAVE_DATA_PATH + "val_.csv")
save_dataset2(test, SAVE_DATA_PATH + "test_.csv")

# save vocab
vocab = {
    "src": SRC.vocab,
    "name": NAME.vocab
}

torch.save(vocab, SAVE_DATA_PATH + "vocab.pt")
print("build data time: %f" % (time() - start))
