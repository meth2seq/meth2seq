import torch
from time import time
from torchtext.data import Field
from torchtext.data import TabularDataset
from torchtext.data import BucketIterator
from deprecated.hyperparam.HyperParam import HyperParam
from dataset.batch.wrapper.randomwalk.MultiContextWrapper import MultiContextWrapper
from model.naming.Model import Model
from training.loss.wrapper.KLDivLossWithLabelSmoothing import KLDivLossWithLabelSmoothing
from training.opt.OptimWrapper import OptimWrapper
from training.loss.compute.SimpleLossCompute import SimpleLossCompute

# device
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
print("current device is :", device)

# preliminary
INPUT_BASE = "/home/qwe/disk1/zfy_lab/data/raw_samples/tmp/"
OUTPUT_BASE = "/home/qwe/disk1/zfy_lab/data/raw_samples/tmp/"
param = HyperParam(INPUT_BASE, OUTPUT_BASE)
DATA_LOAD_PATH = param.SAVE_DATA_BASE
MAX_WALK_TIMES = param.MAX_WALK_TIMES
param.set_training_params(epochs=20)
EPOCHS = param.EPOCHS
BATCH_SIZE = param.BATCH_SIZE
SAVE_MODEL_PATH = param.SAVE_MODEL_BASE
print("data loading path: %s" % DATA_LOAD_PATH)
print("save model to path %s " % SAVE_MODEL_PATH)

tokenize = lambda x: x.split(',')
SRC = Field(tokenize=tokenize, init_token="<s>", eos_token="<eos>")
NAME = Field(tokenize=tokenize, init_token="<s>", eos_token="<eos>")

fields = list()
fields.append(("id", None))
fields.append(("comment", NAME))
for i in range(MAX_WALK_TIMES):
    fields.append(("jimple_" + str(i), SRC))
    fields.append(("ir_" + str(i), SRC))
    fields.append(("trans_" + str(i), SRC))

t = time()
# load dataset
train, val, test = TabularDataset.splits(
    path=DATA_LOAD_PATH, train="train1_.csv", validation="val1_.csv", test="test1_.csv", format="csv",
    skip_header=True, fields=fields
)

# load vocab
ck = torch.load(param.SAVE_DATA_BASE + "vocab1.pt")
vocab_src = ck["src"]
vocab_name = ck["name"]
SRC.vocab = vocab_src
NAME.vocab = vocab_name

# create iterator
def sort_key(x):
    total_length = 0
    name = getattr(x, "comment")  # this happens when preprocessing is done, so type is list
    total_length += len(name)
    return total_length


train_iter, val_iter, test_iter = BucketIterator.splits(
    datasets=(train, val, test),
    batch_sizes=(BATCH_SIZE, BATCH_SIZE, BATCH_SIZE),
    sort_key=sort_key,
    sort_within_batch=False,
    device=device,
    repeat=False
)

# wrap the iterator
train_wrapper = MultiContextWrapper(train_iter, "comment", padding_idx=NAME.vocab.stoi["<pad>"], walk_times=MAX_WALK_TIMES)
val_wrapper = MultiContextWrapper(val_iter, "comment", padding_idx=NAME.vocab.stoi["<pad>"], walk_times=MAX_WALK_TIMES)
test_wrapper = MultiContextWrapper(test_iter, "comment", padding_idx=NAME.vocab.stoi["<pad>"], walk_times=MAX_WALK_TIMES)

"""model"""
model = Model.make_model(len(SRC.vocab), len(NAME.vocab), N=6)
model.cuda()
criterion = KLDivLossWithLabelSmoothing(len(NAME.vocab), padding_idx=0, smoothing=0.1)
criterion.cuda()
opt = OptimWrapper.get_std_opt(model)
train_loss_compute = SimpleLossCompute(model.generator, criterion, opt)
val_loss_compute = SimpleLossCompute(model.generator, criterion, None)

"""eval"""
checkpoint = torch.load(SAVE_MODEL_PATH + "best.pth.tar")
model.load_state_dict(checkpoint["state_dict"])
train_loss_compute.opt.optimizer.load_state_dict(checkpoint["optim_dict"])
model.eval()

from evaluating.metrics.Bleu import Bleu
bleu = Bleu(model, test_wrapper, NAME.vocab.stoi["<s>"], NAME.vocab.stoi["<eos>"], NAME.vocab.stoi["<pad>"], NAME.vocab.stoi["<unk>"])
# bleu.write1("/home/qwe/disk1/zfy_lab/fyrunning/tmp_files")
b1, b2 = bleu.process("/home/qwe/disk1/zfy_lab/fyrunning/tmp_files")
print(b1)
print(b2)