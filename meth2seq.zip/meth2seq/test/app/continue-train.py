import os
import torch
import json
from time import time
from torchtext.data import Field
from torchtext.data import TabularDataset
from torchtext.data import BucketIterator
from deprecated.hyperparam.HyperParam import HyperParam
from dataset.batch.wrapper.randomwalk.MultiContextWrapper import MultiContextWrapper
from model.naming.Model import Model
from training.loss.wrapper.KLDivLossWithLabelSmoothing import KLDivLossWithLabelSmoothing
from training.opt.OptimWrapper import OptimWrapper
from training.loss.compute.SimpleLossCompute import SimpleLossCompute
from training.run.RunEpoch import RunEpoch
from evaluating.metrics.Bleu import Bleu
from op.model.utils import save_checkpoint, save_value_to_json


# device
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
print("current device is :", device)

# preliminary
INPUT_BASE = "/home/qwe/disk1/zfy_lab/data/raw_samples/tmp/"
OUTPUT_BASE = "/home/qwe/disk1/zfy_lab/data/raw_samples/tmp/"
param = HyperParam(INPUT_BASE, OUTPUT_BASE)
DATA_LOAD_PATH = param.SAVE_DATA_BASE
MAX_WALK_TIMES = param.MAX_WALK_TIMES
param.set_training_params(epochs=40)
EPOCHS = param.EPOCHS
BATCH_SIZE = param.BATCH_SIZE
SAVE_MODEL_PATH = param.SAVE_MODEL_BASE
print("data loading path: %s" % DATA_LOAD_PATH)
print("save model to path %s " % SAVE_MODEL_PATH)

tokenize = lambda x: x.split(',')
SRC = Field(tokenize=tokenize, init_token="<s>", eos_token="<eos>")
NAME = Field(tokenize=tokenize, init_token="<s>", eos_token="<eos>")

fields = list()
fields.append(("id", None))
fields.append(("comment", NAME))
for i in range(MAX_WALK_TIMES):
    fields.append(("jimple_" + str(i), SRC))
    fields.append(("ir_" + str(i), SRC))
    fields.append(("trans_" + str(i), SRC))

t = time()
# load dataset
train, val, test = TabularDataset.splits(
    path=DATA_LOAD_PATH, train="train1_.csv", validation="val1_.csv", test="test1_.csv", format="csv",
    skip_header=True, fields=fields
)

# load vocab
ck = torch.load(param.SAVE_DATA_BASE + "vocab1.pt")
vocab_src = ck["src"]
vocab_name = ck["name"]
SRC.vocab = vocab_src
NAME.vocab = vocab_name

# create iterator
def sort_key(x):
    total_length = 0
    name = getattr(x, "comment")  # this happens when preprocessing is done, so type is list
    total_length += len(name)
    return total_length


train_iter, val_iter, test_iter = BucketIterator.splits(
    datasets=(train, val, test),
    batch_sizes=(BATCH_SIZE, BATCH_SIZE, BATCH_SIZE),
    sort_key=sort_key,
    sort_within_batch=False,
    device=device,
    repeat=False
)

# wrap the iterator
train_wrapper = MultiContextWrapper(train_iter, "comment", padding_idx=NAME.vocab.stoi["<pad>"], walk_times=MAX_WALK_TIMES)
val_wrapper = MultiContextWrapper(val_iter, "comment", padding_idx=NAME.vocab.stoi["<pad>"], walk_times=MAX_WALK_TIMES)
test_wrapper = MultiContextWrapper(test_iter, "comment", padding_idx=NAME.vocab.stoi["<pad>"], walk_times=MAX_WALK_TIMES)

"""model"""
model = Model.make_model(len(SRC.vocab), len(NAME.vocab), N=6)
model.cuda()
criterion = KLDivLossWithLabelSmoothing(len(NAME.vocab), padding_idx=0, smoothing=0.1)
criterion.cuda()
opt = OptimWrapper.get_std_opt(model)
train_loss_compute = SimpleLossCompute(model.generator, criterion, opt)
val_loss_compute = SimpleLossCompute(model.generator, criterion, None)

"""load check point"""
checkpoint = torch.load(SAVE_MODEL_PATH + "best.pth.tar")
model.load_state_dict(checkpoint["state_dict"])
train_loss_compute.opt.optimizer.load_state_dict(checkpoint["optim_dict"])

"""load old best metric"""
with open(SAVE_MODEL_PATH + "/metrics_val_best_weights.json") as f:
    data = json.load(f)
best_bleu = data["bleu"]
no_new_best_count = 0

curr_epoch = checkpoint["epoch"]
print("current epoch: ", curr_epoch)
print("current best: ", best_bleu)
"""train"""
for epoch in range(curr_epoch,EPOCHS):
    print("EPOCH: " + str(epoch))
    model.train()
    loss = RunEpoch.run_epoch(train_wrapper, model, train_loss_compute)
    print("loss: %f" % loss)
    model.eval()
    # val_metrics = eval3(model, val_wrapper, NAME.vocab.stoi["<s>"],
    #                     NAME.vocab.stoi["<eos>"], NAME.vocab.stoi["<pad>"], NAME.vocab.stoi["<unk>"])
    # test_metrics = eval3(model, test_wrapper, NAME.vocab.stoi["<s>"],
    #                     NAME.vocab.stoi["<eos>"], NAME.vocab.stoi["<pad>"], NAME.vocab.stoi["<unk>"])
    # print("val metric: " + metrics_dict_msg(val_metrics))
    # print("test metric: " + metrics_dict_msg(test_metrics))
    # val_f1 = val_metrics["f1"]
    bleu1 = Bleu(model, val_wrapper, NAME.vocab.stoi["<s>"],
                 NAME.vocab.stoi["<eos>"], NAME.vocab.stoi["<pad>"], NAME.vocab.stoi["<unk>"])
    path = "/home/qwe/disk1/zfy_lab/fyrunning/tmp_files/val"
    bleu1.write2(path)
    val_bleu_score = bleu1.process(path)

    bleu2 = Bleu(model, test_wrapper, NAME.vocab.stoi["<s>"],
                 NAME.vocab.stoi["<eos>"], NAME.vocab.stoi["<pad>"], NAME.vocab.stoi["<unk>"])
    path = "/home/qwe/disk1/zfy_lab/fyrunning/tmp_files/test"
    bleu2.write2(path)
    test_bleu_score = bleu2.process(path)
    print("val bleu: ", val_bleu_score)
    print("test bleu: ", test_bleu_score)

    is_best = val_bleu_score > best_bleu
    checkpoint = {
        "epoch": epoch,
        "state_dict": model.state_dict(),
        "optim_dict": train_loss_compute.opt.optimizer.state_dict()
    }
    save_checkpoint(checkpoint, is_best, SAVE_MODEL_PATH)

    if is_best:
        print("find new best f1")
        best_bleu = val_bleu_score

        best_json_path = os.path.join(
            SAVE_MODEL_PATH, "metrics_val_best_weights.json")

        save_value_to_json(val_bleu_score, best_json_path)
    else:
        no_new_best_count += 1
    # FIXME bug when start at a very high point
    if no_new_best_count > 5:
        print("5 epochs without new best, end training")
        # break

print("time cost: ", time() - t)