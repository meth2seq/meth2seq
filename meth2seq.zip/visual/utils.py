import seaborn


def draw(data, x, y, ax):
    seaborn.heatmap(data,
                    xticklabels=x, square=True, yticklabels=y, vmin=0.0, vmax=1.0,
                    cbar=False, ax=ax)

def get_name_from_ids(ids, vocab):
    name = []
    filtered = []
    for id in ids:
        if id not in [0,1,2,3]:
            filtered.append(id)
    for j in filtered:
        s = vocab.vocab.itos[j]
        name.append(s)
    return name

def get_ids_from_name(name, vocab):
    ids = []
    for s in name:
        id = vocab.vocab.stoi[s]
        ids.append(id)
    return ids

def filter_impossible(tokens):
    res = []
    for t in tokens:
        if t not in [0, 1, 2, 3]:
            res.append(t)
    return tokens

def get_example(iter, name):
    for batch in iter:
        batch_size = batch.src.size(0)
        for i in range(batch_size):
            tgtname = filter_impossible(batch.tgt_y[i:i + 1])

