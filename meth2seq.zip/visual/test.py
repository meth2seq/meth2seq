import os
import torch
from time import time
from torchtext.data import Field
from torchtext.data import Dataset, TabularDataset
from torchtext.data import Iterator, BucketIterator
from common.parameter.Params import Params
from dataset.batch.wrapper.NamingWrapperMultiple import NamingWrapperMultiple
from model.naming.Model import Model
from training.loss.wrapper.KLDivLossWithLabelSmoothing import KLDivLossWithLabelSmoothing
from training.opt.OptimWrapper import OptimWrapper
from training.loss.compute.SimpleLossCompute import SimpleLossCompute
from training.run.RunEpoch import RunEpoch
from evaluating.run.evaluate import eval2, eval3
from common.model.utils import save_checkpoint, save_dict_to_json, metrics_dict_msg
import matplotlib.pyplot as plt
from visual.utils import draw, get_name_from_ids, get_ids_from_name
from evaluating.decode.Decode import Decode

# device
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
print("current device is :", device)

# preliminary
param = Params()
DATA_LOAD_PATH = "/home/qwe/disk1/zfy_lab/fytorch_data/method_name_new/data/"
MAX_WALK_TIMES = param.MAX_WALK_TIMES
param.set_training_params(epochs=20)
EPOCHS = param.EPOCHS
BATCH_SIZE = param.BATCH_SIZE
SAVE_MODEL_PATH = "/home/qwe/disk1/zfy_lab/fytorch_data/method_name_new/model/"
print("data loading path: %s" % DATA_LOAD_PATH)
print("save model to path %s " % SAVE_MODEL_PATH)

tokenize = lambda x: x.split(',')
SRC = Field(tokenize=tokenize, init_token="<s>", eos_token="<eos>")
NAME = Field(tokenize=tokenize, init_token="<s>", eos_token="<eos>")

fields = list()
fields.append(("id", None))
fields.append(("method_name", NAME))
for i in range(MAX_WALK_TIMES):
    fields.append(("jimple_" + str(i), SRC))
    fields.append(("ir_" + str(i), SRC))
    fields.append(("trans_" + str(i), SRC))
fields.append(("comment", SRC))

t = time()
# load dataset
train, val, test = TabularDataset.splits(
    path=DATA_LOAD_PATH, train="train_.csv", validation="val_.csv", test="test_.csv", format="csv",
    skip_header=True, fields=fields
)

# load vocab
ck = torch.load(SAVE_MODEL_PATH + "vocab.pt")
vocab_src = ck["src"]
vocab_name = ck["name"]
SRC.vocab = vocab_src
NAME.vocab = vocab_name
print(NAME.vocab.stoi.__len__())

# create iterator
def sort_key(x):
    total_length = 0
    name = getattr(x, "method_name")  # this happens when preprocessing is done, so type is list
    total_length += len(name)
    return total_length


train_iter, val_iter, test_iter = BucketIterator.splits(
    datasets=(train, val, test),
    batch_sizes=(BATCH_SIZE, BATCH_SIZE, BATCH_SIZE),
    sort_key=sort_key,
    sort_within_batch=False,
    device=device,
    repeat=False
)

# wrap the iterator
train_wrapper = NamingWrapperMultiple(train_iter, "method_name", padding_idx=NAME.vocab.stoi["<pad>"], walk_times=MAX_WALK_TIMES)
val_wrapper = NamingWrapperMultiple(val_iter, "method_name", padding_idx=NAME.vocab.stoi["<pad>"], walk_times=MAX_WALK_TIMES)
test_wrapper = NamingWrapperMultiple(test_iter, "method_name", padding_idx=NAME.vocab.stoi["<pad>"], walk_times=MAX_WALK_TIMES)

"""model"""
model = Model.make_model(len(SRC.vocab), len(NAME.vocab), N=6)
model.cuda()
criterion = KLDivLossWithLabelSmoothing(len(NAME.vocab), padding_idx=0, smoothing=0.1)
criterion.cuda()
opt = OptimWrapper.get_std_opt(model)
train_loss_compute = SimpleLossCompute(model.generator, criterion, opt)
val_loss_compute = SimpleLossCompute(model.generator, criterion, None)

def get_name_from_ids(ids):
    name = []
    filtered = []
    for id in ids:
        if id not in [0,1,2,3]:
            filtered.append(id)
    for j in filtered:
        s = NAME.vocab.itos[j]
        name.append(s)
    return "_".join(name)

def get_average(emb):
    return torch.mean(emb, 0)

def is_outlier_name(name):
    """
    filter out certain kind of names according to experiment settings
    :param name: name to examine
    :return: bool value
    """
    # anonymous method that can't find corresponding source name (name = A$B)
    if name.find('$') != -1 and len(name.split('$')) <= 2 and not name.startswith('$'):
        return True
    # main or init method
    if name == 'main' or name == 'init' or name == 'clinit':
        return True
    # init method
    if name.find('init') != -1 or name.find('clinit') != -1:
        return True
    # toy method
    if name.find('example') != -1 or name.find('test') != -1 or name.find('template') != -1:
        return True
    # names without any letters or empty name
    if not any(c.isalpha() for c in name):
        return True
    if name.find("lambda") != -1 or name.find("bootstrap") != -1 or name.find("access") != -1:
        return True
    else:
        return False


"""get context vectors"""
# batch = next(train_wrapper.__iter__())
# out = model.forward(batch.src, batch.tgt, batch.src_mask, batch.tgt_mask)

# meta = "/home/qwe/disk1/zfy_lab/fytorch_data/visual/meta_small.tsv"
# emb = "/home/qwe/disk1/zfy_lab/fytorch_data/visual/emb_small.tsv"
# with open(meta, "w") as f1:
#     with open(emb, "w") as f2:
#         times = 0
#         already_in = []
#         for batch in train_wrapper:
#             times += 1
#             print(times)
#             if times > 100:
#                 break
#             out = model.forward(batch.src, batch.tgt, batch.src_mask, batch.tgt_mask)
#             for i in range(len(batch.tgt)):
#                 ids = batch.tgt[i]
#                 name = get_name_from_ids(ids)
#                 emb = out[i, :]
#                 emb = get_average(emb)
#                 emb = emb.tolist()
#                 if not is_outlier_name(name) and name not in already_in:
#                     f1.write(name + "\n")
#                     for j in range(len(emb)-1):
#                         v = str(emb[j])
#                         f2.write(v + "\t")
#                     f2.write(str(emb[len(emb)-1]))
#                     f2.write("\n")
#                 already_in.append(name)

"""visualize attention"""
# batch = next(train_wrapper.__iter__())
# sent_ids = batch.tgt[0]
# print(sent_ids.size())
# # sent = get_name_from_ids(sent_ids)
# tgt_ids = batch.tgt_y
# print(tgt_ids.size())
# # tgt_sent = get_name_from_ids(tgt_ids)
# #
# # for layer in range(1, 6, 2):
# #     fig, axs = plt.subplots(1, 4, figsize=(20, 10))
# #     print("Encoder Layer", layer + 1)
# #     for h in range(4):
# #         draw(model.encoder.layers[layer].self_attn.attn[0, h].data,
# #              sent, sent if h == 0 else [], ax=axs[h])
# #     plt.show()

"""single predict"""
batch = next(train_wrapper.__iter__())
out = model.forward(batch.src, batch.tgt, batch.src_mask, batch.tgt_mask)
tgt = batch.tgt[24]
src = batch.src[24]
src_attn = model.decoder.layers[0].src_attn.attn[0,0].data
# print(src.size())
# print(tgt.size())
# print(src_attn.size())
# print(src_attn)
for i in range(len(tgt)):
    print(i)
    id = tgt[i]
    print(NAME.vocab.itos[id])
    print(src_attn[i].size())
    print(src_attn[i])
    print("----------")
