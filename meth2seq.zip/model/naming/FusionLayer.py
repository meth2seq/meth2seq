import torch
import torch.nn as nn


class FusionLayer(nn.Module):
    """use simple ffn to fusion contexts"""

    def __init__(self, dim1, dim2, dropout=0.1):
        super(FusionLayer, self).__init__()
        self.linear = nn.Linear(dim1, dim2)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x):
        x = x.reshape(x.shape[0], x.shape[1], -1)
        return self.dropout(self.linear(x))

