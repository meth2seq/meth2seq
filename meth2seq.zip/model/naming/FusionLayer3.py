import torch
import torch.nn as nn


class FusionLayer3(nn.Module):
    """ use conv1d to fusion contexrs """

    def __init__(self, ksize=2561, dropout=0.1):
        super(FusionLayer3, self).__init__()
        self.conv1d = nn.Conv1d(48, 48, ksize)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x):
        x = x.reshape(x.size(0), x.size(1), -1)  # which makes d_in = 11 * 256 = 2816
        return self.dropout(self.conv1d(x))
