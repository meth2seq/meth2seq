import torch
import torch.nn as nn
import torch.nn.functional as F
from model.transformer.PositionWiseFeedForward import PositionwiseFeedForward

# prelims

batch_size = 32
walk_times = 20
walk_length = 10
dim1 = 128
dim2 = 64

# input
input = torch.randn(batch_size, walk_times, walk_length, dim1)
print(input.shape)

# common
input = input.reshape(batch_size, walk_times, -1)
print(input.shape)

# model
linear = nn.Linear(1280, 64)
posff = PositionwiseFeedForward(1280, 64)
conv1d = nn.Conv1d(20, 20, 1280-64)


# output
output = conv1d(input)
print(output.shape)