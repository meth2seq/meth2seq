import torch
import torch.nn as nn
from torchtext import data, datasets
from torchtext.data import BucketIterator
import spacy
from model.transformer.Model import Model
from training.loss.wrapper.LossWrapper import LossWrapper
from training.Optimizer import Optimizer
from app.RunEpoch import RunEpoch
from training.loss.compute.SimpleLossCompute import SimpleLossCompute
from dataset.batch.wrapper.IWSLTWrapper import IWSLTTranslationBatchWrapper
from evaluating.decode.Decode import Decode
from dataset.batch.wrapper.MyIterator import MyIterator
from dataset.batch.mask.Mask import Mask


global max_src_in_batch, max_tgt_in_batch
def batch_size_fn(new, count, sofar):
    "Keep augmenting batch and calculate total number of tokens + padding."
    global max_src_in_batch, max_tgt_in_batch
    if count == 1:
        max_src_in_batch = 0
        max_tgt_in_batch = 0
    max_src_in_batch = max(max_src_in_batch,  len(new.src))
    max_tgt_in_batch = max(max_tgt_in_batch,  len(new.trg) + 2)
    src_elements = count * max_src_in_batch
    tgt_elements = count * max_tgt_in_batch
    return max(src_elements, tgt_elements)


def rebatch(pad_idx, batch):
    "Fix order in torchtext to match ours"
    src, trg = batch.src.transpose(0, 1), batch.trg.transpose(0, 1)
    return Mask(src, trg, pad_idx)


spacy_de = spacy.load('de')
spacy_en = spacy.load('en')

def tokenize_de(text):
    return [tok.text for tok in spacy_de.tokenizer(text)]

def tokenize_en(text):
    return [tok.text for tok in spacy_en.tokenizer(text)]

BOS_WORD = '<s>'
EOS_WORD = '</s>'
BLANK_WORD = "<blank>"
SRC = data.Field(tokenize=tokenize_de, pad_token=BLANK_WORD)
TGT = data.Field(tokenize=tokenize_en, init_token = BOS_WORD,
                 eos_token = EOS_WORD, pad_token=BLANK_WORD)

# device
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
print("current device is :", device)


# build data
MAX_LEN = 100
train, val, test = datasets.IWSLT.splits(
    exts=('.de', '.en'), fields=(SRC, TGT),
    filter_pred=lambda x: len(vars(x)['src']) <= MAX_LEN and
        len(vars(x)['trg']) <= MAX_LEN)
MIN_FREQ = 2
SRC.build_vocab(train.src, min_freq=MIN_FREQ)
TGT.build_vocab(train.trg, min_freq=MIN_FREQ)

padding_idx = TGT.vocab.stoi[BLANK_WORD]
BATCH_SIZE = 12


pad_idx = TGT.vocab.stoi["<blank>"]
model = Model.make_model(len(SRC.vocab), len(TGT.vocab), N=6)
model.cuda()
criterion = LossWrapper(size=len(TGT.vocab), criterion=nn.KLDivLoss(size_average=False), padding_idx=padding_idx)
criterion.cuda()
BATCH_SIZE = 120
train_iter = MyIterator(train, batch_size=BATCH_SIZE, device="cuda:0",
                        repeat=False, sort_key=lambda x: (len(x.src), len(x.trg)),
                        batch_size_fn=batch_size_fn, train=True)
valid_iter = MyIterator(val, batch_size=BATCH_SIZE, device="cuda:0",
                        repeat=False, sort_key=lambda x: (len(x.src), len(x.trg)),
                        batch_size_fn=batch_size_fn, train=False)

if True:
    model_opt = Optimizer(model.src_embed[0].d_model, 1, 2000, torch.optim.Adam(model.parameters(), lr=0, betas=(0.9, 0.98), eps=1e-9))
    for epoch in range(1):
        model.train()
        RunEpoch.run_single_step((rebatch(pad_idx, b) for b in train_iter),
                                 model,
                                 SimpleLossCompute(model.generator, criterion,
                        opt=model_opt))

for i, batch in enumerate(valid_iter):
    src = batch.src.transpose(0,1)[:1]
    src_mask = (src != SRC.vocab.stoi["<blank>"]).unsqueeze(-2)
    print(src.shape)
    print(src_mask.shape)
    out = Decode.greedy_decode(model, src, src_mask,
                        max_len=60, start_symbol=TGT.vocab.stoi["<s>"])
    print("Translation:", end="\t")
    for i in range(1, out.size(1)):
        sym = TGT.vocab.itos[out[0, i]]
        if sym == "</s>": break
        print(sym, end =" ")
    print()
    print("Target:", end="\t")
    for i in range(1, batch.trg.size(0)):
        sym = TGT.vocab.itos[batch.trg.data[i, 0]]
        if sym == "</s>": break
        print(sym, end =" ")
    print()
    break
