import torch
import torchtext
from time import time
import torch
import os
from tqdm import tqdm
from torchtext.data import Field
from torchtext.data import Dataset, TabularDataset
from torchtext.data import Iterator, BucketIterator
from dataset.batch.wrapper.NamingWrapper import NamingWrapper
from training.loss.wrapper.KLDivLossWithLabelSmoothing import KLDivLossWithLabelSmoothing
from training.loss.compute.SimpleLossCompute import SimpleLossCompute
from training.opt.OptimWrapper import OptimWrapper
from training.run.RunEpoch import RunEpoch
from model.naming.Model import Model
from time import time
from evaluating.run.evaluate import eval2, eval3, eval4
from common.model.utils import save_checkpoint, save_dict_to_json, metrics_dict_msg

# device
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
print("current device is :", device)

# preliminary
DATA_PATH = "/home/qwe/zfy_lab/fytorch/output/dataset/no_trim/use_minfreq/"
MAX_WALK_TIMES = 48
EPOCHS = 40
BATCH_SIZE = 64
SAVE_PATH = "/home/qwe/zfy_lab/fytorch/output/trained/no_trim/use_minfreq/"

tokenize = lambda x: x.split(',')
JIMPLE = Field(tokenize=tokenize, init_token="<s>", eos_token="<eos>")
NAME = Field(tokenize=tokenize, init_token="<s>", eos_token="<eos>")

fields = list()
fields.append(("id", None))
fields.append(("method_name", NAME))
for i in range(MAX_WALK_TIMES):
    name = "walk_" + str(i)
    fields.append((name, JIMPLE))

t = time()
# load dataset
train, val, test = TabularDataset.splits(
    path=DATA_PATH, train="train_.csv", validation="val_.csv", test="test_.csv", format="csv",
    skip_header=True, fields=fields
)

for i in range(48):
    example = train[0]
    key = "walk_" + str(i)
    print(getattr(example, key))

# # load vocab
# ck = torch.load(DATA_PATH + "vocab.pt")
# vocab_jimple = ck["jimple"]
# vocab_name = ck["name"]
# JIMPLE.vocab = vocab_jimple
# NAME.vocab = vocab_name
#
#
# # create iterator
# def sort_key(x):
#     total_length = 0
#     name = getattr(x, "method_name")  # this happens when preprocessing is done, so type is list
#     total_length += len(name)
#     return total_length
#
#
# train_iter, val_iter, test_iter = BucketIterator.splits(
#     datasets=(train, val, test),
#     batch_sizes=(BATCH_SIZE, BATCH_SIZE, BATCH_SIZE),
#     sort_key=sort_key,
#     sort_within_batch=False,
#     device=device,
#     repeat=False
# )
#
# # wrap the iterator
# train_wrapper = MethodNamingBatchWrapper(train_iter, "method_name", padding_idx=NAME.vocab.stoi["<pad>"], walk_times=MAX_WALK_TIMES)
# val_wrapper = MethodNamingBatchWrapper(val_iter, "method_name", padding_idx=NAME.vocab.stoi["<pad>"], walk_times=MAX_WALK_TIMES)
# test_wrapper = MethodNamingBatchWrapper(test_iter, "method_name", padding_idx=NAME.vocab.stoi["<pad>"], walk_times=MAX_WALK_TIMES)
#
#
# """model"""
# model = Model.make_model(len(JIMPLE.vocab), len(NAME.vocab), N=6)
# model.cuda()
# criterion = KLDivLossWithLabelSmoothing(len(NAME.vocab), padding_idx=NAME.vocab.stoi["<pad>"], smoothing=0.1)
# criterion.cuda()
# opt = OptimWrapper.get_std_opt(model)
# train_loss_compute = SimpleLossCompute(model.generator, criterion, opt)
# val_loss_compute = SimpleLossCompute(model.generator, criterion, None)
#
# """eval"""
# checkpoint = torch.load(SAVE_PATH + "best.pth.tar")
# model.load_state_dict(checkpoint["state_dict"])
# train_loss_compute.opt.optimizer.load_state_dict(checkpoint["optim_dict"])
# model.eval()
#
# from evaluating.run.evaluate import eval2, eval3, eval4, eval5, eval6
# metrics = eval6(model, test_wrapper, NAME.vocab.stoi["<s>"], NAME.vocab.stoi["<eos>"], NAME.vocab.stoi["<pad>"], NAME.vocab.stoi["<unk>"])
# print(metrics)