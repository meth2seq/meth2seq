from dataset.preprocessing.wrapper.JimpleFieldWrapper import JimpleFieldWrapper
from dataset.preprocessing.wrapper.MethodNameFieldWrapper import MethodNameFieldWrapper
from evaluating.run.evaluate import eval2, eval3
from op.model.utils import save_checkpoint, save_dict_to_json, metrics_dict_msg
import torch
import os
from torchtext.data import Field
from torchtext.data import Dataset, TabularDataset
from torchtext.data import Iterator, BucketIterator
from dataset.batch.wrapper.NamingWrapper import NamingWrapper
from training.loss.wrapper.KLDivLossWithLabelSmoothing import KLDivLossWithLabelSmoothing
from training.loss.compute.SimpleLossCompute import SimpleLossCompute
from training.opt.OptimWrapper import OptimWrapper
from training.run.RunEpoch import RunEpoch
from model.naming.Model import Model
from time import time
from dataset.io.io import save_dataset


# preliminary
MAX_WALK_TIMES = 48
EPOCHS = 60
BATCH_SIZE = 64
DATA_BASE = "/home/qwe/disk1/data_SoC/files/"
SAVE_DATA_BASE = "/home/qwe/zfy_lab/fytorch/output/dataset/"
SAVE_MODEL_BASE = "/home/qwe/zfy_lab/fytorch/output/trained/"
USE_TRIM = False
USE_MIN_FREQ = True

if USE_TRIM and USE_MIN_FREQ:
    DATA_PATH = DATA_BASE + "ptdata/"
    SAVE_DATA_PATH = SAVE_DATA_BASE + "use_trim/use_minfreq/"
    SAVE_MODEL_PATH = SAVE_MODEL_BASE + "use_trim/use_minfreq/"
if USE_TRIM and not USE_MIN_FREQ:
    DATA_PATH = DATA_BASE + "ptdata/"
    SAVE_DATA_PATH = SAVE_DATA_BASE + "use_trim/no_minfreq/"
    SAVE_MODEL_PATH = SAVE_MODEL_BASE + "use_trim/no_minfreq/"
if not USE_TRIM and USE_MIN_FREQ:
    DATA_PATH = DATA_BASE + "ptdata_no_trim/"
    SAVE_DATA_PATH = SAVE_DATA_BASE + "no_trim/use_minfreq/"
    SAVE_MODEL_PATH = SAVE_MODEL_BASE + "no_trim/use_minfreq/"
if not USE_TRIM and not USE_MIN_FREQ:
    DATA_PATH = DATA_BASE + "ptdata_no_trim/"
    SAVE_DATA_PATH = SAVE_DATA_BASE + "no_trim/no_minfreq/"
    SAVE_MODEL_PATH = SAVE_MODEL_BASE + "no_trim/no_minfreq/"
print("current DATA_PATH: %s" % DATA_PATH)
print("current SAVE_DATA_PATH: %s" % SAVE_DATA_PATH)
print("current SAVE_MODEL_PATH: %s" % SAVE_MODEL_PATH)


# device
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
print("current device is :", device)

JIMPLE = Field(tokenize=JimpleFieldWrapper.tokenize, preprocessing=JimpleFieldWrapper.preprocess,
               init_token="<s>", eos_token="<eos>")
NAME = Field(tokenize=MethodNameFieldWrapper.tokenize, preprocessing=MethodNameFieldWrapper.preprocess,
             init_token="<s>", eos_token="<eos>")

fields = []
fields.append(("id", None))
fields.append(("method_name", NAME))
for i in range(MAX_WALK_TIMES):
    name = "walk_" + str(i)
    fields.append((name, JIMPLE))

# build dataset
train, val, test = TabularDataset.splits(
    path=DATA_PATH, train="train.csv", validation="val.csv", test="test.csv", format="csv",
    skip_header=True, fields=fields
)

# build vocab
JIMPLE.build_vocab(train, val, test, min_freq=8)
NAME.build_vocab(train, val, test, min_freq=8)

# save dataset
save_dataset(train, SAVE_DATA_PATH + "train_.csv")
save_dataset(val, SAVE_DATA_PATH + "val_.csv")
save_dataset(test, SAVE_DATA_PATH + "test_.csv")

# save vocab
vocab = {
    "jimple": JIMPLE.vocab,
    "name": NAME.vocab
}

torch.save(vocab, SAVE_DATA_PATH + "vocab.pt")


# create iterator
def sort_key(x):
    total_length = 0
    name = getattr(x, "method_name")  # this happens when preprocessing is done, so type is list
    total_length += len(name)
    return total_length


train_iter, val_iter, test_iter = BucketIterator.splits(
    datasets=(train, val, test),
    batch_sizes=(BATCH_SIZE, BATCH_SIZE, BATCH_SIZE),
    sort_key=sort_key,
    sort_within_batch=False,
    device=device,
    repeat=False,
    shuffle=True
)

# wrap the iterator
train_wrapper = NamingWrapper(train_iter, "method_name", padding_idx=NAME.vocab.stoi["<pad>"], walk_times=MAX_WALK_TIMES)
val_wrapper = NamingWrapper(val_iter, "method_name", padding_idx=NAME.vocab.stoi["<pad>"], walk_times=MAX_WALK_TIMES)
test_wrapper = NamingWrapper(test_iter, "method_name", padding_idx=NAME.vocab.stoi["<pad>"], walk_times=MAX_WALK_TIMES)


"""model"""
model = Model.make_model(len(JIMPLE.vocab), len(NAME.vocab), N=6)
model.cuda()
criterion = KLDivLossWithLabelSmoothing(len(NAME.vocab), padding_idx=NAME.vocab.stoi["<pad>"], smoothing=0.1)
criterion.cuda()
opt = OptimWrapper.get_std_opt(model)
train_loss_compute = SimpleLossCompute(model.generator, criterion, opt)
val_loss_compute = SimpleLossCompute(model.generator, criterion, None)

"""train"""
best_f1 = 0.0
no_new_best_count = 0
for epoch in range(EPOCHS):
    print("EPOCH: " + str(epoch))
    model.train()
    loss = RunEpoch.run_epoch(train_wrapper, model, train_loss_compute)
    print("loss: %f" % loss)
    model.eval()
    val_metrics = eval3(model, val_wrapper, NAME.vocab.stoi["<s>"],
                        NAME.vocab.stoi["<eos>"], NAME.vocab.stoi["<pad>"], NAME.vocab.stoi["<unk>"])
    test_metrics = eval3(model, test_wrapper, NAME.vocab.stoi["<s>"],
                        NAME.vocab.stoi["<eos>"], NAME.vocab.stoi["<pad>"], NAME.vocab.stoi["<unk>"])
    print("val metric: " + metrics_dict_msg(val_metrics))
    print("test metric: " + metrics_dict_msg(test_metrics))
    val_f1 = val_metrics["f1"]

    is_best = val_f1 > best_f1
    checkpoint = {
        epoch: epoch,
        "state_dict": model.state_dict(),
        "optim_dict": train_loss_compute.opt.optimizer.state_dict()
    }
    save_checkpoint(checkpoint, is_best, SAVE_MODEL_PATH)

    if is_best:
        print("find new best f1 value")
        best_f1 = val_f1

        best_json_path = os.path.join(
            SAVE_MODEL_PATH, "metrics_val_best_weights.json")

        save_dict_to_json(val_metrics, best_json_path)
        no_new_best_count = 0
    else:
        no_new_best_count += 1

    if no_new_best_count > 5:
        print("5 epochs without new best, end training")
        break
