import torch
from tqdm import tqdm
from torchtext.data import Field
from torchtext.data import TabularDataset
from torchtext.data import Iterator, BucketIterator
from dataset.preprocessing.wrapper.JimpleFieldWrapper import JimpleFieldWrapper
from dataset.preprocessing.wrapper.MethodNameFieldWrapper import MethodNameFieldWrapper
from dataset.batch.wrapper.NamingWrapper import NamingWrapper
from training.loss.wrapper.KLDivLossWithLabelSmoothing import KLDivLossWithLabelSmoothing
from training.loss.compute.SimpleLossCompute import SimpleLossCompute
from training.opt.OptimWrapper import OptimWrapper
from training.run.RunEpoch import RunEpoch
from model.naming.Model import Model
from evaluating.decode.Decode import Decode
from evaluating.metrics.F1 import F1
from torch.autograd import Variable
from dataset.batch.mask.RandomWalkMask import RandomWalkMask
from time import time
from dataset.io.io import save_dataset

# preliminary
DATA_PATH = "/home/qwe/disk1/data_SoC/files/"
MAX_WALK_TIMES = 48
EPOCHS = 20
SAVE_PATH = "/home/qwe/zfy_lab/fytorch/trained/"
BATCH_SIZE = 64

# device
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
print("current device is :", device)

# define field
JIMPLE = Field(tokenize=JimpleFieldWrapper.tokenize, preprocessing=JimpleFieldWrapper.preprocess,
               init_token="<s>", eos_token="<eos>")
NAME = Field(tokenize=MethodNameFieldWrapper.tokenize, preprocessing=MethodNameFieldWrapper.preprocess,
             init_token="<s>", eos_token="<eos>")

fields = []
fields.append(("id", None))
fields.append(("method_name", NAME))
for i in range(MAX_WALK_TIMES):
    name = "walk_" + str(i)
    fields.append((name, JIMPLE))

before_build_data = time()
# build dataset
train, val, test = TabularDataset.splits(
    path=DATA_PATH, train="toy3.csv", validation="toy3.csv", test="toy3.csv", format="csv",
    skip_header=True, fields=fields
)

# build vocab
JIMPLE.build_vocab(train, val, test)
NAME.build_vocab(train, val, test)

after_build_vocab = time()
#
# save_dataset(train, SAVE_PATH + "train_dataset.csv")
# save_dataset(val, SAVE_PATH + "val_dataset.csv")
# save_dataset(test, SAVE_PATH + "test_dataset.csv")
# after_save_data = time()
#
# create iterator
def sort_key(x):
    total_length = 0
    name = getattr(x, "method_name")  # this happens when preprocessing is done, so type is list
    total_length += len(name)
    # for i in range(MAX_WALK_TIMES):
    #     walk = getattr(x, "walk_" + str(i))
    #     total_length += len(walk)  # walk is also list of tokens now
    return total_length


train_iter, val_iter = BucketIterator.splits(
    datasets=(train, val),
    batch_sizes=(BATCH_SIZE, BATCH_SIZE),
    device=device,
    sort_key=sort_key,
    sort_within_batch=False,
    repeat=False
)

test_iter = BucketIterator(
    dataset=test,
    batch_size=BATCH_SIZE,
    device=device,
    sort=False,
    sort_within_batch=False,
    repeat=False
)

# wrap the iterator
train_wrapper = NamingWrapper(train_iter, "method_name", padding_idx=1, walk_times=MAX_WALK_TIMES)
val_wrapper = NamingWrapper(val_iter, "method_name", padding_idx=1, walk_times=MAX_WALK_TIMES)
test_wrapper = NamingWrapper(test_iter, "method_name", padding_idx=1, walk_times=MAX_WALK_TIMES)

# # """model"""
# # model = Model.make_model(len(JIMPLE.vocab), len(NAME.vocab), N=6)
# # model.cuda()
# # criterion = KLDivLossWithLabelSmoothing(len(NAME.vocab), padding_idx=0, smoothing=0.1)
# # criterion.cuda()
# # opt = OptimWrapper.get_std_opt(model)
# # train_loss_compute = SimpleLossCompute(model.generator, criterion, opt)
# # val_loss_compute = SimpleLossCompute(model.generator, criterion, None)
# #
# # """train"""
# # for epoch in range(EPOCHS):
# #     print("EPOCH: " + str(epoch))
# #     model.train()
# #     RunEpoch.run_epoch(train_wrapper, model, train_loss_compute)
# #     model.eval()
# #     loss = RunEpoch.run_epoch(val_wrapper, model, val_loss_compute)
# #     print(loss)
# #
# # """save model"""
# # torch.save(model, SAVE_PATH + "naming_concat2.pt")
#
# """eval"""
# model = torch.load(SAVE_PATH + "naming_concat2.pt")
# model.cuda()
# model.eval()
# #
# #
# #
# # total_acc = []
# # total_prec = []
# # total_recall = []
# # total_f1 = []
# #
# # # for batch in tqdm(val_wrapper):
# # #     outs = []
# # #     tgts = []
# # #     for i in range(BATCH_SIZE):
# # #         src = batch.src[i:i+1]
# # #         src_mask = batch.src_mask[i:i+1]
# # #         tgt = batch.tgt_y[i:i+1]
# # #         out = Decode.greedy_decode(model, src, src_mask, max_len=60, start_symbol=NAME.vocab.stoi["<s>"])
# # #         outs.append(out)
# # #         tgts.append(tgt)
# # #         # print(out)
# # #     batch_pred = torch.cat([out for out in outs], dim=0)
# # #     batch_tgt = torch.cat([tgt for tgt in tgts], dim=0)
# # #     metric = F1(BATCH_SIZE, NAME.vocab.stoi["<s>"], NAME.vocab.stoi["<eos>"], NAME.vocab.stoi["<pad>"], NAME.vocab.stoi["<unk>"])
# # #     acc, prec, recall, f1 = metric.calculate(batch_pred, batch_tgt)
# # #     total_acc.append(acc)
# # #     total_prec.append(prec)
# # #     total_recall.append(recall)
# # #     total_f1.append(f1)
# # #     print(batch_tgt.size(1), metric.calculate(batch_pred, batch_tgt))
# # #
# # # print("total:", total_acc.mean(), total_prec.mean(), total_recall.mean(), total_f1.mean())
# #
# t1 = time()
# from evaluating.run.evaluate import eval2, eval3
# accuracy, precision, recall, f1 = eval3(model, test_wrapper, NAME.vocab.stoi["<s>"], NAME.vocab.stoi["<eos>"], NAME.vocab.stoi["<pad>"], NAME.vocab.stoi["<unk>"])
# dt = time() - t1
# print("valid metrics, accuracy: %0.3f, precision: %0.3f, recall: %0.3f, f1: %0.3f, time: %f"
#       % (accuracy, precision, recall, f1, dt))