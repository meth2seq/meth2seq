import torch
import torchtext
from time import time
from torchtext.data import Field
from torchtext.data import TabularDataset
from torchtext.data import Iterator, BucketIterator
from dataset.preprocessing.wrapper.JimpleFieldWrapper import JimpleFieldWrapper
from dataset.preprocessing.wrapper.MethodNameFieldWrapper import MethodNameFieldWrapper
from dataset.batch.wrapper.NamingWrapper import NamingWrapper
from dataset.io.io import save_dataset
from op.parameter.Params import Params

# preliminary
INPUT_PATH = "/home/qwe/disk1/data_SoC/files/ptdata/"
MAX_WALK_TIMES = 48
EPOCHS = 10
SAVE_PATH = "/home/qwe/zfy_lab/fytorch/output/dataset"
BATCH_SIZE = 64


# device
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
print("current device is :", device)

start = time()
JIMPLE = Field(tokenize=JimpleFieldWrapper.tokenize, preprocessing=JimpleFieldWrapper.preprocess,
               init_token="<s>", eos_token="<eos>")
NAME = Field(tokenize=MethodNameFieldWrapper.tokenize, preprocessing=MethodNameFieldWrapper.preprocess,
             init_token="<s>", eos_token="<eos>")

fields = []
fields.append(("id", None))
fields.append(("method_name", NAME))
for i in range(MAX_WALK_TIMES):
    name = "walk_" + str(i)
    fields.append((name, JIMPLE))

# build dataset
train, val, test = TabularDataset.splits(
    path=DATA_PATH, train="train.csv", validation="val.csv", test="test.csv", format="csv",
    skip_header=True, fields=fields
)


# build vocab
JIMPLE.build_vocab(train, val, test)
NAME.build_vocab(train, val, test)

# save dataset
save_dataset(train, SAVE_PATH + "train_.csv")
save_dataset(val, SAVE_PATH + "val_.csv")
save_dataset(test, SAVE_PATH + "test_.csv")

# save vocab
vocab = {
    "jimple": JIMPLE.vocab,
    "name": NAME.vocab
}

torch.save(vocab, SAVE_PATH + "vocab.pt")

print("build data time: %f" % (time() - start))