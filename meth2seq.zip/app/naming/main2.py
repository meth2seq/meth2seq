import torch
import random
import numpy as np
from tqdm import tqdm
from torchtext.data import Field
from torchtext.data import TabularDataset
from torchtext.data import Iterator, BucketIterator
from dataset.preprocessing.wrapper.JimpleFieldWrapper import JimpleFieldWrapper
from dataset.preprocessing.wrapper.MethodNameFieldWrapper import MethodNameFieldWrapper
from dataset.batch.wrapper.NamingWrapper import NamingWrapper
from training.loss.wrapper.KLDivLossWithLabelSmoothing import KLDivLossWithLabelSmoothing
from training.loss.compute.SimpleLossCompute import SimpleLossCompute
from training.opt.OptimWrapper import OptimWrapper
from training.run.RunEpoch import RunEpoch
from model.naming.Model import Model
from evaluating.run.evaluate import eval_epoch, eval2

# preliminary
DATA_PATH = "/home/qwe/disk1/data_SoC/files/"
MAX_WALK_TIMES = 50
EPOCHS = 20
SAVE_PATH = "/home/qwe/zfy_lab/fytorch/trained/"
BATCH_SIZE = 64
MAX_LEN = 5


# device
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
print("current device is :", device)

# define field
JIMPLE = Field(tokenize=JimpleFieldWrapper.tokenize, preprocessing=JimpleFieldWrapper.preprocess,
               init_token="<s>", eos_token="<eos>")
NAME = Field(tokenize=MethodNameFieldWrapper.tokenize, preprocessing=MethodNameFieldWrapper.preprocess,
             init_token="<s>", eos_token="<eos>")

fields = []
fields.append(("id", None))
fields.append(("method_name", NAME))
for i in range(MAX_WALK_TIMES):
    name = "walk_" + str(i)
    fields.append((name, JIMPLE))

# build dataset
train, val, test = TabularDataset.splits(
    path=DATA_PATH, train="train.csv", validation="val.csv", test="test.csv", format="csv",
    skip_header=True, fields=fields
)

# build vocab
JIMPLE.build_vocab(train, val, test)
NAME.build_vocab(train, val, test)


# create iterator
def sort_key(x):
    total_length = 0
    name = getattr(x, "method_name")  # this happens when preprocessing is done, so type is list
    total_length += len(name)
    # for i in range(MAX_WALK_TIMES):
    #     walk = getattr(x, "walk_" + str(i))
    #     total_length += len(walk)  # walk is also list of tokens now
    return total_length


train_iter, val_iter = BucketIterator.splits(
    datasets=(train, val),
    batch_sizes=(BATCH_SIZE, BATCH_SIZE),
    device=device,
    sort_key=sort_key,
    sort_within_batch=False,
    repeat=False
)

test_iter = BucketIterator(
    dataset=test,
    batch_size=BATCH_SIZE,
    device=device,
    sort=False,
    sort_within_batch=False,
    repeat=False
)

# wrap the iterator
train_wrapper = NamingWrapper(train_iter, "method_name", padding_idx=NAME.vocab.stoi["<pad>"], walk_times=MAX_WALK_TIMES)
val_wrapper = NamingWrapper(val_iter, "method_name", padding_idx=NAME.vocab.stoi["<pad>"], walk_times=MAX_WALK_TIMES)
test_wrapper = NamingWrapper(test_iter, "method_name", padding_idx=NAME.vocab.stoi["<pad>"], walk_times=MAX_WALK_TIMES)


"""model"""
model = Model.make_model(len(JIMPLE.vocab), len(NAME.vocab), N=6)
model.cuda()
criterion = KLDivLossWithLabelSmoothing(len(NAME.vocab), padding_idx=0, smoothing=0.1)
criterion.cuda()
opt = OptimWrapper.get_std_opt(model)
train_loss_compute = SimpleLossCompute(model.generator, criterion, opt)
val_loss_compute = SimpleLossCompute(model.generator, criterion, None)

"""train"""
for epoch in range(EPOCHS):
    print("EPOCH: %d, total steps: %d" % (epoch, len(train_wrapper)))
    model.train()
    total_tokens = 0
    total_loss = 0
    count = 0
    for batch in train_wrapper:
        model.train()
        count += 1
        out = model.forward(batch.src, batch.tgt, batch.src_mask, batch.tgt_mask)
        loss = train_loss_compute(out, batch.tgt_y, batch.ntokens)
        total_loss += loss
        total_tokens += batch.ntokens
        if count % 2000 == 0:
            model.eval()
            loss = RunEpoch.run_epoch(val_wrapper, model, val_loss_compute)
            print("valid loss: %0.3f" % loss)
            accuracy, precision, recall, f1 = \
                eval2(model, val_wrapper, NAME.vocab.stoi["<s>"],
                           NAME.vocab.stoi["<eos>"], NAME.vocab.stoi["<pad>"], NAME.vocab.stoi["<unk>"])
            print("valid metrics, accuracy: %0.3f, precision: %0.3f, recall: %0.3f, f1: %0.3f"
                  % (accuracy, precision, recall, f1))
        if count % 2000 == 0:
            model.eval()
            accuracy, precision, recall, f1 = \
                eval2(model, test_wrapper, NAME.vocab.stoi["<s>"],
                           NAME.vocab.stoi["<eos>"], NAME.vocab.stoi["<pad>"], NAME.vocab.stoi["<unk>"])

            print("test metrics, accuracy: %0.3f, precision: %0.3f, recall: %0.3f, f1: %0.3f"
                  % (accuracy, precision, recall, f1))

# """save model"""
# torch.save(model, SAVE_PATH + "naming_concat3.pt")
