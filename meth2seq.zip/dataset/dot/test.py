from dataset.dot.SourceFinder import SourceFinder
from tqdm import tqdm
import itertools


path1 = "/home/qwe/disk1/dots/projects1"
path2 = "/home/qwe/disk1/dots/projects2"
path3 = "/home/qwe/disk1/dots/projects3"

paths = path1 + "#" + path2 + "#" + path3
local_path = "/home/qwe/disk1/sources/astpath_sources/locals.txt"
feature_path = "/home/qwe/disk1/sources/astpath_sources/features.txt"

dict_local = {}
dict_feature = {}
with open(local_path, "r") as f1:
    with open(feature_path, "r") as f2:
        for line in f1.readlines():
            if len(line) > 1 and line.find("|||") != -1:
                qualifier = line.split("|||")[0]
                locals = line.split("|||")[1]
                dict_local.setdefault(qualifier, None)
                dict_local[qualifier] = locals
        for line in f2.readlines():
            if len(line) > 1 and line.find("|||") != -1 and line.find("$full$") != -1:
                qualifier = line.split("$full$")[0].split("|||")[0]
                feature = line.split("$full$")[1]
                dict_feature.setdefault(qualifier, None)
                dict_feature[qualifier] = feature
print(len(dict_local), len(dict_feature))
count = 0
with open("/home/qwe/disk1/zfy_lab/fytorch_data/source_var/evaluation/raw/local_astpath.txt", "w") as f:
    for q in dict_local.keys():
        if q in dict_feature.keys():
            name = dict_local[q].strip()
            feature = dict_feature[q].strip()
            f.write(name + "$full$" + feature + "\n")
            count += 1
print(count)
# search_space = {}
# with open(feature_path, "r") as f:
#     for line in f.readlines():
#         if len(line) > 1 and line.find("|||") != -1:
#             qualifier = line.split("|||")[0]
#             locals = line.split("|||")[1]
#             search_space.setdefault(qualifier, None)
#             search_space[qualifier] = locals.strip()
# print(len(search_space))

# success_count = 0
# fail_count = 0
# finder = SourceFinder(paths)
# pit = itertools.islice(finder, 10)
# for dot in tqdm(finder):
#     if finder.find_method_in_source(dot, search_space):
#         success_count += 1
#     else:
#         fail_count += 1
# print(success_count, fail_count) # 72477 115526

