"""
统一管理不同级别的分隔符
"""


class Delimiter:

    def __init__(self):
        """
        label_level: 用于连接一个node中的不同字段，如node["jimple"]和node["ir"]
        node_level: 用于连接一个walk之间的nodes
        walk_level: 用于连接一个random walk序列中不同的walks
        full_name_level: 用于连接方法全名和对应的random walks
        """
        self.label_level = "$label$"
        self.node_level = "$node$"
        self.walk_level = "$walk$"
        self.full_name_level = "$full$"
