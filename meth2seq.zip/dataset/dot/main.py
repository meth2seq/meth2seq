from dataset.dot.DotFileWalker import DotFileWalker
from dataset.dot.NxGraph import NxGraph
from dataset.dot.SimpleJimple import SimpleJimple


path1 = "/home/qwe/disk1/dots/projects1"
path2 = "/home/qwe/disk1/dots/projects2"
path3 = "/home/qwe/disk1/dots/projects3"
# exc_path = "/home/qwe/disk1/dots/" + "exceptions.txt"
# output_path = "/home/qwe/disk1/data_SoC/files_IR"
# toy_output_path = "/home/qwe/disk1/data_SoC/test"
# paths = path1 + "#" + path2 + "#" + path3

path = "/home/qwe/disk1/zfy_lab/travis_projects/projects"
exc_path = "/home/qwe/disk1/data_SoC/files_new/sensitive_study/length/exceptions.txt"
output_path = "/home/qwe/disk1/data_SoC/files_new/sensitive_study/length/raw"
toy_output_path = "/home/qwe/disk1/data_SoC/files_new/sensitive_study/length/raw"
paths = path1 + "#" + path2 + "#" + path3 + "#" + path

# total dot file number:  188803 + 91736
walker = DotFileWalker(paths)
print(walker.path)
walker.read_dot_files()
print("total dot file number: ", len(walker.dot_files))
DotFileWalker.clean_file_content(output_path)
count, errcount= walker.process(output_path, exc_path)
print(count, errcount)