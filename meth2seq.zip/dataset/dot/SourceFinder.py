import re
import bisect
from .DotFileWalker import DotFileWalker
from networkx.drawing.nx_pydot import read_dot, write_dot
from .NxGraph import NxGraph
from .Delimiter import Delimiter


class SourceFinder(DotFileWalker):

    def get_haf_path_name(self, dot):
        g = read_dot(dot)
        nxgraph = NxGraph(g)
        fullname = nxgraph.get_full_method_name()
        fullname = re.sub("\(.*\)", "", fullname)
        if len(fullname.split("$")) > 1:
            fullname = fullname.split("$")[0]
        half_path = "/".join(fullname.split(".")[:-1]) + ".java"
        return half_path

    def get_qualifier(self, dot):
        g = read_dot(dot)
        nxgraph = NxGraph(g)
        fullname = nxgraph.get_full_method_name()
        fullname = re.sub("\(.*\)", "", fullname)
        class_name = fullname.split(".")[-2]
        simple_name = fullname.split(".")[-1]
        fulllist = fullname.split(".")[:-2]
        if class_name.find("$") != -1:
            class_name = class_name.split("$")[-1]
        if simple_name.find("$") != -1:
            if len(simple_name.split("$")) > 2:
                simple_name = simple_name.split("$")[1]
            else:
                simple_name = simple_name.split("$")[0]
        fulllist.append(class_name)
        fulllist.append(simple_name)
        fullname = ".".join(fulllist)
        return fullname

    def get_full_name(self,dot):
        g = read_dot(dot)
        nxgraph = NxGraph(g)
        fullname = nxgraph.get_full_method_name()
        fullname = re.sub("\(.*\)", "", fullname)
        return fullname

    def is_bisect_in(self, a, b):
        b.sort()
        for i, x in enumerate(a):
            index = bisect.bisect_left(b, x)
            if index < len(a):
                if x == b[index]:
                    return True
        return False

    def find_method_in_source(self, dot, search_space):
        g = read_dot(dot)
        nxgraph = NxGraph(g)
        fullname = nxgraph.get_full_method_name()
        fullname = re.sub("\(.*\)", "", fullname)
        class_name = fullname.split(".")[-2]
        simple_name = fullname.split(".")[-1]
        fulllist = fullname.split(".")[:-2]
        if class_name.find("$") != -1:
            class_name = class_name.split("$")[-1]
        if simple_name.find("$") != -1:
            if len(simple_name.split("$")) > 2:
                simple_name = simple_name.split("$")[1]
            else:
                simple_name = simple_name.split("$")[0]
        fulllist.append(class_name)
        fulllist.append(simple_name)
        fullname = ".".join(fulllist)
        qualifier = fullname
        if qualifier in search_space.keys():
            result = search_space[qualifier]
            nxgraph.add_attr_to_existing_node(nxgraph.info_node, "source_var", result)
            nxgraph.write_to("/home/qwe/disk1/dots/qualified_source_var/" + qualifier + ".dot")
            return True
        return False
