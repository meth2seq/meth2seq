from dataset.dot.DotFileWalker import DotFileWalker


path = "/home/qwe/disk1/dots/qualified_source_var"
exc_path = "/home/qwe/disk1/data_SoC/files_new/source_var/exceptions.txt"
output_path = "/home/qwe/disk1/data_SoC/files_new/source_var/raw"
toy_output_path = "/home/qwe/disk1/data_SoC/files_new/source_var/raw"

walker = DotFileWalker(path)
print(walker.path)
walker.read_dot_files()
print("total dot file number: ", len(walker.dot_files))
# DotFileWalker.clean_file_content(output_path)
count, errcount= walker.process(output_path, exc_path, mode=1)
print(count, errcount)