import torch
import sys
sys.path.insert(0, "/tmp/pycharm_project_521/")
from dataset.batch.mask.Mask import Mask
from common.tensor.TensorOp import TensorOp
from dataset.batch.mask.RandomWalkMask import RandomWalkMask
from .BasicWrapper import BasicWrapper


class NamingWrapper(BasicWrapper):

    def __init__(self, dl, y_vars, padding_idx, walk_times=48, walk_length=11, device=torch.device("cuda:0")):
        self.dl = dl
        x_vars = []
        for i in range(walk_times):
            x_vars.append("walk_" + str(i))
        self.x_vars = x_vars
        # y_vars is a sentence(method name)
        self.y_vars = y_vars
        self.padding_idx = padding_idx
        self.walk_length = walk_length
        self.device = device

    def __iter__(self):
        # start from naive, we concatenate the contexts
        for batch in self.dl:
            walks = []
            for x_var in self.x_vars:
                walk = getattr(batch, x_var)
                if walk.shape[0] < self.walk_length:
                    padwalk = TensorOp.tpad(walk, dim=0, n=abs(self.walk_length-walk.shape[0]), fillvalue=self.padding_idx)
                else:
                    padwalk = torch.index_select(walk, 0, torch.tensor([i for i in range(self.walk_length)]).to(self.device))
                padwalk = padwalk.unsqueeze(1)
                walks.append(padwalk)

            x = torch.cat([t for t in walks], dim=1)
            x = x.transpose(0, -1)

            y = getattr(batch, self.y_vars)
            y = y.transpose(0, -1)

            yield RandomWalkMask(x, y, pad=1)

    def __len__(self):
        return len(self.dl)
