import torch
from dataset.batch.wrapper.BasicWrapper import BasicWrapper
from common.tensor.TensorOp import TensorOp
from dataset.batch.mask.RandomWalkMask import RandomWalkMask


class AstPathWrapper(BasicWrapper):

    def __init__(self, iter, y_fields, padding_idx, walk_times=48, walk_length=11, device=torch.device("cuda:0")):
        self.dl = iter
        x_fields = list()
        x_fields.append("target")
        for i in range(walk_times):
            x_fields.append("astpath_" + str(i))
        self.x_fields = x_fields
        self.y_fields = y_fields
        self.padding_idx = padding_idx
        self.walk_length = walk_length
        self.device = device

    def __iter__(self):
        """
        一共有三种不同来源的contexts， 分别是jimple，IR(trans)，和comment
        这里采用最简单的方法，直接将不同来源的contexts线性连接
        """
        for batch in self.dl:
            paths = []
            for x_fields in self.x_fields:
                path = getattr(batch, x_fields)
                if path.shape[0] < self.walk_length:
                    padwalk = TensorOp.tpad(path, dim=0, n=abs(self.walk_length-path.shape[0]), fillvalue=self.padding_idx)
                else:
                    padwalk = torch.index_select(path, 0, torch.tensor([i for i in range(self.walk_length)]).to(self.device))
                padwalk = padwalk.unsqueeze(1)
                paths.append(padwalk)
            x = torch.cat([t for t in paths], dim=1)
            x = x.transpose(0, -1)

            y = getattr(batch, self.y_fields)
            y = y[:20, :]
            y = y.transpose(0, -1)

            yield RandomWalkMask(x, y, pad=1)

    def __len__(self):
        return len(self.dl)