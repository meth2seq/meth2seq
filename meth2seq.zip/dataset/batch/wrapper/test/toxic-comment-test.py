import pandas as pd
import numpy as np
import torch
from torchtext.data import Field
from torchtext.data import TabularDataset
from torchtext.data import Iterator, BucketIterator


tokenize = lambda x: x.split()
TEXT = Field(sequential=True, tokenize=tokenize, lower=True)
LABEL = Field(sequential=False, use_vocab=False)

tv_datafields = [("id", None),
                 ("comment_text", TEXT), ("toxic", LABEL),
                 ("severe_toxic", LABEL), ("threat", LABEL),
                 ("obscene", LABEL), ("insult", LABEL),
                 ("identity_hate", LABEL)]

trn, vld = TabularDataset.splits(
        path="/home/qwe/zfy_lab/practical-torchtext/data/",
        train='train.csv', validation="valid.csv",
        format='csv',
        skip_header=True,
        fields=tv_datafields)

tst_datafields = [("id", None), ("comment_text", TEXT)]

tst = TabularDataset(
        path="/home/qwe/zfy_lab/practical-torchtext/data/test.csv", # the file path
        format='csv',
        skip_header=True,
        fields=tst_datafields)

TEXT.build_vocab(trn)


train_iter, val_iter = BucketIterator.splits(
        (trn, vld), # we pass in the datasets we want the iterator to draw data from
        batch_sizes=(64, 64),
        device=-1, # if you want to use the GPU, specify the GPU number here
        sort_key=lambda x: len(x.comment_text), # the BucketIterator needs to be told what function it should use to group the data.
        sort_within_batch=False,
        repeat=False # we pass repeat=False because we want to wrap this Iterator layer.
)