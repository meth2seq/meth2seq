import torch
import torch.nn as nn
from torchtext import data, datasets
from torchtext.data import BucketIterator
import spacy
from model.transformer.Model import Model
from training.loss.wrapper.LossWrapper import LossWrapper
from training.opt.OptimWrapper import OptimWrapper
from app.run.RunEpoch import RunEpoch
from training.loss.compute.SimpleLossCompute import SimpleLossCompute
from dataset.batch.wrapper.IWSLTWrapper import IWSLTTranslationBatchWrapper
from evaluating.decode.Decode import Decode
from dataset.batch.wrapper.MyIterator import MyIterator

global max_src_in_batch, max_tgt_in_batch
def batch_size_fn(new, count, sofar):
    "Keep augmenting batch and calculate total number of tokens + padding."
    global max_src_in_batch, max_tgt_in_batch
    if count == 1:
        max_src_in_batch = 0
        max_tgt_in_batch = 0
    max_src_in_batch = max(max_src_in_batch,  len(new.src))
    max_tgt_in_batch = max(max_tgt_in_batch,  len(new.trg) + 2)
    src_elements = count * max_src_in_batch
    tgt_elements = count * max_tgt_in_batch
    return max(src_elements, tgt_elements)


spacy_de = spacy.load('de')
spacy_en = spacy.load('en')

def tokenize_de(text):
    return [tok.text for tok in spacy_de.tokenizer(text)]

def tokenize_en(text):
    return [tok.text for tok in spacy_en.tokenizer(text)]

BOS_WORD = '<s>'
EOS_WORD = '</s>'
BLANK_WORD = "<blank>"
SRC = data.Field(tokenize=tokenize_de, pad_token=BLANK_WORD)
TGT = data.Field(tokenize=tokenize_en, init_token = BOS_WORD,
                 eos_token = EOS_WORD, pad_token=BLANK_WORD)

# device
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
print("current device is :", device)


# build data
MAX_LEN = 100
train, val, test = datasets.IWSLT.splits(
    exts=('.de', '.en'), fields=(SRC, TGT),
    filter_pred=lambda x: len(vars(x)['src']) <= MAX_LEN and
        len(vars(x)['trg']) <= MAX_LEN)
MIN_FREQ = 2
SRC.build_vocab(train.src, min_freq=MIN_FREQ)
TGT.build_vocab(train.trg, min_freq=MIN_FREQ)

padding_idx = TGT.vocab.stoi[BLANK_WORD]
BATCH_SIZE = 12

train_iter1 = MyIterator(train, batch_size=BATCH_SIZE, device=0,
                            repeat=False, sort_key=lambda x: (len(x.src), len(x.trg)),
                            batch_size_fn=batch_size_fn, train=True)
valid_iter1 = MyIterator(val, batch_size=BATCH_SIZE, device=0,
                        repeat=False, sort_key=lambda x: (len(x.src), len(x.trg)),
                        batch_size_fn=batch_size_fn, train=False)

train_iter2 = BucketIterator(train, batch_size=BATCH_SIZE, device=device,
                        repeat=False, sort_key=lambda x: (len(x.src), len(x.trg)),train=True)
valid_iter2 = BucketIterator(val, batch_size=BATCH_SIZE, device=device,
                        repeat=False, sort_key=lambda x: (len(x.src), len(x.trg)),train=False)

train_wrapper = IWSLTTranslationBatchWrapper(train_iter1, "src", "trg", padding_idx)
valid_wrapper = IWSLTTranslationBatchWrapper(valid_iter1, "src", "trg", padding_idx)

print(next(valid_iter1.__iter__()))
print(next(valid_iter2.__iter__()))
print(next(valid_wrapper.__iter__()))
