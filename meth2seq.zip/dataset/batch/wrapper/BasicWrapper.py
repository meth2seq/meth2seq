"""
batch wrapper provides a more convenient way to iterate over a torchtext.data.Batch object.
"""


class BasicWrapper:

    def __init__(self, iterator, x_fields, y_fileds, padding_idx):
        """
        init method
        :param iterator: any object that extends the torchtext.data.Iterator
        :param x_fields: fields in independent variable
        :param y_fileds: fields in dependent variable
        """
        self.iter = iterator
        self.x_fields = x_fields
        self.y_fields = y_fileds

    def __iter__(self):
        """
        define the way it iterates.
        you can decide the output shape and if it is masked.
        :return: a batch of samples
        """
        pass

    def __len__(self):
        """
        return the length of the iterator
        :return:
        """
        pass
