import torch
import numpy as np
from common.tensor.TensorOp import TensorOp


class RandomWalkMask:

    def __init__(self, src, tgt=None, pad=1):
        self.src = src
        mask = (src != pad)
        self.src_mask = TensorOp.bool_narrow3D(mask).unsqueeze(-2)

        if tgt is not None:
            self.tgt = tgt[:, :-1]
            self.tgt_y = tgt[:, 1:]
            self.tgt_mask = self.make_tgt_mask(self.tgt, pad)
            self.ntokens = (self.tgt_y != pad).data.sum()

    @staticmethod
    def make_tgt_mask(tgt, pad):
        "mask: 1.padding; 2.future words"
        tgt_mask = (tgt != pad).unsqueeze(-2)
        tgt_subsequence_mask = RandomWalkMask.subsequent_mask(tgt.size(-1)).type_as(tgt_mask.data)
        final_mask = tgt_mask & tgt_subsequence_mask # bit-wise AND
        return final_mask

    @staticmethod
    def subsequent_mask(size):
        "mask out subsequent positions."
        attn_shape = (1, size, size)
        subsequence_mask = np.triu(np.ones(attn_shape), k=1).astype('uint8')
        return torch.from_numpy(subsequence_mask) == 0