from ..core.refine import Refiner


class PathRefiner(Refiner):

    def __init__(self):
        super(PathRefiner, self).__init__()

    def refine(self, tokens):
        res = []
        for t in tokens:
            t = self.do_special_case(t)
            t = self.refine_letters(t)
            if not self.is_empty(t) and self.is_valid(t):
                res.append(t)
        return res