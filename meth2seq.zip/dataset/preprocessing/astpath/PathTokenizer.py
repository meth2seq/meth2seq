from ..core.tokenize import Tokenizer


class PathTokenizer(Tokenizer):

    def __init__(self):
        super(PathTokenizer, self).__init__()

