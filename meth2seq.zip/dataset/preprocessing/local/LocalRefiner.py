from ..core.refine import Refiner


class LocalRefiner(Refiner):
    
    def __init__(self):
        super(LocalRefiner, self).__init__()

    def restrict_len(self, tokens, threshold=10):
        if len(tokens) > threshold:
            return tokens[:threshold]
        else:
            return tokens