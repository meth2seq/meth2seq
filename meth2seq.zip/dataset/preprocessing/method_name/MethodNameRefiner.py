from ..core.refine import Refiner


class MethodNameRefiner(Refiner):

    def __init__(self):
        super(MethodNameRefiner, self).__init__()
