from ..core.tokenize import Tokenizer


class MethodNameTokenizer(Tokenizer):

    def __init__(self):
        super(MethodNameTokenizer, self).__init__()
        self.special_cases = []
        self.stoplist = []