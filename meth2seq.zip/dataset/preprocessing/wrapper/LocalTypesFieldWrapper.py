from ..local.LocalTokenizer import LocalTokenizer
from ..local.LocalRefiner import LocalRefiner


class LocalTypesFieldWrapper:

    def __init__(self):
        pass

    @staticmethod
    def tokenize(input):
        tk = LocalTokenizer()
        sp1 = tk.simple_split(input)
        return sp1

    @staticmethod
    def preprocess(input):
        rf = LocalRefiner()
        input = rf.restrict_len(input)
        return input

    @staticmethod
    def postprocess(input):
        pass