import re
from ..jimple.JimpleTokenizer import JimpleTokenizer
from ..jimple.JimpleRefiner import JimpleRefiner


class JimpleFieldWrapper:

    def __init__(self):
        pass

    @staticmethod
    def tokenize(input, before_processing=True, tokenize_level=0):
        """
        tokenize method that will be passed to torchtext.data.Field()
        :param input: getattr(example, column_name), type str
        :param before_processing: if filter low quality names & handle special name cases before start tokenizing
        :param tokenize_level: 0 -- only camel split; 1 -- camel and ninjia split
        :return: tokenized tokens, as a list
        """
        # print(input)
        tk = JimpleTokenizer()
        if before_processing is True:
            input = re.sub('[0-9]', '', input)
            # INIT_BITSET, SET$ONE
            if all(x.isupper() for x in input.replace('_', '').replace('$', '')):
                input = input.lower()
            # mCOLLECTION
            if input[0].islower() and all(x.isupper() for x in input[1:].replace('_', '').replace('$', '')):
                input = input[1:].lower()

        res = []
        if tokenize_level == 0:
            for t in tk.simple_split(input):
                res.extend(tk.camel_split(t))
        elif tokenize_level == 1:
            tokens = []
            for t in tk.simple_split(input):
                tokens.extend(tk.camel_split(t))
            for t in tokens:
                res.extend(tk.ninja_split(t))
        for t in res:
            if not tk.is_valid_token(t):
                res = list(filter(t.__ne__, res))
        # print(res)
        return res

    @staticmethod
    def preprocess(input, second_split=False, lemmatize=False, need_refine=True):
        """
        :param input: tokenized tokens, type: list
        :param second_split: if need to ninjia split twice
        :param lemmatize: if need to lemmatize tokens
        :param need_refine: if need to refine tokens
        :return: list of processed tokens
        """
        tk = JimpleTokenizer()
        rf = JimpleRefiner()
        # split twice
        tokens = []
        for t in input:
            tokens.extend(tk.split_twice(t) if second_split else [t])
        # lemmatize
        lemma_tokens = tk.spacy_lemmatize(tokens) if lemmatize else tokens
        # refine
        res = rf.refine(lemma_tokens) if need_refine else lemma_tokens
        # print(res)
        # print('--------------')
        return res

    @staticmethod
    def postprocess(input):
        pass
