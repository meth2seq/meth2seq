from ..local.LocalTokenizer import LocalTokenizer
from ..local.LocalRefiner import LocalRefiner


class LocalNamesFieldWrapper:

    def __init__(self):
        pass

    @staticmethod
    def tokenize(input):
        res = list()
        tk = LocalTokenizer()
        sp1 = tk.simple_split(input)
        for t in sp1:
            sp2 = tk.camel_split(t)
            for sp in sp2:
                res.append(sp)
        # sp3 = [tk.ninja_split(t) for t in sp2]
        return res

    @staticmethod
    def preprocess(input):
        tf = LocalRefiner()
        res = tf.refine(input)
        return res

    @staticmethod
    def postprocess(input):
        pass