import re
from ..astpath.PathTokenizer import PathTokenizer
from ..astpath.PathRefiner import PathRefiner


class AstPathFieldWrapper():

    def __init__(self):
        pass

    @staticmethod
    def tokenize(input):
        tk = PathTokenizer()
        sp1 = tk.simple_split(input)
        return sp1

    @staticmethod
    def preprocess(input):
        tf = PathRefiner()
        res = tf.refine(input)
        return res
