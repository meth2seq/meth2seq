import random


def randfile(path1, path2):
    with open(path1 , 'r') as f:
        lines = f.readlines()
        random.shuffle(lines)
        with open(path2, 'w') as f:
            for line in lines:
                f.write(line)
                f.write('\n')