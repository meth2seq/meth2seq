from dataset.generator.RandomWalkBasicIter import RandomWalkBasicIter
from dataset.dot.Delimiter import Delimiter
import random
import csv
import itertools
from tqdm import tqdm


class AstPathIter(RandomWalkBasicIter):

    def __iter__(self):
        delim = Delimiter()
        with open(self.in_path + "features.txt", "r") as f:
            lines = f.readlines()
            random.shuffle(lines)
            count = 0
            errcount = 0
            for line in lines:
                count += 1
                if len(line) > 1 and line.find(delim.full_name_level) != -1:
                    # print(line)
                    target = line.split(delim.full_name_level)[0]
                    walks = line.split(delim.full_name_level)[1].split(delim.walk_level)
                    if self.is_valid_astpath(target):
                        yield target, walks
                elif len(line) > 1:
                    errcount += 1

    def __len__(self):
        # option 1
        # return sum(1 for i in open(self.path, 'rb'))
        with open(self.in_path + "features.txt", 'r') as f:
            return sum(bl.count("\n") for bl in RandomWalkBasicIter.blocks(f))


    def is_valid_astpath(self, target):
        if len(target) < 1:
            return False
        if not any(c.isalpha() for c in target):
            return False
        return True

    def dict_to_csv_toy(self, times, trim=False):
        fieldnames = self.get_field_names()
        with open(self.out_path + "toy.csv", "w") as csv_file:
            writer = csv.DictWriter(csv_file, fieldnames=fieldnames)
            writer.writeheader()
            # 开始遍历
            it = itertools.islice(self, times)
            for t in it:
                name = t[0]
                walks = t[1]
                simplename = AstPathIter.get_simple_name(name)
                # 因为get_simple_name会过滤掉stack和this变量，如果过滤后为空就不写入csv文件
                if len(simplename) > 0:
                    row = self.get_row(simplename, walks)
                    writer.writerow(row)

    def dict_to_csv_total(self, trim=False):
        fieldnames = self.get_field_names()
        with open(self.out_path + "total.csv", "w") as csv_file:
            writer = csv.DictWriter(csv_file, fieldnames=fieldnames)
            writer.writeheader()
            # 开始遍历
            for t in tqdm(self):
                name = t[0]
                walks = t[1]
                simplename = AstPathIter.get_simple_name(name)
                if len(simplename) > 0:
                    row = self.get_row(simplename, walks)
                    writer.writerow(row)

    def dict_to_csv_split(self, trim=False):
        fieldnames = self.get_field_names()
        total = len(self)
        train_num, val_num, test_num = AstPathIter.compute_split_ratio(total)
        train_num = 140000
        val_num = 40000
        test_num = 100000
        with open(self.out_path + "train.csv", "w") as csv1:
            with open(self.out_path + "val.csv", "w") as csv2:
                with open(self.out_path + "test.csv", "w") as csv3:
                    writer1 = csv.DictWriter(csv1, fieldnames=fieldnames)
                    writer2 = csv.DictWriter(csv2, fieldnames=fieldnames)
                    writer3 = csv.DictWriter(csv3, fieldnames=fieldnames)
                    writer1.writeheader()
                    writer2.writeheader()
                    writer3.writeheader()
                    count = 0
                    for t in tqdm(self, total=total):
                        if count < train_num:
                            name = t[0]
                            walks = t[1]
                            simplename = AstPathIter.get_simple_name(name)
                            if len(simplename) > 0:
                                row = self.get_row(simplename, walks)
                                writer1.writerow(row)
                        elif train_num <= count < train_num + val_num:
                            name = t[0]
                            walks = t[1]
                            simplename = AstPathIter.get_simple_name(name)
                            if len(simplename) > 0:
                                row = self.get_row(simplename, walks)
                                writer2.writerow(row)
                        else:
                            name = t[0]
                            walks = t[1]
                            simplename = AstPathIter.get_simple_name(name)
                            if len(simplename) > 0:
                                row = self.get_row(simplename, walks)
                                writer3.writerow(row)
                        count += 1

    def get_field_names(self):
        res = list()
        res.append("target");
        for i in range(self.max_walk_times):
            res.append("astpath_" + str(i))
        return res

    def get_row(self, simple_name, walks):
        delim = Delimiter()
        row = dict()
        row["target"] = simple_name
        times = len(walks) if len(walks) < self.max_walk_times else self.max_walk_times
        for i in range(self.max_walk_times):
            if i in range(times):
                walk_list = self.walk_split(walks[i])
                walk_str = ",".join(walk_list)
                row["astpath_" + str(i)] = walk_str.replace("\n", "")
            else:
                row["astpath_" + str(i)] = self.pad
        return row

    @staticmethod
    def label_clean(input):
        return input.strip("\"")
        # return re.sub(r'[^a-zA-Z\s]', ' ', input)
        # return re.sub(r'[\[\]\"\'\\]', "", input)

    def walk_split(self, walk):
        walk = walk.replace(",", "_").replace("^", "_")
        return walk.split("_")


    @staticmethod
    def get_simple_name(fullname):
        # return fullname
        name_list = fullname.split("|")
        return " ".join(name_list)

