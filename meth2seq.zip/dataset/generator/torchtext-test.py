from dataset.generator.NamingIter import NamingIter
from torchtext.data import Field
from torchtext.data import Dataset, TabularDataset
from torchtext.data import Iterator, BucketIterator

NAME = Field()
JIMPLE = Field()
IR = Field()
TRANS = Field()
COMMENT = Field()

fields = []
fields.append(("method_name", NAME))
for i in range(48):
    fields.append(("jimple_" + str(i), JIMPLE))
    fields.append(("ir_"+str(i), IR))
    fields.append(("trans_"+str(i), TRANS))
fields.append(("comment", COMMENT))

toy = TabularDataset(path="/home/qwe/disk1/data_SoC/test/total.csv", format="csv", fields=fields, skip_header=True)
print(getattr(toy[1], "method_name"))
print(getattr(toy[1], "jimple_1"))
print(getattr(toy[1], "ir_1"))
print(getattr(toy[1], "trans_1"))