from dataset.generator.RandomWalkIter import RandomWalkIter
import random

class RandomWalkShuffleIter(RandomWalkIter):

    # def __init__(self, path):
    #     super(RandomWalkShuffleIter, self).__init__(path)

    def __iter__(self):
        with open(self.path, 'r') as f:
            lines = f.readlines()
            random.shuffle(lines)
            for line in lines:
                if len(line) > 1:
                    name = line.split(':::')[0]
                    walks = line.split(':::')[1].split('$$$')[:-1]  # a$$$b$$$
                    yield name, walks