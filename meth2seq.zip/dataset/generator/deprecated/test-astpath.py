import os
input_file = "/home/qwe/disk1/sources/astpath_sources/features.txt"

with open(input_file, "r") as f:
    for line in f.readlines():
        if len(line) > 1:
            print(line.strip())