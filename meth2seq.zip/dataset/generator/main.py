from dataset.generator.NamingIter import NamingIter
import csv
import itertools
from dataset.dot.Delimiter import Delimiter
from dataset.generator.LocalIter import LocalIter
from dataset.generator.AstPathIter import AstPathIter
from dataset.generator.NoPDGIter import NoPDGIter


"""IR"""
# in_path = "/home/qwe/disk1/data_SoC/files_IR/"
# output = "/home/qwe/disk1/data_SoC/files_IR/"
# it = IRIter(in_path, output)
# # 187933
# it.process(split=True)

"""local_name"""
# in_path = "/home/qwe/disk1/data_SoC/files_IR/method_name/"
# output = "/home/qwe/disk1/data_SoC/files_IR/local_name/types/"
# it = LocalIter(in_path, output)
# it.process(split=True)

"""new data method name"""
# in_path = "/home/qwe/disk1/data_SoC/files_new/raw/"
# output = "/home/qwe/disk1/data_SoC/files_new/method_name/"
# it = NamingIter(in_path, output)
# it.process(split=True, trim=True)

"""test ast path iter"""
# in_path = "/home/qwe/disk1/sources/astpath_sources/"
# output = "/home/qwe/disk1/zfy_lab/fytorch_data/astpaths/raw/"
# it = AstPathIter(in_path, output)
# it.process(split=True)

"""ablation study : no pdg"""
# in_path = "/home/qwe/disk1/data_SoC/files_new/ablation_study/no_pdg_path/raw/"
# output = "/home/qwe/disk1/data_SoC/files_new/ablation_study/no_pdg_path/method_name/"
# it = NoPDGIter(in_path, output)
# it.process(split=True)

"""naming walk length=1"""
# in_path = "/home/qwe/disk1/data_SoC/files_new/sensitive_study/length/raw/"
# output = "/home/qwe/disk1/zfy_lab/fytorch_data/sensitive/length/"
# it = NamingIter(in_path, output)
# it.process(split=True)

"""local naming"""
# in_path = "/home/qwe/disk1/data_SoC/files_new/source_var/raw/"
# output = "/home/qwe/disk1/zfy_lab/fytorch_data/source_var/"
# it = LocalIter(in_path, output)
# it.process(split=True)

"""local naming using astpath"""
in_path = "/home/qwe/disk1/zfy_lab/fytorch_data/source_var/evaluation/raw/"
output = "/home/qwe/disk1/zfy_lab/fytorch_data/source_var/evaluation/"
it = LocalIter(in_path, output)
it.process(split=True)
# for t, walk in it:
#     print(t)
#     print(walk)
#     print("------")