from dataset.dot.Delimiter import Delimiter


class RandomWalkBasicIter:
    """
    对于random walk进行遍历的基类，其子类的变形包括以下方面：
    1.遍历是是否采取random shuffle的策略
    2.target信息来源：方法名，局部变量名，参数名，注释
    """

    def __init__(self, in_path, out_path):
        self.in_path = in_path
        self.out_path = out_path
        self.max_walk_times = None
        self.pad = None
        self.set_basic_iter_properties()

    def __iter__(self):
        pass

    def __len__(self):
        pass

    @staticmethod
    def blocks(files, size=65536):
        while True:
            b = files.read(size)
            if not b: break
            yield b

    @staticmethod
    def compute_split_ratio(total):
        a = int(total * 0.7)
        b = int(total * 0.1)
        c = total - a - b
        return a, b, c

    @staticmethod
    def get_simple_name(fullname):
        pass

    @staticmethod
    def get_node_attr(node, key):
        delim = Delimiter()
        if node == "cfg":
            return node
        if node == "data_flow":
            return node
        if node == "calling":
            return node
        if node == "extra":
            return node
        if key == "jimple":
            jimple = node.split(delim.label_level)[0]
            return RandomWalkBasicIter.label_clean(jimple)
        if key == "ir":
            ir = node.split(delim.label_level)[-1].split("###")[0]
            return RandomWalkBasicIter.label_clean(ir)
        if key == "trans":
            trans = node.split(delim.label_level)[-1].split("###")[-1]
            return RandomWalkBasicIter.label_clean(trans)
        raise ValueError("unchecked node value")

    @staticmethod
    def label_clean(input):
        return input.strip("\"")
        # return re.sub(r'[^a-zA-Z\s]', ' ', input)
        # return re.sub(r'[\[\]\"\'\\]', "", input)

    def set_basic_iter_properties(self, max_walk_times=48, pad="<pad>"):
        self.max_walk_times = max_walk_times
        self.pad = pad

    def process(self, trim=False, split=False, times=-1):
        """
        构建random walk词典，作为pandas DataFrame的输入
        :param trim: 是否精简方法名
        :param split: 是否分训练 / 测试 / 验证集
        :param times: 如果为-1则返回全集词典，如果非-1则返回词典的指定次数子集作为测试样例; 注意如果time != -1，则split一定为False
        :return:
        """
        if times != -1:
            assert split is False
            return self.dict_to_csv_toy(times, trim)
        elif split:
            return self.dict_to_csv_split(trim)
        else:
            return self.dict_to_csv_total(trim)

    def dict_to_csv_toy(self, times, trim):
        pass

    def dict_to_csv_total(self, trim):
        pass

    def dict_to_csv_split(self, trim):
        pass

