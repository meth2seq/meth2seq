from dataset.generator.RandomWalkBasicIter import RandomWalkBasicIter
from dataset.dot.Delimiter import Delimiter
import random
import csv
import itertools
from tqdm import tqdm


class SourceVarIter(RandomWalkBasicIter):

    def __init__(self):
        with open(self.in_path + "locals.txt", "r") as f:
            lines = f.readlines()
            random.shuffle(lines)
            count = 0
            errcount = 0
            for line in lines:
                count += 1
                if len(line) > 1 and line.find("|||") != -1:
                    # print(line)
                    qualifier = line.split("|||")[0]
                    locals = line.split("|||")[1].split(", ")
                    if self.is_valid(qualifier):
                        yield qualifier, locals
                elif len(line) > 1:
                    errcount += 1
    def __len__(self):
        # option 1
        # return sum(1 for i in open(self.path, 'rb'))
        with open(self.in_path + "features.txt", 'r') as f:
            return sum(bl.count("\n") for bl in RandomWalkBasicIter.blocks(f))


    def is_valid(self, qualifier):
        if len(qualifier) < 1:
            return False
        if not any(c.isalpha() for c in qualifier):
            return False
        return True