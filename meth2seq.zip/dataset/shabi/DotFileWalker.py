# import os
# import traceback
# from tqdm import tqdm
# from networkx.drawing.nx_pydot import read_dot
# from .randomWalk import RandomWalk
# from .jimple import Jimple
# from .preprocess import Preprocess
# from .jimple_translation import Natural
#
#
class DotFileWalker:

    def __init__(self, paths):
        self.path = paths.split('#')
        self.map_files = []
        self.dot_files = []
        self.dictionary = {}
        self.read_dot_files()
#
#     def __iter__(self):
#         for dot_file in self.dot_files:
#             yield dot_file
#
#     def __len__(self):
#         return len(self.dot_files)
#
#     def read_dot_files(self):
#         map_files = []
#         dot_files = []
#         # get all shabi files and map files
#         for path in self.path:
#             for root, dirs, files in os.walk(path):
#                 for file in files:
#                     if file == 'cfg_map.txt':
#                         map_files.append(os.path.join(root, file))
#                     if file.endswith('CFG.shabi'):
#                         dot_files.append(os.path.join(root, file))
#         self.map_files = map_files
#         self.dot_files = dot_files
#
#     def get_node_info(self, exc_path):
#         dictionary = {}
#         err_cases = []
#         errcount = 0
#         count = 0
#         for dot in tqdm(self.__iter__()):
#             try:
#                 # read
#                 g = read_dot(dot)
#                 # read from info node
#                 info_node = DotFileWalker.find_info_node(g)
#                 full_name = g.nodes[info_node]['fullMethodName'].strip('\"')
#                 simple_name = g.nodes[info_node]['simlpeMethodName'].strip('\"')
#                 comment = g.nodes[info_node]['natural'].replace('\n', ' ')
#                 local_names = g.nodes[info_node]['local']
#                 param_names = g.nodes[info_node]['param']
#                 # get graph
#                 relabelled_graph = DotFileWalker.remove_info_and_relabel(g, info_node)
#                 # get random walk
#                 random_walks = RandomWalk.generate_random_walk(g, walk_mode=2)
#
#                 info = (count, dot, simple_name, comment, local_names, param_names, random_walks)
#                 dictionary.setdefault(full_name, None)
#                 dictionary[full_name] = info
#                 count += 1
#             except Exception:
#                 count += 1
#                 errcount += 1
#                 err_cases.append(dot)
#                 DotFileWalker.excpetion_write(traceback.format_exc(), exc_path)
#                 DotFileWalker.excpetion_write(dot, exc_path)
#                 DotFileWalker.excpetion_write("------------------", exc_path)
#                 continue
#         print(count, errcount)
#         self.dictionary = dictionary
#
#     def output_to_file(self, base_path):
#         dictionary = self.dictionary
#
#         # id
#         with open(base_path + "/id.txt", 'w') as f:
#             for k, v in dictionary.items():
#                 id = v[0]
#                 f.write(k + ':::' + str(id))
#                 f.write('\n')
#
#         # shabi path
#         with open(base_path + "/shabi.txt", 'w') as f:
#             for k, v in dictionary.items():
#                 dot = v[1]
#                 f.write(k + ':::' + str(dot))
#                 f.write('\n')
#
#         # simple name
#         with open(base_path + "/simple.txt", 'w') as f:
#             for k, v in dictionary.items():
#                 simple_name = v[2]
#                 f.write(k + ':::' + str(simple_name))
#                 f.write('\n')
#
#         # comment
#         with open(base_path + "/comment.txt", 'w') as f:
#             for k, v in dictionary.items():
#                 comment = v[3]
#                 f.write(k + ':::' + str(comment))
#                 f.write('\n')
#
#         # local
#         with open(base_path + "/local.txt", 'w') as f:
#             for k, v in dictionary.items():
#                 local = v[4]
#                 f.write(k + ':::' + str(local))
#                 f.write('\n')
#
#         # param
#         with open(base_path + "/param.txt", 'w') as f:
#             for k, v in dictionary.items():
#                 param = v[5]
#                 f.write(k + ':::' + str(param))
#                 f.write('\n')
#
#         # random_walk
#         with open(base_path + "/local.txt", 'w') as f:
#             for k, v in dictionary.items():
#                 walk = v[6]
#                 f.write(k + ':::' + str(walk))
#                 f.write('\n')
#
#     @staticmethod
#     def find_info_node(g):
#         info_node = None
#         # iter nodes, find info node and relabel
#         for node in g.nodes():
#             if g.nodes[node].get('natural') != None:
#                 info_node = node
#         assert info_node is not None
#         return info_node
#
#     @staticmethod
#     def remove_info_and_relabel(g, info_node):
#         g.remove_node(info_node)
#         for node in g.nodes():
#             label = g.node[node]['label']
#             jimple = Jimple(label)
#             simple_jimple = jimple.get_simple_jimple()
#             g.node[node]['simple_jimple'] = Preprocess.clean_label(simple_jimple)
#         for e in g.edges:
#             labels = g.edges[e]
#             if labels.get('color') == None:
#                 g.edges[e]['label'] = 'cfg'
#             elif labels.get('color') == 'red':
#                 g.edges[e]['label'] = 'data_flow'
#             elif labels.get('color') == 'blue':
#                 g.edges[e]['label'] = 'extra'
#             elif labels.get('color') == 'green':
#                 g.edges[e]['label'] = 'calling'
#             else:
#                 print('err edge type')
#         return g
#
#     @staticmethod
#     def get_jimple_labels(g):
#         labels = []
#         for n in g.nodes():
#             try:
#                 label = g.nodes[n]['label'].strip('\"')
#                 nl = Natural()
#                 jimple_nl = nl.determine_and_solve(label)
#                 labels.append(jimple_nl)
#             except Exception as e:
#                 continue
#         return labels
#
#     @staticmethod
#     def excpetion_write(exc, path):
#         with open(path, "a") as f:
#             f.write(exc)
#             f.write("\n")