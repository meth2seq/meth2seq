def get_f1(precision, recall):
    f1 = 2 * precision * recall / (precision + recall)
    return f1

a = 0.51690019961480724
b = 0.44733097066237353

print(get_f1(a, b))