### implement

- add trim function before tokenization

- walk_length no need be fixed

- 数据中存在空值，应该是由于预处理导致的

- 维护一个TOP5的checkpoints

- 完善模型保存、读取机制

- cuda semantic

### model

- 考虑pos enc设计

### test
