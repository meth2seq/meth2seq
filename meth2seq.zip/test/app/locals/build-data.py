import torch
from time import time
from dataset.preprocessing.wrapper.AstPathFieldWrapper import AstPathFieldWrapper
from torchtext.data import Field
from torchtext.data import Dataset, TabularDataset
from torchtext.data import Iterator, BucketIterator
from dataset.io.io import save_dataset, save_dataset4
from common.parameter.Params import Params
from common.parameter.ProcessedSamplesPath import ProcessedSamplesPath
from common.parameter.RawSamplesPath import RawSamplesPath

start = time()

# device
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
print("current device is :", device)

# training parameters
param = Params()
MAX_WALK_TIMES = param.MAX_WALK_TIMES
param.set_training_params(epochs=20)
EPOCHS = param.EPOCHS
BATCH_SIZE = param.BATCH_SIZE

# path setting
DATA_LOAD_PATH = "/home/qwe/disk1/zfy_lab/fytorch_data/source_var/evaluation/"
DATA_SAVE_PATH = "/home/qwe/disk1/zfy_lab/fytorch_data/source_var/evaluation/data/"

print("current data loading path: %s" % DATA_LOAD_PATH)
print("current data saving path: %s" % DATA_SAVE_PATH)

SRC = Field(tokenize=AstPathFieldWrapper.tokenize, preprocessing=AstPathFieldWrapper.preprocess,
               init_token="<s>", eos_token="<eos>")
NAME = Field(tokenize=AstPathFieldWrapper.tokenize, preprocessing=AstPathFieldWrapper.preprocess,
             init_token="<s>", eos_token="<eos>")

fields = list()
fields.append(("target", NAME))
for i in range(MAX_WALK_TIMES):
    fields.append(("astpath_"+str(i), SRC))

# build dataset
train, val, test = TabularDataset.splits(
    path=DATA_LOAD_PATH, train="train.csv", validation="val.csv", test="test.csv", format="csv",
    skip_header=True, fields=fields
)
print(len(train), len(val), len(test))
example = train[0]
print(getattr(example, "target"))
print(getattr(example, "astpath_0"))

# build vocab
SRC.build_vocab(train, val, test)
NAME.build_vocab(train, val, test)

# save dataset
save_dataset4(train, DATA_SAVE_PATH + "train_.csv")
save_dataset4(val, DATA_SAVE_PATH + "val_.csv")
save_dataset4(test, DATA_SAVE_PATH + "test_.csv")

# save vocab
vocab = {
    "src": SRC.vocab,
    "name": NAME.vocab
}

torch.save(vocab, DATA_SAVE_PATH + "vocab.pt")
print("build data time: %f" % (time() - start))  # 7593s
