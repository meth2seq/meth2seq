import torch
from torchtext.data import Field
from torchtext.data import Dataset, TabularDataset
from time import time
from common.parameter.Params import Params
from common.parameter.ProcessedSamplesPath import ProcessedSamplesPath
from torchtext.data import BucketIterator, Iterator
from dataset.batch.wrapper.AstPathWrapper import AstPathWrapper
from model.naming.Model import Model
from training.loss.wrapper.KLDivLossWithLabelSmoothing import KLDivLossWithLabelSmoothing
from training.opt.OptimWrapper import OptimWrapper
from training.loss.compute.SimpleLossCompute import SimpleLossCompute
from evaluating.decode.Decode import Decode
from evaluating.run.evaluate import eval2, eval3, eval4
from common.model.utils import save_checkpoint, save_dict_to_json, metrics_dict_msg

# device
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
print("current device is :", device)

# training parameters
param = Params()
MAX_WALK_TIMES = param.MAX_WALK_TIMES
param.set_training_params(epochs=20)
EPOCHS = param.EPOCHS
BATCH_SIZE = param.BATCH_SIZE

# path setting
DATA_LOAD_PATH = "/home/qwe/disk1/zfy_lab/fytorch_data/source_var/evaluation/data/"
MODEL_LOAD_PATH = "/home/qwe/disk1/zfy_lab/fytorch_data/source_var/evaluation/model/"
print("data loading path: %s" % DATA_LOAD_PATH)
print("load model from path %s " % MODEL_LOAD_PATH)

tokenize = lambda x: x.split(',')
SRC = Field(tokenize=tokenize, init_token="<s>", eos_token="<eos>")
NAME = Field(tokenize=tokenize, init_token="<s>", eos_token="<eos>")

fields = list()
fields.append(("id", None))
fields.append(("target", NAME))
for i in range(MAX_WALK_TIMES):
    fields.append(("astpath_"+str(i), SRC))

t = time()
# load dataset
train, val, test = TabularDataset.splits(
    path=DATA_LOAD_PATH, train="train_.csv", validation="val_.csv", test="test_.csv", format="csv",
    skip_header=True, fields=fields
)

# load vocab
ck = torch.load(DATA_LOAD_PATH + "vocab.pt")
vocab_src = ck["src"]
vocab_name = ck["name"]
SRC.vocab = vocab_src
NAME.vocab = vocab_name

# create iterator
def sort_key(x):
    total_length = 0
    name = getattr(x, "target")  # this happens when preprocessing is done, so type is list
    total_length += len(name)
    return total_length


train_iter, val_iter, test_iter = BucketIterator.splits(
    datasets=(train, val, test),
    batch_sizes=(BATCH_SIZE, BATCH_SIZE, BATCH_SIZE),
    sort_key=sort_key,
    sort_within_batch=False,
    device=device,
    repeat=False
)

# wrap the iterator
train_wrapper = AstPathWrapper(train_iter, "target", padding_idx=NAME.vocab.stoi["<pad>"], walk_times=MAX_WALK_TIMES)
val_wrapper = AstPathWrapper(val_iter, "target", padding_idx=NAME.vocab.stoi["<pad>"], walk_times=MAX_WALK_TIMES)
test_wrapper = AstPathWrapper(test_iter, "target", padding_idx=NAME.vocab.stoi["<pad>"], walk_times=MAX_WALK_TIMES)

"""model"""
model = Model.make_model(len(SRC.vocab), len(NAME.vocab), N=6)
model.cuda()
criterion = KLDivLossWithLabelSmoothing(len(NAME.vocab), padding_idx=0, smoothing=0.1)
criterion.cuda()
opt = OptimWrapper.get_std_opt(model)
train_loss_compute = SimpleLossCompute(model.generator, criterion, opt)
val_loss_compute = SimpleLossCompute(model.generator, criterion, None)



"""eval"""
checkpoint = torch.load(MODEL_LOAD_PATH + "best.pth.tar")
model.load_state_dict(checkpoint["state_dict"])
train_loss_compute.opt.optimizer.load_state_dict(checkpoint["optim_dict"])
model.eval()

# 2 3 1 0
# print(NAME.vocab.stoi["<s>"], NAME.vocab.stoi["<eos>"], NAME.vocab.stoi["<pad>"], NAME.vocab.stoi["<unk>"])
#
# from evaluating.run.evaluate import eval2, eval3, eval4, eval5, eval6
# metrics = eval2(model, val_wrapper, NAME.vocab.stoi["<s>"], NAME.vocab.stoi["<eos>"], NAME.vocab.stoi["<pad>"], NAME.vocab.stoi["<unk>"])
# print(metrics)

def get_name_from_ids(ids):
    name = []
    filtered = []
    for id in ids:
        if id not in [0,1,2,3]:
            filtered.append(id)
    for j in filtered:
        s = NAME.vocab.itos[j]
        name.append(s)
    return name

with open("/home/qwe/disk1/zfy_lab/fytorch_data/source_var/evaluation/model/predict_log.txt", "w") as f:
    for batch in train_wrapper:
        outs = []
        tgts = []
        BATCH_SIZE = batch.src.size(0)
        for i in range(BATCH_SIZE):
            src = batch.src[i:i + 1]
            src_mask = batch.src_mask[i:i + 1]
            tgt = batch.tgt_y[i:i + 1].squeeze().tolist()
            out = Decode.greedy_decode(model, src, src_mask, max_len=5, start_symbol=2).squeeze().tolist()
            pred_name = get_name_from_ids(out)
            tgt_name = get_name_from_ids(tgt)
            print(pred_name)
            print(tgt_name)
            print("---------------")
            # if pred_name == tgt_name:
            #     f.write(", ".join(tgt_name) + " : " + ", ".join(pred_name))
            #     f.write("\n")
            #     print(pred_name)
            #     print(tgt_name)
            #     print("-----------")