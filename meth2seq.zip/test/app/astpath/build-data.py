import torch
from time import time
from dataset.preprocessing.wrapper.AstPathFieldWrapper import AstPathFieldWrapper
from torchtext.data import Field
from torchtext.data import Dataset, TabularDataset
from torchtext.data import Iterator, BucketIterator
from dataset.io.io import save_dataset4
from common.parameter.Params import Params

start = time()

# preliminary
INPUT_BASE = "/home/qwe/disk1/zfy_lab/fytorch_data/astpaths/raw/"
OUTPUT_BASE = "/home/qwe/disk1/zfy_lab/fytorch_data/astpaths/data/"
param = Params()
MAX_WALK_TIMES = param.MAX_WALK_TIMES
device = param.device
SAVE_DATA_PATH = "/home/qwe/disk1/zfy_lab/fytorch_data/astpaths/data/"
SAVE_MODEL_PATH = "/home/qwe/disk1/zfy_lab/fytorch_data/astpaths/model/"

print("current data saving path: %s" % SAVE_DATA_PATH)
print("current model saving path: %s" % SAVE_MODEL_PATH)
print("current device is :", device)

NAME = Field(tokenize=AstPathFieldWrapper.tokenize, preprocessing=AstPathFieldWrapper.preprocess, init_token="<s>", eos_token="<eos>")
SRC = Field(tokenize=AstPathFieldWrapper.tokenize, preprocessing=AstPathFieldWrapper.preprocess, init_token="<s>", eos_token="<eos>")

fields = list()
fields.append(("target", NAME))
for i in range(MAX_WALK_TIMES):
    fields.append(("astpath_"+str(i), SRC))

# build dataset
train, val, test = TabularDataset.splits(
    path=INPUT_BASE, train="train.csv", validation="val.csv", test="test.csv", format="csv",
    skip_header=True, fields=fields
)

print(len(train), len(val), len(test))
# example = train[0]
# name = getattr(example, "target")
# path = getattr(example, "astpath_1")
# print(name, type(name))
# print(path, type(path))

SRC.build_vocab(train, val, test)
NAME.build_vocab(train, val, test)



# save dataset
save_dataset4(train, SAVE_DATA_PATH + "train_.csv")
save_dataset4(val, SAVE_DATA_PATH + "val_.csv")
save_dataset4(test, SAVE_DATA_PATH + "test_.csv")

# save vocab
vocab = {
    "src": SRC.vocab,
    "name": NAME.vocab
}

torch.save(vocab, SAVE_MODEL_PATH + "vocab.pt")
print("build data time: %f" % (time() - start))