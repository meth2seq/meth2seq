import torch
from time import time
from dataset.preprocessing.wrapper.JimpleFieldWrapper import JimpleFieldWrapper
from dataset.preprocessing.wrapper.MethodNameFieldWrapper import MethodNameFieldWrapper
from torchtext.data import Field
from torchtext.data import Dataset, TabularDataset
from torchtext.data import Iterator, BucketIterator
from dataset.io.io import save_dataset
from common.parameter.Params import Params

start = time()

# preliminary
INPUT_BASE = "/home/qwe/disk1/data_SoC/files_new/ablation_study/no_pdg_path/method_name"
param = Params()
MAX_WALK_TIMES = param.MAX_WALK_TIMES
device = param.device
SAVE_DATA_PATH = "/home/qwe/disk1/zfy_lab/fytorch_data/ablation/data"
SAVE_MODEL_PATH = "/home/qwe/disk1/zfy_lab/fytorch_data/ablation/model"

print("current data saving path: %s" % SAVE_DATA_PATH)
print("current model saving path: %s" % SAVE_MODEL_PATH)
print("current device is :", device)

SRC = Field(tokenize=JimpleFieldWrapper.tokenize, preprocessing=JimpleFieldWrapper.preprocess,
               init_token="<s>", eos_token="<eos>")
NAME = Field(tokenize=MethodNameFieldWrapper.tokenize, preprocessing=MethodNameFieldWrapper.preprocess,
             init_token="<s>", eos_token="<eos>")

fields = list()
fields.append(("method_name", NAME))
for i in range(MAX_WALK_TIMES):
    fields.append(("walk_"+str(i), SRC))

# build dataset
train, val, test = TabularDataset.splits(
    path=INPUT_BASE, train="train.csv", validation="val.csv", test="test.csv", format="csv",
    skip_header=True, fields=fields
)

# build vocab
SRC.build_vocab(train, val, test)
NAME.build_vocab(train, val, test)

# example = train[0]
# name = getattr(example, "method_name")
# walk = getattr(example, "walk_20")
# print(name)
# print(walk)

# save dataset
save_dataset(train, SAVE_DATA_PATH + "train_.csv")
save_dataset(val, SAVE_DATA_PATH + "val_.csv")
save_dataset(test, SAVE_DATA_PATH + "test_.csv")

# save vocab
vocab = {
    "src": SRC.vocab,
    "name": NAME.vocab
}

torch.save(vocab, SAVE_DATA_PATH + "vocab.pt")
print("build data time: %f" % (time() - start))
