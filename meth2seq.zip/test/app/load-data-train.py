import os
import torch
from time import time
from torchtext.data import Field
from torchtext.data import Dataset, TabularDataset
from torchtext.data import Iterator, BucketIterator
from common.parameter.Params import Params
from dataset.batch.wrapper.NamingWrapperMultiple import NamingWrapperMultiple
from model.naming.Model import Model
from training.loss.wrapper.KLDivLossWithLabelSmoothing import KLDivLossWithLabelSmoothing
from training.opt.OptimWrapper import OptimWrapper
from training.loss.compute.SimpleLossCompute import SimpleLossCompute
from training.run.RunEpoch import RunEpoch
from evaluating.run.evaluate import eval2, eval3
from common.model.utils import save_checkpoint, save_dict_to_json, metrics_dict_msg


# device
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
print("current device is :", device)

# preliminary
param = Params()
DATA_LOAD_PATH = "/home/qwe/disk1/zfy_lab/fytorch_data/method_name_new/data/"
MAX_WALK_TIMES = param.MAX_WALK_TIMES
param.set_training_params(epochs=20)
EPOCHS = param.EPOCHS
BATCH_SIZE = param.BATCH_SIZE
SAVE_MODEL_PATH = "/home/qwe/disk1/zfy_lab/fytorch_data/method_name_new/model/"
print("data loading path: %s" % DATA_LOAD_PATH)
print("save model to path %s " % SAVE_MODEL_PATH)

tokenize = lambda x: x.split(',')
SRC = Field(tokenize=tokenize, init_token="<s>", eos_token="<eos>")
NAME = Field(tokenize=tokenize, init_token="<s>", eos_token="<eos>")

fields = list()
fields.append(("id", None))
fields.append(("method_name", NAME))
for i in range(MAX_WALK_TIMES):
    fields.append(("jimple_" + str(i), SRC))
    fields.append(("ir_" + str(i), SRC))
    fields.append(("trans_" + str(i), SRC))
fields.append(("comment", SRC))

t = time()
# load dataset
train, val, test = TabularDataset.splits(
    path=DATA_LOAD_PATH, train="train_.csv", validation="val_.csv", test="test_.csv", format="csv",
    skip_header=True, fields=fields
)

# load vocab
ck = torch.load(SAVE_MODEL_PATH + "vocab.pt")
vocab_src = ck["src"]
vocab_name = ck["name"]
SRC.vocab = vocab_src
NAME.vocab = vocab_name
print(NAME.vocab.stoi.__len__())

# create iterator
def sort_key(x):
    total_length = 0
    name = getattr(x, "method_name")  # this happens when preprocessing is done, so type is list
    total_length += len(name)
    return total_length


train_iter, val_iter, test_iter = BucketIterator.splits(
    datasets=(train, val, test),
    batch_sizes=(BATCH_SIZE, BATCH_SIZE, BATCH_SIZE),
    sort_key=sort_key,
    sort_within_batch=False,
    device=device,
    repeat=False
)

# wrap the iterator
train_wrapper = NamingWrapperMultiple(train_iter, "method_name", padding_idx=NAME.vocab.stoi["<pad>"], walk_times=MAX_WALK_TIMES)
val_wrapper = NamingWrapperMultiple(val_iter, "method_name", padding_idx=NAME.vocab.stoi["<pad>"], walk_times=MAX_WALK_TIMES)
test_wrapper = NamingWrapperMultiple(test_iter, "method_name", padding_idx=NAME.vocab.stoi["<pad>"], walk_times=MAX_WALK_TIMES)

"""model"""
model = Model.make_model(len(SRC.vocab), len(NAME.vocab), N=6)
model.cuda()
criterion = KLDivLossWithLabelSmoothing(len(NAME.vocab), padding_idx=0, smoothing=0.1)
criterion.cuda()
opt = OptimWrapper.get_std_opt(model)
train_loss_compute = SimpleLossCompute(model.generator, criterion, opt)
val_loss_compute = SimpleLossCompute(model.generator, criterion, None)

"""train"""
best_f1 = 0.0
no_new_best_count = 0
for epoch in range(EPOCHS):
    print("EPOCH: " + str(epoch))
    model.train()
    loss = RunEpoch.run_epoch(train_wrapper, model, train_loss_compute)
    print("loss: %f" % loss)
    model.eval()
    val_metrics = eval3(model, val_wrapper, NAME.vocab.stoi["<s>"],
                        NAME.vocab.stoi["<eos>"], NAME.vocab.stoi["<pad>"], NAME.vocab.stoi["<unk>"])
    test_metrics = eval3(model, test_wrapper, NAME.vocab.stoi["<s>"],
                        NAME.vocab.stoi["<eos>"], NAME.vocab.stoi["<pad>"], NAME.vocab.stoi["<unk>"])
    print("val metric: " + metrics_dict_msg(val_metrics))
    print("test metric: " + metrics_dict_msg(test_metrics))
    val_f1 = val_metrics["f1"]

    is_best = val_f1 > best_f1
    checkpoint = {
        epoch: epoch,
        "state_dict": model.state_dict(),
        "optim_dict": train_loss_compute.opt.optimizer.state_dict()
    }
    save_checkpoint(checkpoint, is_best, SAVE_MODEL_PATH)

    if is_best:
        print("find new best f1")
        best_f1 = val_f1

        best_json_path = os.path.join(
            SAVE_MODEL_PATH, "metrics_val_best_weights.json")

        save_dict_to_json(val_metrics, best_json_path)
    else:
        no_new_best_count += 1

    if no_new_best_count > 5:
        print("5 epochs without new best, end training")
        break

print("time cost: ", time() - t)