import torch
from time import time
from dataset.preprocessing.wrapper.JimpleFieldWrapper import JimpleFieldWrapper
from dataset.preprocessing.wrapper.MethodNameFieldWrapper import MethodNameFieldWrapper
from torchtext.data import Field
from torchtext.data import Dataset, TabularDataset
from torchtext.data import Iterator, BucketIterator
from dataset.io.io import save_dataset, save_dataset2, save_dataset3
from common.parameter.Params import Params

start = time()

# preliminary
INPUT_BASE = "/home/qwe/disk1/zfy_lab/fytorch_data/sensitive/length/"
param = Params()
MAX_WALK_TIMES = param.MAX_WALK_TIMES
device = param.device
SAVE_DATA_PATH = "/home/qwe/disk1/zfy_lab/fytorch_data/sensitive/length/data/"
SAVE_MODEL_PATH = "/home/qwe/disk1/zfy_lab/fytorch_data/sensitive/length/model/"

print("current data saving path: %s" % SAVE_DATA_PATH)
print("current model saving path: %s" % SAVE_MODEL_PATH)
print("current device is :", device)

SRC = Field(tokenize=JimpleFieldWrapper.tokenize, preprocessing=JimpleFieldWrapper.preprocess,
               init_token="<s>", eos_token="<eos>")
NAME = Field(tokenize=MethodNameFieldWrapper.tokenize, preprocessing=MethodNameFieldWrapper.preprocess,
             init_token="<s>", eos_token="<eos>")

fields = list()
fields.append(("method_name", NAME))
for i in range(MAX_WALK_TIMES):
    fields.append(("jimple_"+str(i), SRC))
    fields.append(("ir_"+str(i), SRC))
    fields.append(("trans_"+str(i), SRC))
fields.append(("comment", SRC))

# build dataset
train, val, test = TabularDataset.splits(
    path=INPUT_BASE, train="train.csv", validation="val.csv", test="test.csv", format="csv",
    skip_header=True, fields=fields
)

# build vocab
SRC.build_vocab(train, val, test)
NAME.build_vocab(train, val, test)

# save dataset
save_dataset3(train, SAVE_DATA_PATH + "train_.csv")
save_dataset3(val, SAVE_DATA_PATH + "val_.csv")
save_dataset3(test, SAVE_DATA_PATH + "test_.csv")

# save vocab
vocab = {
    "src": SRC.vocab,
    "name": NAME.vocab
}

torch.save(vocab, SAVE_MODEL_PATH + "vocab.pt")
print("build data time: %f" % (time() - start))
