from networkx.drawing.nx_pydot import read_dot
from dataset.dot.NxGraph import NxGraph


dot = "/home/qwe/disk1/dots/projects2/spring-oauth/spring-oauth/AST_CFG_PDGdotInfo/org.springframework.security.oauth2.config.xml.AuthorizationServerBeanDefinitionParser/0_CFG.dot"
g = read_dot(dot)
nxGraph = NxGraph(g)
info_node = nxGraph.remove_info_node()
nxGraph.relabel_attrs()
rw = nxGraph.get_random_walks(mode=2)
print(len(rw))