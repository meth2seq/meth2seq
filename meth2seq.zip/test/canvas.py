l = ['a', 'b', 'c']
print("#".join(l))