

class DotPath:
    """
    管理关于dot文件的路径
    目前所有的dot文件位于/home/qwe/disk1/dots/路径下
    """

    def __init__(self):
        self.dot_files_path = None
        self.set_dot_files_path()

    def set_dot_files_path(self, path="/home/qwe/disk1/dots"):
        self.dot_files_path = path

    def get_dot_files_path(self):
        return self.dot_files_path
