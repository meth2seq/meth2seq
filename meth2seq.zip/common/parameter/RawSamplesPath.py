

class RawSamplesPath:
    """
    管理原始训练数据相关的路径
    """

    def __init__(self):
        """
        base路径：每个任务的主路径
        path路径：如果某个任务要分不同的设置进行，那么在base路径下为每个设置建立一个独立的path路径
        """
        # base路径
        self.base = "/home/qwe/disk1/data_SoC/files_IR/"
        self.method_name_base = self.base + "method_name/"
        self.local_name_base = self.base + "local_name/"
        self.param_name_base = self.base + "param_name/"
        self.comment_base = self.base + "comment/"

        # path路径
        self.method_name_path = None
        self.local_names_path = None
        self.local_types_path = None
        self.param_name_path = None
        self.comment_path = None

        # 调用setter方法
        self.set_method_name_paths()
        self.set_local_name_paths()
        self.set_param_name_paths()
        self.set_comment_paths()

    def set_method_name_paths(self):
        self.method_name_path = self.method_name_base

    def set_local_name_paths(self):
        self.local_names_path = self.local_name_base + "names/"
        self.local_types_path = self.local_name_base + "types/"

    def set_param_name_paths(self):
        self.param_name_path = self.param_name_base

    def set_comment_paths(self):
        self.comment_path = self.comment_base
