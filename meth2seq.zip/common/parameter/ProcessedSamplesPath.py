

class ProcessedSamplesPath:
    """
    管理经过pytorch text pipeline预处理之后的训练数据的存储路径
    """

    def __init__(self):
        """
        base路径：每个任务的主路径
        path路径：每个base路径下包括两个path路径: data/ 和 model/
        注意：并没有维护每个path路径下可能的不同设置（情况太多），需要手动设置特定的路径，如data/multi_src, data/single_src等
        """
        # base路径
        self.base = "/home/qwe/disk1/zfy_lab/fytorch_data/"
        self.method_name_base = self.base + "method_name/"
        self.local_name_base = self.base + "local_name/"
        self.param_name_base = self.base + "param_name/"
        self.comment_base = self.base + "comment/"

        # path路径
        self.method_name_data_path = None
        self.method_name_model_path = None
        self.local_name_data_path = None
        self.local_name_model_path = None
        self.param_name_data_path = None
        self.param_name_model_path = None
        self.comment_data_path = None
        self.comment_model_path = None

        # 调用setter方法
        self.set_method_name_paths()
        self.set_local_name_paths()
        self.set_param_name_path()
        self.set_comment_path()

    def set_method_name_paths(self):
        self.method_name_data_path = self.method_name_base + "data/"
        self.method_name_model_path = self.method_name_base + "model/"

    def set_local_name_paths(self):
        self.local_name_data_path = self.local_name_base + "data/"
        self.local_name_model_path = self.local_name_base + "model/"

    def set_param_name_path(self):
        self.param_name_data_path = self.param_name_base + "data/"
        self.param_name_model_path = self.param_name_base + "model/"

    def set_comment_path(self):
        self.comment_data_path = self.comment_base + "data/"
        self.comment_model_path = self.comment_base + "model/"