import torch
import torch.nn as nn

model = nn.Transformer()